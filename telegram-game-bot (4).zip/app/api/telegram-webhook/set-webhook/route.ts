import { NextResponse } from "next/server"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const token = "7965340925:AAGxU7avZioNeoj3mbJRxyv0XnrMzGXfY8w"

    // 호스트 URL 가져오기
    const host = request.headers.get("host") || "your-app.vercel.app"
    const protocol = host.includes("localhost") ? "http" : "https"
    const webhookUrl = `${protocol}://${host}/api/telegram-webhook`

    // 웹훅 설정 API 호출
    const response = await fetch(`https://api.telegram.org/bot${token}/setWebhook?url=${webhookUrl}`)
    const data = await response.json()

    return NextResponse.json({
      success: true,
      webhook: {
        url: webhookUrl,
        status: data.ok ? "설정됨" : "오류",
        response: data,
      },
      next_steps: ["텔레그램에서 봇을 검색하세요", "/ping 명령어를 입력하여 봇이 응답하는지 확인하세요"],
    })
  } catch (error) {
    console.error("웹훅 설정 오류:", error)
    return NextResponse.json(
      {
        error: String(error),
      },
      { status: 500 },
    )
  }
}
