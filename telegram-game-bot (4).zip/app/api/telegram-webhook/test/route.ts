// 테스트용 API 엔드포인트
import { NextResponse } from "next/server"
import { Telegraf } from "telegraf"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const chatId = searchParams.get("chat_id")

    if (!chatId) {
      return NextResponse.json(
        {
          error: "chat_id 파라미터가 필요합니다",
          example: "/api/telegram-webhook/test?chat_id=YOUR_CHAT_ID",
        },
        { status: 400 },
      )
    }

    const token = process.env.TELEGRAM_BOT_TOKEN
    if (!token) {
      return NextResponse.json({ error: "TELEGRAM_BOT_TOKEN이 설정되지 않았습니다" }, { status: 500 })
    }

    const bot = new Telegraf(token)
    await bot.telegram.sendMessage(chatId, "🎮 테스트 메시지: BitMatch 봇이 정상적으로 작동 중입니다!")

    return NextResponse.json({ success: true, message: `메시지가 chat_id ${chatId}로 전송되었습니다` })
  } catch (error) {
    console.error("테스트 메시지 전송 오류:", error)
    return NextResponse.json({ error: String(error) }, { status: 500 })
  }
}
