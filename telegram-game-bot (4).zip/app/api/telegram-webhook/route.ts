import { Telegraf, Markup } from "telegraf"
import { type NextRequest, NextResponse } from "next/server"
import { getBinancePrice } from "@/lib/crypto-api"

// 토큰을 직접 코드에 포함 (일반적으로 권장되지 않지만 테스트용으로 사용)
const BOT_TOKEN = "7965340925:AAGxU7avZioNeoj3mbJRxyv0XnrMzGXfY8w"
const bot = new Telegraf(BOT_TOKEN)

// 디버깅을 위한 로깅 함수
function logDebug(message: string, data?: any) {
  console.log(`[DEBUG] ${message}`, data ? JSON.stringify(data) : "")
}

// Game state storage - in a real app, you'd use a database
const userStates = new Map()
const gameRounds = new Map()
let currentRound = {
  number: 1,
  timeRemaining: 120,
  btcPrice: 97490.04,
  ethPrice: 1854.39,
  btcChange: "+0.83%",
  ethChange: "+0.10%",
}

// Initialize game
let gameInterval: NodeJS.Timeout | null = null
let isGameRunning = false

// 기본 명령어 설정
bot.start((ctx) => {
  logDebug("Start command received")
  return ctx.reply("안녕하세요! BitMatch 게임 봇입니다. 명령어 목록을 보려면 /help를 입력하세요.")
})

bot.help((ctx) => {
  logDebug("Help command received")
  return ctx.reply(`
사용 가능한 명령어:
/start - 봇 시작하기
/help - 도움말 보기
/ping - 봇 상태 확인
  `)
})

bot.command("ping", (ctx) => {
  logDebug("Ping command received")
  return ctx.reply("pong! 봇이 정상 작동 중입니다.")
})

// 모든 메시지에 응답
bot.on("message", (ctx) => {
  logDebug("Message received:", ctx.message)
  return ctx.reply(`메시지를 받았습니다: ${JSON.stringify(ctx.message)}`)
})

// Start the game timer and price updates
function startGame() {
  if (isGameRunning) return

  logDebug("Starting game...")
  isGameRunning = true
  gameInterval = setInterval(async () => {
    try {
      // Try to get real prices from Binance
      const prices = await getBinancePrice()
      if (prices) {
        const btcOldPrice = currentRound.btcPrice
        const ethOldPrice = currentRound.ethPrice

        currentRound.btcPrice = prices.btcPrice
        currentRound.ethPrice = prices.ethPrice

        // Calculate change percentage
        const btcChangePercent = (((currentRound.btcPrice - btcOldPrice) / btcOldPrice) * 100).toFixed(2)
        const ethChangePercent = (((currentRound.ethPrice - ethOldPrice) / ethOldPrice) * 100).toFixed(2)

        currentRound.btcChange = (btcChangePercent > 0 ? "+" : "") + btcChangePercent + "%"
        currentRound.ethChange = (ethChangePercent > 0 ? "+" : "") + ethChangePercent + "%"
      } else {
        // Fallback to random price changes if API fails
        currentRound.btcPrice = Number.parseFloat((currentRound.btcPrice + (Math.random() * 300 - 150)).toFixed(2))
        currentRound.ethPrice = Number.parseFloat((currentRound.ethPrice + (Math.random() * 20 - 10)).toFixed(2))

        currentRound.btcChange = (Math.random() > 0.5 ? "+" : "-") + (Math.random() * 2).toFixed(2) + "%"
        currentRound.ethChange = (Math.random() > 0.5 ? "+" : "-") + (Math.random() * 2).toFixed(2) + "%"
      }

      // Update time remaining
      if (currentRound.timeRemaining > 0) {
        currentRound.timeRemaining--

        // Notify users about time remaining at specific intervals
        if (
          currentRound.timeRemaining === 60 ||
          currentRound.timeRemaining === 30 ||
          currentRound.timeRemaining === 10
        ) {
          notifyAllUsers(`⏱ *라운드 ${currentRound.number}*: ${currentRound.timeRemaining}초 남았습니다!`)
        }

        // Notify users when betting is closed (at 34 seconds remaining - after 86 seconds)
        if (currentRound.timeRemaining === 34) {
          notifyAllUsers(
            `🔒 *베팅 마감!*\n\n라운드 ${currentRound.number}의 베팅이 마감되었습니다. 결과를 기다려주세요.`,
          )
        }
      } else {
        // Round ended, process bets and start new round
        await processRoundResults()
        currentRound = {
          number: currentRound.number + 1,
          timeRemaining: 120,
          btcPrice: currentRound.btcPrice,
          ethPrice: currentRound.ethPrice,
          btcChange: currentRound.btcChange,
          ethChange: currentRound.ethChange,
        }

        // Notify all users about new round
        notifyAllUsers(`🔄 *라운드 ${currentRound.number} 시작!*\n\n새로운 베팅을 하려면 /bet 명령어를 사용하세요.`)
      }
    } catch (error) {
      console.error("Game update error:", error)
    }
  }, 1000)
}

// Notify all active users
function notifyAllUsers(message: string) {
  for (const [userId] of userStates) {
    try {
      bot.telegram.sendMessage(userId, message, { parse_mode: "Markdown" })
    } catch (error) {
      console.error(`Failed to notify user ${userId}:`, error)
    }
  }
}

// Process round results
async function processRoundResults() {
  // Determine winners based on final prices
  const btcFinalPrice = currentRound.btcPrice
  const ethFinalPrice = currentRound.ethPrice
  const btcWins = btcFinalPrice > ethFinalPrice
  const tie = Math.abs(btcFinalPrice - ethFinalPrice) < 0.01 // Consider very close values as tie
  const btcIsOdd = Math.floor(btcFinalPrice) % 2 !== 0
  const ethIsOdd = Math.floor(ethFinalPrice) % 2 !== 0

  // Prepare result message for all users
  const resultMessage = `
🏁 *라운드 ${currentRound.number} 결과*

*Bitcoin:* ₩${btcFinalPrice.toLocaleString()} (${currentRound.btcChange})
*Ethereum:* ₩${ethFinalPrice.toLocaleString()} (${currentRound.ethChange})

*승리 조건:*
${btcWins ? "✅" : "❌"} BTC WIN
${tie ? "✅" : "❌"} TIE
${!btcWins && !tie ? "✅" : "❌"} ETH WIN
${btcIsOdd ? "✅" : "❌"} BTC ODD
${!btcIsOdd ? "✅" : "❌"} BTC EVEN
${ethIsOdd ? "✅" : "❌"} ETH ODD
${!ethIsOdd ? "✅" : "❌"} ETH EVEN
${btcFinalPrice < 97500 ? "✅" : "❌"} BTC UNDER
${ethFinalPrice > 1850 ? "✅" : "❌"} ETH OVER
`

  // Notify all users about round results
  notifyAllUsers(resultMessage)

  // Process all bets for this round
  const roundBets = gameRounds.get(currentRound.number) || []

  for (const bet of roundBets) {
    const user = userStates.get(bet.userId)
    if (!user) continue

    let won = false
    let multiplier = 1

    switch (bet.option) {
      case "BTC WIN":
        won = btcWins
        multiplier = 1.8
        break
      case "ETH WIN":
        won = !btcWins && !tie
        multiplier = 1.8
        break
      case "TIE":
        won = tie
        multiplier = 10
        break
      case "BTC ODD":
        won = btcIsOdd
        multiplier = 1.9
        break
      case "BTC EVEN":
        won = !btcIsOdd
        multiplier = 1.9
        break
      case "ETH ODD":
        won = ethIsOdd
        multiplier = 1.9
        break
      case "ETH EVEN":
        won = !ethIsOdd
        multiplier = 1.9
        break
      case "BTC UNDER":
        won = btcFinalPrice < 97500
        multiplier = 1.9
        break
      case "ETH OVER":
        won = ethFinalPrice > 1850
        multiplier = 1.9
        break
    }

    // Calculate winnings
    const winnings = won ? Math.floor(bet.amount * multiplier) : 0

    if (won) {
      user.balance += winnings
      // Notify user of win
      await bot.telegram.sendMessage(
        bet.userId,
        `🎉 *승리!* 베팅: ₩${bet.amount.toLocaleString()} on ${bet.option}\n💰 획득: ₩${winnings.toLocaleString()}\n💵 현재 잔액: ₩${user.balance.toLocaleString()}`,
        { parse_mode: "Markdown" },
      )
    } else {
      // Notify user of loss
      await bot.telegram.sendMessage(
        bet.userId,
        `❌ *패배* 베팅: ₩${bet.amount.toLocaleString()} on ${bet.option}\n💵 현재 잔액: ₩${user.balance.toLocaleString()}`,
        { parse_mode: "Markdown" },
      )
    }
  }

  // Clear round bets
  gameRounds.delete(currentRound.number)
}

// 기본 명령어 처리
// bot.command("ping", (ctx) => {
//   logDebug("Received ping command")
//   ctx.reply("pong!")
// })

// // Start command
// bot.command("start", (ctx) => {
//   logDebug("Received start command")
//   const userId = ctx.from.id

//   // Initialize user if new
//   if (!userStates.has(userId)) {
//     userStates.set(userId, {
//       balance: 1000000,
//       currentBet: {
//         amount: 0,
//         option: null,
//       },
//     })
//   }

//   // Start the game if not already running
//   if (!isGameRunning) {
//     startGame()
//   }

//   ctx.reply(
//     "🎮 *BitMatch 베팅 게임에 오신 것을 환영합니다!* 🎮\n\n" +
//       "비트코인과 이더리움 가격 변동에 베팅하고 가상 화폐를 획득하세요!\n\n" +
//       "📊 */status* - 현재 가격 및 남은 시간 확인\n" +
//       "💰 */bet* - 새로운 베팅 하기\n" +
//       "💵 */balance* - 잔액 확인\n" +
//       "❓ */help* - 도움말 보기",
//     { parse_mode: "Markdown" },
//   )
// })

// Status command
bot.command("status", (ctx) => {
  logDebug("Received status command")
  ctx.reply(
    `📊 *BitMatch 상태* 📊\n\n` +
      `*라운드:* ${currentRound.number}\n` +
      `*남은 시간:* ${currentRound.timeRemaining}초\n\n` +
      `*Bitcoin:* ₩${currentRound.btcPrice.toLocaleString()} (${currentRound.btcChange})\n` +
      `*Ethereum:* ₩${currentRound.ethPrice.toLocaleString()} (${currentRound.ethChange})`,
    { parse_mode: "Markdown" },
  )
})

// Balance command
bot.command("balance", (ctx) => {
  logDebug("Received balance command")
  const userId = ctx.from.id
  const user = userStates.get(userId)

  if (!user) {
    ctx.reply("계정을 초기화하려면 /start 명령어를 사용하세요.")
    return
  }

  ctx.reply(`💰 *현재 잔액:* ₩${user.balance.toLocaleString()}`, { parse_mode: "Markdown" })
})

// Bet command
bot.command("bet", (ctx) => {
  logDebug("Received bet command")
  const userId = ctx.from.id
  const user = userStates.get(userId)

  if (!user) {
    ctx.reply("계정을 초기화하려면 /start 명령어를 사용하세요.")
    return
  }

  // Check if betting is still open (first 86 seconds of the round)
  if (currentRound.timeRemaining <= 34) {
    ctx.reply(
      `❌ *베팅 마감*\n\n` +
        `현재 라운드(${currentRound.number})의 베팅이 마감되었습니다.\n` +
        `결과는 ${currentRound.timeRemaining}초 후에 발표됩니다.\n\n` +
        `다음 라운드를 기다려주세요.`,
      { parse_mode: "Markdown" },
    )
    return
  }

  ctx.reply(
    `📊 *현재 시장 상황*\n` +
      `*Bitcoin:* ₩${currentRound.btcPrice.toLocaleString()} (${currentRound.btcChange})\n` +
      `*Ethereum:* ₩${currentRound.ethPrice.toLocaleString()} (${currentRound.ethChange})\n\n` +
      `⏱ *라운드 ${currentRound.number}* - 남은 시간: ${currentRound.timeRemaining}초\n` +
      `🕒 *베팅 마감까지:* ${currentRound.timeRemaining - 34}초\n\n` +
      `베팅 옵션을 선택하세요:`,
    {
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [
          Markup.button.callback("BTC WIN", "bet_BTC_WIN"),
          Markup.button.callback("TIE", "bet_TIE"),
          Markup.button.callback("ETH WIN", "bet_ETH_WIN"),
        ],
        [Markup.button.callback("BTC ODD", "bet_BTC_ODD"), Markup.button.callback("BTC EVEN", "bet_BTC_EVEN")],
        [Markup.button.callback("ETH ODD", "bet_ETH_ODD"), Markup.button.callback("ETH EVEN", "bet_ETH_EVEN")],
        [Markup.button.callback("BTC UNDER", "bet_BTC_UNDER"), Markup.button.callback("ETH OVER", "bet_ETH_OVER")],
      ]),
    },
  )
})

// Handle bet option selection
bot.action(/bet_(.+)/, (ctx) => {
  const userId = ctx.from.id
  const user = userStates.get(userId)
  const option = ctx.match[1].replace(/_/g, " ")

  if (!user) {
    ctx.reply("계정을 초기화하려면 /start 명령어를 사용하세요.")
    return
  }

  user.currentBet.option = option

  ctx.editMessageText(`선택한 옵션: *${option}*\n\n베팅 금액을 선택하세요:`, {
    parse_mode: "Markdown",
    ...Markup.inlineKeyboard([
      [
        Markup.button.callback("₩5,000", "amount_5000"),
        Markup.button.callback("₩10,000", "amount_10000"),
        Markup.button.callback("₩50,000", "amount_50000"),
      ],
      [Markup.button.callback("₩100,000", "amount_100000"), Markup.button.callback("₩1,000,000", "amount_1000000")],
      [Markup.button.callback("❌ 취소", "cancel_bet")],
    ]),
  })
})

// Handle bet amount selection
bot.action(/amount_(\d+)/, (ctx) => {
  const userId = ctx.from.id
  const user = userStates.get(userId)
  const amount = Number.parseInt(ctx.match[1])

  if (!user) {
    ctx.reply("계정을 초기화하려면 /start 명령어를 사용하세요.")
    return
  }

  if (user.balance < amount) {
    ctx.reply("❌ 잔액이 부족합니다. 더 작은 금액을 선택하세요.")
    return
  }

  user.currentBet.amount = amount

  ctx.editMessageText(
    `베팅 확인:\n\n` +
      `옵션: *${user.currentBet.option}*\n` +
      `금액: ₩${amount.toLocaleString()}\n\n` +
      `현재 잔액: ₩${user.balance.toLocaleString()}`,
    {
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback("✅ 확인", "confirm_bet"), Markup.button.callback("❌ 취소", "cancel_bet")],
      ]),
    },
  )
})

// Handle bet confirmation
bot.action("confirm_bet", (ctx) => {
  const userId = ctx.from.id
  const user = userStates.get(userId)

  if (!user || !user.currentBet.option || !user.currentBet.amount) {
    ctx.reply("잘못된 베팅입니다. 새로운 베팅을 하려면 /bet 명령어를 사용하세요.")
    return
  }

  if (user.balance < user.currentBet.amount) {
    ctx.reply("❌ 잔액이 부족합니다. 더 작은 금액을 선택하세요.")
    return
  }

  // Check if betting is still open (first 86 seconds of the round)
  if (currentRound.timeRemaining <= 34) {
    ctx.reply("❌ 베팅이 마감되었습니다. 다음 라운드에 베팅해주세요.")
    return
  }

  // Deduct bet amount from balance
  user.balance -= user.currentBet.amount

  // Add bet to current round
  if (!gameRounds.has(currentRound.number)) {
    gameRounds.set(currentRound.number, [])
  }

  gameRounds.get(currentRound.number).push({
    userId,
    option: user.currentBet.option,
    amount: user.currentBet.amount,
  })

  ctx.editMessageText(
    `✅ *베팅 완료!*\n\n` +
      `옵션: *${user.currentBet.option}*\n` +
      `금액: ₩${user.currentBet.amount.toLocaleString()}\n\n` +
      `새 잔액: ₩${user.balance.toLocaleString()}\n\n` +
      `라운드 ${currentRound.number}는 ${currentRound.timeRemaining}초 후에 종료됩니다.`,
    { parse_mode: "Markdown" },
  )

  // Reset current bet
  user.currentBet = {
    amount: 0,
    option: null,
  }
})

// Handle bet cancellation
bot.action("cancel_bet", (ctx) => {
  const userId = ctx.from.id
  const user = userStates.get(userId)

  if (user) {
    user.currentBet = {
      amount: 0,
      option: null,
    }
  }

  ctx.editMessageText("베팅이 취소되었습니다. 새로운 베팅을 하려면 /bet 명령어를 사용하세요.")
})

// Help command
bot.command("help", (ctx) => {
  logDebug("Received help command")
  ctx.reply(
    "📚 *BitMatch 베팅 게임 도움말* 📚\n\n" +
      "*명령어:*\n" +
      "/start - 계정 초기화\n" +
      "/status - 현재 가격 및 시간 확인\n" +
      "/bet - 새로운 베팅 하기\n" +
      "/balance - 잔액 확인\n" +
      "/help - 도움말 보기\n\n" +
      "*베팅 옵션:*\n" +
      "• BTC WIN - 비트코인 가격 > 이더리움 가격\n" +
      "• ETH WIN - 이더리움 가격 > 비트코인 가격\n" +
      "• TIE - 두 가격이 동일함\n" +
      "• BTC ODD - 비트코인 가격이 홀수로 끝남\n" +
      "• BTC EVEN - 비트코인 가격이 짝수로 끝남\n" +
      "• ETH ODD - 이더리움 가격이 홀수로 끝남\n" +
      "• ETH EVEN - 이더리움 가격이 짝수로 끝남\n" +
      "• BTC UNDER - 비트코인 가격이 기준치 미만\n" +
      "• ETH OVER - 이더리움 가격이 기준치 초과\n\n" +
      "*게임 규칙:*\n" +
      "• 각 라운드는 120초 동안 진행됩니다\n" +
      "• 한 라운드에 여러 베팅을 할 수 있습니다\n" +
      "• 승리 시 자동으로 상금이 지급됩니다\n" +
      "• 시작 잔액: ₩1,000,000",
    { parse_mode: "Markdown" },
  )
})

// 간단한 테스트 명령어 추가
bot.command("test", (ctx) => {
  logDebug("Received test command")
  ctx.reply("테스트 명령어가 정상적으로 작동합니다! 봇이 활성화되어 있습니다.")
})

// 봇 초기화 및 설정
// bot.telegram
//   .getMe()
//   .then((botInfo) => {
//     logDebug(`Bot initialized: @${botInfo.username}`)
//   })
//   .catch((err) => {
//     console.error("Error initializing bot:", err)
//   })

// Launch the bot in webhook mode for production
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    logDebug("Received Telegram update", body)

    // 봇 초기화 확인
    // if (!process.env.TELEGRAM_BOT_TOKEN) {
    //   console.error("TELEGRAM_BOT_TOKEN is not defined")
    //   return NextResponse.json({ ok: false, error: "Bot token not configured" }, { status: 500 })
    // }

    await bot.handleUpdate(body)
    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error("Error processing update:", error)
    return NextResponse.json(
      {
        ok: false,
        error: String(error),
        message: "웹훅 처리 중 오류가 발생했습니다",
      },
      { status: 500 },
    )
  }
}

// 간단한 GET 요청 처리 추가
export async function GET() {
  return NextResponse.json({
    status: "online",
    message: "텔레그램 봇 웹훅 엔드포인트가 활성화되어 있습니다.",
    timestamp: new Date().toISOString(),
  })
}
