import { NextResponse } from "next/server"

export async function GET() {
  try {
    const token = "7965340925:AAGxU7avZioNeoj3mbJRxyv0XnrMzGXfY8w"

    // 봇 정보 가져오기
    const botInfoResponse = await fetch(`https://api.telegram.org/bot${token}/getMe`)
    const botInfo = await botInfoResponse.json()

    // 웹훅 정보 가져오기
    const webhookResponse = await fetch(`https://api.telegram.org/bot${token}/getWebhookInfo`)
    const webhookInfo = await webhookResponse.json()

    return NextResponse.json({
      status: "success",
      bot: botInfo.ok ? botInfo.result : "봇 정보를 가져올 수 없습니다",
      webhook: webhookInfo.ok ? webhookInfo.result : "웹훅 정보를 가져올 수 없습니다",
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    return NextResponse.json(
      {
        status: "error",
        error: String(error),
      },
      { status: 500 },
    )
  }
}
