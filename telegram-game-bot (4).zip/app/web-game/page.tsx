"use client"

import { useEffect, useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function WebGamePage() {
  const [seconds, setSeconds] = useState(120)
  const [round, setRound] = useState(96)
  const [wallet, setWallet] = useState(1000000)
  const [betAmount, setBetAmount] = useState(0)
  const [selectedOption, setSelectedOption] = useState<string | null>(null)
  const [btcPrice, setBtcPrice] = useState("₩97,490.04")
  const [ethPrice, setEthPrice] = useState("₩1,854.39")
  const [btcChange, setBtcChange] = useState("+0.83%")
  const [ethChange, setEthChange] = useState("+0.10%")
  const [btcRawPrice, setBtcRawPrice] = useState(97490.04)
  const [ethRawPrice, setEthRawPrice] = useState(1854.39)
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const priceUpdateRef = useRef<NodeJS.Timeout | null>(null)
  const [isBettingClosed, setIsBettingClosed] = useState(false)
  const [roundResult, setRoundResult] = useState<{
    status: "win" | "lose" | null
    option: string | null
    amount: number
    winnings?: number
  } | null>(null)

  // 차트 결과 상태
  const [btcWin, setBtcWin] = useState(false)
  const [ethWin, setEthWin] = useState(false)
  const [showChartResults, setShowChartResults] = useState(false)

  useEffect(() => {
    // Timer countdown
    timerRef.current = setInterval(() => {
      setSeconds((prev) => {
        // Check if betting should be closed (after 86 seconds)
        if (prev === 34) {
          setIsBettingClosed(true)
          // Show message that betting is closed
          alert("베팅이 마감되었습니다. 결과를 기다려주세요.")
        }

        // When round ends
        if (prev <= 1) {
          // Process results
          processResults()
          // Reset timer and increment round when it reaches 0
          setRound((r) => r + 1)
          setIsBettingClosed(false)

          // Show chart results
          setShowChartResults(true)

          // Hide chart results after 15 seconds
          setTimeout(() => {
            setShowChartResults(false)
          }, 15000)

          return 120
        }
        return prev - 1
      })
    }, 1000)

    // Price updates
    priceUpdateRef.current = setInterval(() => {
      const btc = 97490 + Math.random() * 300 - 150
      const eth = 1854 + Math.random() * 20 - 10

      setBtcRawPrice(btc)
      setEthRawPrice(eth)
      setBtcPrice(`₩${btc.toLocaleString(undefined, { maximumFractionDigits: 2 })}`)
      setEthPrice(`₩${eth.toLocaleString(undefined, { maximumFractionDigits: 2 })}`)

      // Random change percentages
      const btcChangeVal = (Math.random() * 2 - 1).toFixed(2)
      const ethChangeVal = (Math.random() * 2 - 1).toFixed(2)
      setBtcChange(`${Number(btcChangeVal) >= 0 ? "+" : ""}${btcChangeVal}%`)
      setEthChange(`${Number(ethChangeVal) >= 0 ? "+" : ""}${ethChangeVal}%`)
    }, 3000)

    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
      if (priceUpdateRef.current) clearInterval(priceUpdateRef.current)
    }
  }, [])

  const addAmount = (amount: number) => {
    setBetAmount((prev) => prev + amount)
  }

  const placeBet = (option: string) => {
    setSelectedOption(option)
  }

  const resetBet = () => {
    setBetAmount(0)
    setSelectedOption(null)
  }

  const confirmBet = () => {
    // Check if betting is closed
    if (isBettingClosed) {
      alert("베팅이 마감되었습니다. 다음 라운드에 베팅해주세요.")
      return
    }

    if (betAmount > 0 && selectedOption) {
      if (wallet >= betAmount) {
        setWallet((prev) => prev - betAmount)
        alert(`베팅 확인: ₩${betAmount.toLocaleString()} on ${selectedOption}`)
      } else {
        alert("잔액이 부족합니다")
        resetBet()
      }
    } else {
      alert("베팅 옵션과 금액을 선택하세요")
    }
  }

  // 결과 처리 함수 추가
  const processResults = () => {
    // 비트코인과 이더리움 승패 결정
    const btcWins = btcRawPrice > ethRawPrice
    const tie = Math.abs(btcRawPrice - ethRawPrice) < 0.01

    // 차트 결과 설정
    setBtcWin(btcWins || tie)
    setEthWin(!btcWins || tie)

    if (selectedOption && betAmount > 0) {
      // Determine if the bet won
      let won = false
      let multiplier = 1

      const btcIsOdd = Math.floor(btcRawPrice) % 2 !== 0
      const ethIsOdd = Math.floor(ethRawPrice) % 2 !== 0

      switch (selectedOption) {
        case "BTC WIN":
          won = btcWins
          multiplier = 1.8
          break
        case "ETH WIN":
          won = !btcWins && !tie
          multiplier = 1.8
          break
        case "TIE":
          won = tie
          multiplier = 10
          break
        case "BTC ODD":
          won = btcIsOdd
          multiplier = 1.9
          break
        case "BTC EVEN":
          won = !btcIsOdd
          multiplier = 1.9
          break
        case "ETH ODD":
          won = ethIsOdd
          multiplier = 1.9
          break
        case "ETH EVEN":
          won = !ethIsOdd
          multiplier = 1.9
          break
        case "BTC UNDER":
          won = btcRawPrice < 97500
          multiplier = 1.9
          break
        case "ETH OVER":
          won = ethRawPrice > 1850
          multiplier = 1.9
          break
      }

      // Update wallet based on result
      if (won) {
        const winnings = Math.floor(betAmount * multiplier)
        setWallet((prev) => prev + winnings)
        setRoundResult({
          status: "win",
          option: selectedOption,
          amount: betAmount,
          winnings: winnings,
        })
      } else {
        setRoundResult({
          status: "lose",
          option: selectedOption,
          amount: betAmount,
        })
      }

      // Reset bet
      setBetAmount(0)
      setSelectedOption(null)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-radial from-gray-800 to-gray-900 py-10">
      <div className="max-w-5xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-center text-green-400 mb-6">BitMatch 베팅 게임</h1>

        {/* Status Bar */}
        <div className="flex justify-between items-center bg-gray-800 p-4 rounded-lg shadow-lg mb-6">
          <div className="text-center">
            <div className="text-gray-400 text-sm">Bitcoin</div>
            <div className="text-2xl font-bold text-white">{btcPrice}</div>
            <div className={`text-sm ${btcChange.startsWith("+") ? "text-green-400" : "text-red-400"}`}>
              {btcChange}
            </div>
          </div>

          <div className="text-center">
            <div className="text-3xl font-bold text-yellow-400">{seconds}</div>
            <div className="text-sm text-gray-300">Round {round}</div>
            {isBettingClosed ? (
              <div className="text-sm font-bold text-red-400 mt-1">베팅 마감</div>
            ) : (
              <div className="text-sm font-bold text-green-400 mt-1">베팅 가능: {Math.max(0, seconds - 34)}초</div>
            )}
          </div>

          <div className="text-center">
            <div className="text-gray-400 text-sm">Ethereum</div>
            <div className="text-2xl font-bold text-white">{ethPrice}</div>
            <div className={`text-sm ${ethChange.startsWith("+") ? "text-green-400" : "text-red-400"}`}>
              {ethChange}
            </div>
          </div>
        </div>

        {/* Round Result */}
        {roundResult && (
          <div
            className={`p-4 rounded-lg mb-6 shadow-lg ${
              roundResult.status === "win"
                ? "bg-gradient-to-r from-green-900 to-green-700 border-l-4 border-green-500"
                : "bg-gradient-to-r from-red-900 to-red-700 border-l-4 border-red-500"
            }`}
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className={`text-xl font-bold ${roundResult.status === "win" ? "text-green-300" : "text-red-300"}`}>
                  {roundResult.status === "win" ? "승리!" : "패배!"}
                </h3>
                <p className="text-white">
                  {roundResult.option} 옵션에 ₩{roundResult.amount.toLocaleString()} 베팅
                </p>
              </div>

              <div className="text-right">
                {roundResult.status === "win" ? (
                  <p className="text-yellow-400 text-xl font-bold">+₩{roundResult.winnings?.toLocaleString()}</p>
                ) : (
                  <p className="text-red-400 text-xl font-bold">-₩{roundResult.amount.toLocaleString()}</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Charts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* BTC Chart */}
          <div className="bg-gray-800 rounded-lg overflow-hidden shadow-lg h-[400px] relative">
            <div className="w-full h-full">
              <iframe
                src="https://s.tradingview.com/widgetembed/?frameElementId=tv1&symbol=BINANCE:BTCUSDT&interval=1&theme=dark"
                className="w-full h-full border-none"
                title="Bitcoin Chart"
              />
            </div>

            {/* BTC Result Overlay */}
            {showChartResults && (
              <div
                className={`absolute inset-0 flex items-center justify-center ${btcWin ? "bg-red-900/40" : "bg-gray-900/40"}`}
              >
                <div className={`rounded-full px-16 py-8 ${btcWin ? "bg-red-800/80" : "bg-gray-800/80"}`}>
                  <div className="text-2xl font-bold text-white text-center mb-2">{btcWin ? "이기다" : "일다"}</div>
                  <div className="text-5xl font-bold text-white text-center">
                    {btcRawPrice.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* ETH Chart */}
          <div className="bg-gray-800 rounded-lg overflow-hidden shadow-lg h-[400px] relative">
            <div className="w-full h-full">
              <iframe
                src="https://s.tradingview.com/widgetembed/?frameElementId=tv2&symbol=BINANCE:ETHUSDT&interval=1&theme=dark"
                className="w-full h-full border-none"
                title="Ethereum Chart"
              />
            </div>

            {/* ETH Result Overlay */}
            {showChartResults && (
              <div
                className={`absolute inset-0 flex items-center justify-center ${ethWin ? "bg-blue-900/40" : "bg-gray-900/40"}`}
              >
                <div className={`rounded-full px-16 py-8 ${ethWin ? "bg-blue-800/80" : "bg-gray-800/80"}`}>
                  <div className="text-2xl font-bold text-white text-center mb-2">{ethWin ? "이기다" : "일다"}</div>
                  <div className="text-5xl font-bold text-white text-center">
                    {ethRawPrice.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Balance */}
        <div className="text-right mb-4">
          <div className="text-xl text-green-400 font-bold">잔액: ₩{wallet.toLocaleString()}</div>
        </div>

        {/* Betting Grid */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <Button
            onClick={() => placeBet("BTC WIN")}
            disabled={isBettingClosed}
            className={`py-6 text-lg font-bold ${
              selectedOption === "BTC WIN" ? "bg-green-500 hover:bg-green-600" : "bg-red-800 hover:bg-red-700"
            } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            BTC WIN
          </Button>
          <Button
            onClick={() => placeBet("TIE")}
            disabled={isBettingClosed}
            className={`py-6 text-lg font-bold ${
              selectedOption === "TIE" ? "bg-green-500 hover:bg-green-600" : "bg-yellow-700 hover:bg-yellow-600"
            } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            TIE
          </Button>
          <Button
            onClick={() => placeBet("ETH WIN")}
            disabled={isBettingClosed}
            className={`py-6 text-lg font-bold ${
              selectedOption === "ETH WIN" ? "bg-green-500 hover:bg-green-600" : "bg-green-800 hover:bg-green-700"
            } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            ETH WIN
          </Button>
          <Button
            onClick={() => placeBet("BTC ODD")}
            disabled={isBettingClosed}
            className={`py-6 text-lg font-bold ${
              selectedOption === "BTC ODD" ? "bg-green-500 hover:bg-green-600" : "bg-red-800 hover:bg-red-700"
            } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            BTC ODD
          </Button>
          <Button
            onClick={() => placeBet("BTC EVEN")}
            disabled={isBettingClosed}
            className={`py-6 text-lg font-bold ${
              selectedOption === "BTC EVEN" ? "bg-green-500 hover:bg-green-600" : "bg-red-800 hover:bg-red-700"
            } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            BTC EVEN
          </Button>
          <Button
            onClick={() => placeBet("ETH ODD")}
            disabled={isBettingClosed}
            className={`py-6 text-lg font-bold ${
              selectedOption === "ETH ODD" ? "bg-green-500 hover:bg-green-600" : "bg-green-800 hover:bg-green-700"
            } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            ETH ODD
          </Button>
          <Button
            onClick={() => placeBet("ETH EVEN")}
            disabled={isBettingClosed}
            className={`py-6 text-lg font-bold ${
              selectedOption === "ETH EVEN" ? "bg-green-500 hover:bg-green-600" : "bg-green-800 hover:bg-green-700"
            } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            ETH EVEN
          </Button>
          <Button
            onClick={() => placeBet("BTC UNDER")}
            disabled={isBettingClosed}
            className={`py-6 text-lg font-bold ${
              selectedOption === "BTC UNDER" ? "bg-green-500 hover:bg-green-600" : "bg-red-800 hover:bg-red-700"
            } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            BTC UNDER
          </Button>
          <Button
            onClick={() => placeBet("ETH OVER")}
            disabled={isBettingClosed}
            className={`py-6 text-lg font-bold ${
              selectedOption === "ETH OVER" ? "bg-green-500 hover:bg-green-600" : "bg-green-800 hover:bg-green-700"
            } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
          >
            ETH OVER
          </Button>
        </div>

        {/* Betting Panel */}
        <Card className="p-4 bg-gray-800 border-gray-700">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap gap-2">
              <Button
                onClick={() => addAmount(5000)}
                variant="outline"
                className="border-gray-600"
                disabled={isBettingClosed}
              >
                5K
              </Button>
              <Button
                onClick={() => addAmount(10000)}
                variant="outline"
                className="border-gray-600"
                disabled={isBettingClosed}
              >
                10K
              </Button>
              <Button
                onClick={() => addAmount(50000)}
                variant="outline"
                className="border-gray-600"
                disabled={isBettingClosed}
              >
                50K
              </Button>
              <Button
                onClick={() => addAmount(100000)}
                variant="outline"
                className="border-gray-600"
                disabled={isBettingClosed}
              >
                100K
              </Button>
              <Button
                onClick={() => addAmount(1000000)}
                variant="outline"
                className="border-gray-600"
                disabled={isBettingClosed}
              >
                1M
              </Button>
            </div>

            <div className="text-xl font-bold text-yellow-400">
              총 베팅: ₩{betAmount.toLocaleString()}
              {selectedOption ? ` on ${selectedOption}` : ""}
            </div>

            <div className="flex gap-2">
              <Button onClick={resetBet} variant="destructive" disabled={isBettingClosed}>
                초기화
              </Button>
              <Button
                onClick={confirmBet}
                className={`bg-green-600 hover:bg-green-700 ${isBettingClosed ? "opacity-50" : ""}`}
                disabled={isBettingClosed}
              >
                확인
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
