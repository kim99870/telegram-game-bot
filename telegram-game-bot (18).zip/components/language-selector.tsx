"use client"

import type React from "react"

import { useLanguage, type Language } from "@/lib/language-context"
import { Globe, Languages, CircleUser } from "lucide-react"

export default function LanguageSelector() {
  const { language, setLanguage } = useLanguage()

  // 언어 표시 이름
  const languageNames: Record<Language, string> = {
    en: "English",
    ko: "한국어",
    zh: "中文",
  }

  // 언어별 아이콘 컴포넌트 매핑
  const LanguageIcons: Record<Language, React.ReactNode> = {
    en: <Languages className="w-3.5 h-3.5 sm:w-4 sm:h-4" />,
    ko: <CircleUser className="w-3.5 h-3.5 sm:w-4 sm:h-4" />,
    zh: <Globe className="w-3.5 h-3.5 sm:w-4 sm:h-4" />,
  }

  // 언어 변경 핸들러
  const handleLanguageChange = (newLanguage: Language) => {
    setLanguage(newLanguage)
  }

  return (
    <div className="flex items-center justify-center">
      <div className="bg-black/30 backdrop-blur-md rounded-lg p-0.5 border border-white/10 shadow-lg">
        <div className="flex">
          {(Object.keys(languageNames) as Language[]).map((code) => (
            <button
              key={code}
              onClick={() => handleLanguageChange(code)}
              className={`
                px-2 py-1.5 min-w-[42px] sm:min-w-[50px] flex items-center justify-center gap-1.5 transition-all duration-200 text-xs sm:text-sm
                ${
                  language === code
                    ? "bg-blue-500/20 rounded-md text-blue-400 border-b border-blue-500"
                    : "text-gray-400 hover:text-gray-200 hover:bg-white/5"
                }
              `}
              aria-label={`${languageNames[code]} 언어로 변경`}
              aria-current={language === code ? "true" : "false"}
            >
              <div
                className={`
                flex items-center justify-center rounded-full p-1
                ${language === code ? "bg-blue-500/20 text-blue-400" : "text-gray-500"}
              `}
              >
                {LanguageIcons[code]}
              </div>
              <span className="font-medium">{code.toUpperCase()}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
