"use client"

import { useRef, useState } from "react"

interface LogoProps {
  size?: "sm" | "md" | "lg" | "xl"
  variant?: "full" | "icon"
  animated?: boolean
  premium?: boolean
}

export default function BitMarketLogo({ size = "md", variant = "full", animated = true, premium = true }: LogoProps) {
  const [isHovered, setIsHovered] = useState(false)
  const logoRef = useRef<HTMLDivElement>(null)

  // 크기에 따른 클래스 설정
  const sizeClasses = {
    sm: variant === "full" ? "h-6" : "h-6 w-6",
    md: variant === "full" ? "h-8" : "h-8 w-8",
    lg: variant === "full" ? "h-10" : "h-10 w-10",
    xl: variant === "full" ? "h-14" : "h-14 w-14",
  }

  // 아이콘만 표시하는 경우
  if (variant === "icon") {
    return (
      <div
        ref={logoRef}
        className={`relative ${sizeClasses[size]} flex items-center justify-center group overflow-hidden`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* 배경 원형 */}
        <div
          className={`absolute inset-0 rounded-full bg-black border-2 ${
            premium ? "border-[#ffd700]" : "border-[#f7931a]"
          } ${animated && isHovered ? "animate-pulse" : ""}`}
        ></div>

        {/* 내부 그라데이션 효과 */}
        <div
          className={`absolute inset-[3px] rounded-full bg-gradient-to-b from-[#ffd700] to-[#b8860b] opacity-20 ${
            animated && isHovered ? "animate-pulse" : ""
          }`}
        ></div>

        {/* 차트 아이콘 */}
        <svg
          className={`${sizeClasses[size]} relative z-10 p-1.5`}
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M3 17L9 11L13 15L21 7M21 7V13M21 7H15"
            stroke={premium ? "#ffd700" : "#f7931a"}
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className={`${animated && isHovered ? "animate-draw-line" : ""}`}
          />
        </svg>

        {/* 호버 시 빛나는 효과 */}
        {animated && (
          <div
            className={`absolute inset-0 rounded-full bg-gradient-to-r from-transparent via-[#ffd700]/20 to-transparent 
            transition-opacity duration-300 ${isHovered ? "opacity-100" : "opacity-0"} animate-shine`}
          ></div>
        )}
      </div>
    )
  }

  // 전체 로고 표시
  return (
    <div
      ref={logoRef}
      className="flex items-center group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className={`relative ${sizeClasses[size]} flex items-center overflow-hidden`}>
        {/* 배경 원형 */}
        <div
          className={`absolute inset-0 rounded-full bg-black border-2 ${
            premium ? "border-[#ffd700]" : "border-[#f7931a]"
          } ${animated && isHovered ? "animate-pulse" : ""}`}
        ></div>

        {/* 내부 그라데이션 효과 */}
        <div
          className={`absolute inset-[3px] rounded-full bg-gradient-to-b from-[#ffd700] to-[#b8860b] opacity-20 ${
            animated && isHovered ? "animate-pulse" : ""
          }`}
        ></div>

        {/* 차트 아이콘 */}
        <svg
          className={`${sizeClasses[size]} relative z-10 p-1.5`}
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M3 17L9 11L13 15L21 7M21 7V13M21 7H15"
            stroke={premium ? "#ffd700" : "#f7931a"}
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className={`${animated && isHovered ? "animate-draw-line" : ""}`}
          />
        </svg>

        {/* 호버 시 빛나는 효과 */}
        {animated && (
          <div
            className={`absolute inset-0 rounded-full bg-gradient-to-r from-transparent via-[#ffd700]/20 to-transparent 
            transition-opacity duration-300 ${isHovered ? "opacity-100" : "opacity-0"} animate-shine`}
          ></div>
        )}
      </div>

      <div className="ml-2 relative">
        <div className="flex items-center">
          {/* Bit 텍스트 */}
          <span className={`text-white font-bold ${size === "xl" ? "text-2xl" : "text-lg"} tracking-wide`}>Bit</span>

          {/* Match 텍스트 */}
          <span className={`text-[#ffd700] font-bold ${size === "xl" ? "text-2xl" : "text-lg"} tracking-wide`}>
            Match
          </span>
        </div>

        {/* 서브타이틀 */}
        <div className={`${size === "xl" ? "text-xs" : "text-[10px]"} text-gray-400 -mt-1 tracking-wider`}>
          {premium ? "Premium Crypto Trading" : "Crypto Betting Platform"}
        </div>
      </div>
    </div>
  )
}
