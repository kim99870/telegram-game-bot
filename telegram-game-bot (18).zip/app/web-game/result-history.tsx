"use client"

import { useState, useEffect, useRef } from "react"
import { Download, Filter, Search, BarChart3, PieChart, TrendingUp, X, Check } from "lucide-react"
import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/translations"

// 결과 타입 정의
type ResultType = "BTC_WIN" | "ETH_WIN" | "TIE"
type ResultIndicator = "E" | "V" | "W" | "U" | "O"

// 결과 표시용 색상 및 아이콘 매핑
const RESULT_COLORS = {
  E: "bg-red-500", // ETH
  V: "bg-purple-500", // TIE
  W: "bg-green-500", // WIN
  U: "bg-blue-500", // UNDER
  O: "bg-yellow-500", // OVER
}

// 결과 내역 아이템 타입
interface ResultHistoryItem {
  round: number
  btcPrice: string
  ethPrice: string
  btcPriceUp: boolean
  ethPriceUp: boolean
  result: ResultType
  indicators: ResultIndicator[]
  timestamp: string
}

export default function ResultHistory({ initialData = [] }: { initialData?: ResultHistoryItem[] }) {
  // 언어 컨텍스트 사용
  const { language } = useLanguage()

  // 상태 관리
  const [historyData, setHistoryData] = useState<ResultHistoryItem[]>(initialData)
  const [filteredData, setFilteredData] = useState<ResultHistoryItem[]>(initialData)
  const [searchTerm, setSearchTerm] = useState("")
  const [activeFilter, setActiveFilter] = useState<string | null>(null)
  const [showFilters, setShowFilters] = useState(false)
  const [showChartView, setShowChartView] = useState(false)
  const [patternAnalysis, setPatternAnalysis] = useState<{
    btcWinStreak: number
    ethWinStreak: number
    tieStreak: number
    alternatingCount: number
    patterns: { [key: string]: number }
  }>({
    btcWinStreak: 0,
    ethWinStreak: 0,
    tieStreak: 0,
    alternatingCount: 0,
    patterns: {},
  })

  const chartRef = useRef<HTMLCanvasElement>(null)

  // 필터 옵션
  const filterOptions = [
    { id: "btc_win", label: t(language, "history.btcWin"), color: "bg-red-500" },
    { id: "eth_win", label: t(language, "history.ethWin"), color: "bg-green-500" },
    { id: "tie", label: t(language, "history.tie"), color: "bg-yellow-500" },
    { id: "btc_odd", label: t(language, "history.btcOdd"), color: "bg-blue-500" },
    { id: "btc_even", label: t(language, "history.btcEven"), color: "bg-purple-500" },
    { id: "last_10", label: t(language, "history.last10"), color: "bg-gray-500" },
    { id: "last_50", label: t(language, "history.last50"), color: "bg-gray-500" },
    { id: "last_100", label: t(language, "history.last100"), color: "bg-gray-500" },
  ]

  // 검색 및 필터링 처리
  useEffect(() => {
    // 필터링 로직이 custom_range인 경우 이미 필터링된 데이터를 사용하므로 추가 처리 불필요
    if (activeFilter === "custom_range") {
      return
    }

    // 먼저 회차 번호 기준으로 오름차순 정렬 (1회차부터 720회차까지)
    let results = [...historyData].sort((a, b) => a.round - b.round)

    // 검색어 필터링
    if (searchTerm) {
      results = results.filter(
        (item) =>
          item.round.toString().includes(searchTerm) ||
          item.btcPrice.includes(searchTerm) ||
          item.ethPrice.includes(searchTerm) ||
          item.result.includes(searchTerm.toUpperCase()),
      )
    }

    // 필터 적용
    if (activeFilter && activeFilter !== "custom_range") {
      switch (activeFilter) {
        case "btc_win":
          results = results.filter((item) => item.result === "BTC_WIN")
          break
        case "eth_win":
          results = results.filter((item) => item.result === "ETH_WIN")
          break
        case "tie":
          results = results.filter((item) => item.result === "TIE")
          break
        case "btc_odd":
          results = results.filter((item) => {
            const lastDigit = Number.parseInt(item.btcPrice.split(".")[1]?.slice(-1) || "0")
            return lastDigit % 2 !== 0
          })
          break
        case "btc_even":
          results = results.filter((item) => {
            const lastDigit = Number.parseInt(item.btcPrice.split(".")[1]?.slice(-1) || "0")
            return lastDigit % 2 === 0
          })
          break
        case "last_10":
          results = historyData.slice(-10).sort((a, b) => a.round - b.round)
          break
        case "last_50":
          results = historyData.slice(-50).sort((a, b) => a.round - b.round)
          break
        case "last_100":
          results = historyData.slice(-100).sort((a, b) => a.round - b.round)
          break
        case "custom":
          // 이미 검색어로 필터링됨
          break
      }
    }

    setFilteredData(results)
  }, [searchTerm, activeFilter, historyData])

  // 패턴 분석 실행
  useEffect(() => {
    analyzePatterns(filteredData)
  }, [filteredData])

  // 차트 렌더링
  useEffect(() => {
    if (showChartView && chartRef.current) {
      renderChart()
    }
  }, [showChartView, filteredData])

  // 패턴 분석 함수
  const analyzePatterns = (data: ResultHistoryItem[]) => {
    if (data.length === 0) return

    let btcWinStreak = 0
    let ethWinStreak = 0
    let tieStreak = 0
    let alternatingCount = 0
    const patterns: { [key: string]: number } = {}

    // 최근 5개 결과의 패턴 분석
    for (let i = 0; i < Math.min(data.length, 100); i++) {
      // 연속 승리 스트릭 계산
      if (data[i].result === "BTC_WIN") {
        btcWinStreak = Math.max(btcWinStreak, getConsecutiveCount(data, i, "BTC_WIN"))
      } else if (data[i].result === "ETH_WIN") {
        ethWinStreak = Math.max(ethWinStreak, getConsecutiveCount(data, i, "ETH_WIN"))
      } else if (data[i].result === "TIE") {
        tieStreak = Math.max(tieStreak, getConsecutiveCount(data, i, "TIE"))
      }

      // 교차 패턴 확인 (BTC -> ETH -> BTC 등)
      if (i < data.length - 2) {
        if (data[i].result !== data[i + 1].result && data[i].result === data[i + 2].result) {
          alternatingCount++
        }
      }

      // 3회 패턴 분석
      if (i < data.length - 2) {
        const pattern = `${data[i].result}-${data[i + 1].result}-${data[i + 2].result}`
        patterns[pattern] = (patterns[pattern] || 0) + 1
      }
    }

    setPatternAnalysis({
      btcWinStreak,
      ethWinStreak,
      tieStreak,
      alternatingCount,
      patterns,
    })
  }

  // 연속 카운트 계산 함수
  const getConsecutiveCount = (data: ResultHistoryItem[], startIndex: number, resultType: ResultType) => {
    let count = 0
    for (let i = startIndex; i < data.length; i++) {
      if (data[i].result === resultType) {
        count++
      } else {
        break
      }
    }
    return count
  }

  // 차트 렌더링 함수
  const renderChart = () => {
    if (!chartRef.current) return

    const ctx = chartRef.current.getContext("2d")
    if (!ctx) return

    // 캔버스 초기화
    ctx.clearRect(0, 0, chartRef.current.width, chartRef.current.height)

    // 데이터 준비
    const btcWins = filteredData.filter((item) => item.result === "BTC_WIN").length
    const ethWins = filteredData.filter((item) => item.result === "ETH_WIN").length
    const ties = filteredData.filter((item) => item.result === "TIE").length

    const total = btcWins + ethWins + ties
    const btcPercentage = total > 0 ? (btcWins / total) * 100 : 0
    const ethPercentage = total > 0 ? (ethWins / total) * 100 : 0
    const tiePercentage = total > 0 ? (ties / total) * 100 : 0

    // 파이 차트 그리기
    const centerX = chartRef.current.width / 2
    const centerY = chartRef.current.height / 2
    const radius = Math.min(centerX, centerY) - 20

    let startAngle = 0

    // BTC 승리 부분
    if (btcWins > 0) {
      const btcAngle = (btcWins / total) * Math.PI * 2
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + btcAngle)
      ctx.closePath()
      ctx.fillStyle = "#ef5350"
      ctx.fill()
      startAngle += btcAngle
    }

    // ETH 승리 부분
    if (ethWins > 0) {
      const ethAngle = (ethWins / total) * Math.PI * 2
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + ethAngle)
      ctx.closePath()
      ctx.fillStyle = "#26a69a"
      ctx.fill()
      startAngle += ethAngle
    }

    // 무승부 부분
    if (ties > 0) {
      const tieAngle = (ties / total) * Math.PI * 2
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + tieAngle)
      ctx.closePath()
      ctx.fillStyle = "#f0b90b"
      ctx.fill()
    }

    // 레이블 추가
    ctx.font = "14px Arial"
    ctx.fillStyle = "white"
    ctx.textAlign = "center"
    ctx.fillText(`BTC: ${btcPercentage.toFixed(1)}%`, centerX, centerY - 30)
    ctx.fillText(`ETH: ${ethPercentage.toFixed(1)}%`, centerX, centerY)
    ctx.fillText(`TIE: ${tiePercentage.toFixed(1)}%`, centerX, centerY + 30)
  }

  // CSV 다운로드 함수
  const downloadCSV = () => {
    // CSV 헤더
    let csv = "Round,Timestamp,BTC Price,ETH Price,Result\n"

    // 데이터 행 추가
    filteredData.forEach((item) => {
      csv += `${item.round},${item.timestamp},${item.btcPrice},${item.ethPrice},${item.result}\n`
    })

    // CSV 파일 생성 및 다운로드
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", `bitmatch_results_${new Date().toISOString().slice(0, 10)}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  // 결과 아이콘 렌더링 함수
  const renderResultIcon = (result: ResultType) => {
    switch (result) {
      case "BTC_WIN":
        return (
          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-red-500 text-white font-bold text-xs">
            B
          </div>
        )
      case "ETH_WIN":
        return (
          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-green-500 text-white font-bold text-xs">
            E
          </div>
        )
      case "TIE":
        return (
          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-yellow-500 text-white font-bold text-xs">
            T
          </div>
        )
    }
  }

  return (
    <div className="mb-4 sm:mb-6 bg-[#0d1117] rounded-lg border border-[#1a1d24] shadow-lg overflow-hidden">
      {/* 헤더 영역 */}
      <div className="bg-[#0d1117] px-4 py-3 border-b border-[#1a1d24] flex items-center justify-between">
        <div className="font-bold text-[#58a6ff] flex items-center">
          <BarChart3 className="h-5 w-5 mr-2" />
          <span className="text-lg tracking-wide">{t(language, "history.resultHistory")}</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="text-xs text-[#8b949e]">
            {t(language, "history.total")} {filteredData.length}
            {t(language, "history.rounds")}
          </div>

          {/* 툴바 버튼들 */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="p-1.5 rounded-md hover:bg-[#1a1d24] text-[#8b949e] hover:text-white"
            title={t(language, "history.filter")}
          >
            <Filter className="h-4 w-4" />
          </button>

          <button
            onClick={() => setShowChartView(!showChartView)}
            className="p-1.5 rounded-md hover:bg-[#1a1d24] text-[#8b949e] hover:text-white"
            title={t(language, "history.viewChart")}
          >
            <PieChart className="h-4 w-4" />
          </button>

          <button
            onClick={downloadCSV}
            className="p-1.5 rounded-md hover:bg-[#1a1d24] text-[#8b949e] hover:text-white"
            title={t(language, "history.downloadCSV")}
          >
            <Download className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* 검색 및 필터 영역 */}
      <div className="p-3 bg-[#0d1117]/80 border-b border-[#1a1d24] flex flex-wrap items-center gap-2">
        <div className="relative flex-grow max-w-xs">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-[#8b949e]" />
          <input
            type="text"
            placeholder={t(language, "history.searchPlaceholder")}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-8 pr-3 py-2 bg-[#161b22] border border-[#30363d] rounded-md text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#58a6ff] focus:border-[#58a6ff]"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm("")}
              className="absolute right-2 top-2.5 text-[#8b949e] hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* 활성화된 필터 표시 */}
        {activeFilter && (
          <div className="flex items-center bg-[#161b22] px-2 py-1 rounded-md border border-[#30363d]">
            <span className="text-xs text-white mr-1">{filterOptions.find((f) => f.id === activeFilter)?.label}</span>
            <button onClick={() => setActiveFilter(null)} className="text-[#8b949e] hover:text-white">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* 필터 드롭다운 */}
      {showFilters && (
        <div className="p-2 sm:p-3 bg-[#161b22] border-b border-[#1a1d24] grid grid-cols-2 sm:grid-cols-4 gap-1 sm:gap-2">
          {filterOptions.map((filter) => (
            <button
              key={filter.id}
              onClick={() => {
                setActiveFilter(activeFilter === filter.id ? null : filter.id)
                setShowFilters(false)
              }}
              className={`flex items-center px-3 py-2 rounded-md text-sm ${
                activeFilter === filter.id
                  ? "bg-[#0d1117] border border-[#58a6ff] text-white"
                  : "bg-[#0d1117]/50 border border-[#30363d] text-[#8b949e] hover:text-white"
              }`}
            >
              <div className={`w-3 h-3 rounded-full ${filter.color} mr-2`}></div>
              <span>{filter.label}</span>
              {activeFilter === filter.id && <Check className="h-3.5 w-3.5 ml-auto" />}
            </button>
          ))}
        </div>
      )}

      {/* 차트 뷰 */}
      {showChartView ? (
        <div className="p-4 flex flex-col items-center">
          <canvas ref={chartRef} width={250} height={250} className="mb-4"></canvas>

          {/* 패턴 분석 결과 */}
          <div className="w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 sm:gap-4 mt-2 sm:mt-4">
            <div className="bg-[#161b22] p-4 rounded-lg border border-[#30363d]">
              <h3 className="text-[#58a6ff] font-medium mb-2 flex items-center">
                <TrendingUp className="h-4 w-4 mr-1" />
                {t(language, "history.consecutivePatterns")}
              </h3>
              <div className="grid grid-cols-2 gap-2">
                <div className="text-sm">
                  <span className="text-[#8b949e]">{t(language, "history.btcConsecutiveWins")}:</span>
                  <span className="text-white ml-1">
                    {patternAnalysis.btcWinStreak}
                    {t(language, "history.times")}
                  </span>
                </div>
                <div className="text-sm">
                  <span className="text-[#8b949e]">{t(language, "history.ethConsecutiveWins")}:</span>
                  <span className="text-white ml-1">
                    {patternAnalysis.ethWinStreak}
                    {t(language, "history.times")}
                  </span>
                </div>
                <div className="text-sm">
                  <span className="text-[#8b949e]">{t(language, "history.tieConsecutive")}:</span>
                  <span className="text-white ml-1">
                    {patternAnalysis.tieStreak}
                    {t(language, "history.times")}
                  </span>
                </div>
                <div className="text-sm">
                  <span className="text-[#8b949e]">{t(language, "history.alternatingPattern")}:</span>
                  <span className="text-white ml-1">
                    {patternAnalysis.alternatingCount}
                    {t(language, "history.times")}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-[#161b22] p-4 rounded-lg border border-[#30363d] md:col-span-2">
              <h3 className="text-[#58a6ff] font-medium mb-2">{t(language, "history.frequentPatterns")}</h3>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(patternAnalysis.patterns)
                  .sort((a, b) => b[1] - a[1])
                  .slice(0, 6)
                  .map(([pattern, count], index) => (
                    <div key={index} className="text-sm flex justify-between">
                      <span className="text-white">{pattern}</span>
                      <span className="text-[#8b949e]">
                        {count}
                        {t(language, "history.times")}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* 테이블 뷰 - 모든 회차를 명확하게 표시 */}
          <div className="overflow-y-auto max-h-96 sm:max-h-[400px] md:max-h-[500px] custom-scrollbar">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-[#0d1117] z-10">
                <tr className="text-xs text-[#8b949e] border-b border-[#30363d]">
                  <th className="text-left py-2 px-3 font-medium">{t(language, "history.round")}</th>
                  <th className="text-left py-2 px-3 font-medium">{t(language, "history.time")}</th>
                  <th className="text-left py-2 px-3 font-medium">{t(language, "history.btcPrice")}</th>
                  <th className="text-left py-2 px-3 font-medium">{t(language, "history.ethPrice")}</th>
                  <th className="text-left py-2 px-3 font-medium">{t(language, "history.result")}</th>
                  <th className="text-left py-2 px-3 font-medium">{t(language, "history.details")}</th>
                </tr>
              </thead>
              <tbody>
                {filteredData.map((historyItem) => (
                  <tr
                    key={historyItem.round}
                    className={`border-b border-[#30363d]/10 hover:bg-[#161b22]/50 transition-colors duration-150 ${
                      historyItem.result === "BTC_WIN"
                        ? "bg-red-500/10"
                        : historyItem.result === "ETH_WIN"
                          ? "bg-green-500/10"
                          : "bg-yellow-500/10"
                    }`}
                  >
                    <td className="py-2 px-3 font-medium text-white">{historyItem.round}</td>
                    <td className="py-2 px-3 text-gray-400">{historyItem.timestamp}</td>
                    <td className="py-2 px-3">
                      <div className="flex items-center">
                        <span className={`mr-1 ${historyItem.btcPriceUp ? "text-green-400" : "text-red-400"}`}>
                          {historyItem.btcPriceUp ? "▲" : "▼"}
                        </span>
                        <span className="font-mono text-white">{historyItem.btcPrice}</span>
                      </div>
                    </td>
                    <td className="py-2 px-3">
                      <div className="flex items-center">
                        <span className={`mr-1 ${historyItem.ethPriceUp ? "text-green-400" : "text-red-400"}`}>
                          {historyItem.ethPriceUp ? "▲" : "▼"}
                        </span>
                        <span className="font-mono text-white">{historyItem.ethPrice}</span>
                      </div>
                    </td>
                    <td className="py-2 px-3">
                      <div
                        className={`inline-flex items-center px-2 py-1 rounded-full ${
                          historyItem.result === "BTC_WIN"
                            ? "bg-red-500/20 text-red-400"
                            : historyItem.result === "ETH_WIN"
                              ? "bg-green-500/20 text-green-400"
                              : "bg-yellow-500/20 text-yellow-400"
                        }`}
                      >
                        {renderResultIcon(historyItem.result)}
                        <span className="ml-1 font-medium">
                          {historyItem.result === "BTC_WIN"
                            ? t(language, "history.btcWin")
                            : historyItem.result === "ETH_WIN"
                              ? t(language, "history.ethWin")
                              : t(language, "history.tie")}
                        </span>
                      </div>
                    </td>
                    <td className="py-2 px-3">
                      <div className="flex flex-wrap gap-1">
                        {historyItem.indicators.map((indicator, idx) => (
                          <span
                            key={idx}
                            className={`inline-block w-5 h-5 rounded-full ${RESULT_COLORS[indicator]} text-white text-xs flex items-center justify-center font-bold`}
                          >
                            {indicator}
                          </span>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="px-4 py-2 border-t border-[#1a1d24] bg-[#0d1117] flex justify-between items-center">
            <div className="flex space-x-1">
              <button
                onClick={() => {
                  if (filteredData.length > 0) {
                    const firstRound = Math.min(...filteredData.map((item) => item.round))
                    setActiveFilter("custom")
                    setSearchTerm(firstRound.toString())
                  }
                }}
                className="px-3 py-1 text-xs bg-[#161b22] text-[#58a6ff] rounded border border-[#30363d] hover:bg-[#1a1d24]"
              >
                {t(language, "history.first")}
              </button>
              <button
                onClick={() => {
                  if (filteredData.length > 0) {
                    const rounds = filteredData.map((item) => item.round).sort((a, b) => a - b)
                    const currentIndex = searchTerm ? rounds.indexOf(Number.parseInt(searchTerm)) : -1
                    if (currentIndex > 0) {
                      setActiveFilter("custom")
                      setSearchTerm(rounds[currentIndex - 1].toString())
                    } else {
                      setActiveFilter("custom")
                      setSearchTerm(rounds[0].toString())
                    }
                  }
                }}
                className="px-3 py-1 text-xs bg-[#161b22] text-[#58a6ff] rounded border border-[#30363d] hover:bg-[#1a1d24]"
              >
                {t(language, "history.previous")}
              </button>
              <button
                onClick={() => {
                  if (filteredData.length > 0) {
                    const rounds = filteredData.map((item) => item.round).sort((a, b) => a - b)
                    const currentIndex = searchTerm ? rounds.indexOf(Number.parseInt(searchTerm)) : -1
                    if (currentIndex >= 0 && currentIndex < rounds.length - 1) {
                      setActiveFilter("custom")
                      setSearchTerm(rounds[currentIndex + 1].toString())
                    } else {
                      setActiveFilter("custom")
                      setSearchTerm(rounds[rounds.length - 1].toString())
                    }
                  }
                }}
                className="px-3 py-1 text-xs bg-[#161b22] text-[#58a6ff] rounded border border-[#30363d] hover:bg-[#1a1d24]"
              >
                {t(language, "history.next")}
              </button>
              <button
                onClick={() => {
                  if (filteredData.length > 0) {
                    const lastRound = Math.max(...filteredData.map((item) => item.round))
                    setActiveFilter("custom")
                    setSearchTerm(lastRound.toString())
                  }
                }}
                className="px-3 py-1 text-xs bg-[#161b22] text-[#58a6ff] rounded border border-[#30363d] hover:bg-[#1a1d24]"
              >
                {t(language, "history.last")}
              </button>
            </div>

            <div className="flex items-center">
              <span className="text-xs text-[#8b949e] mr-2">{t(language, "history.roundRange")}:</span>
              <select
                onChange={(e) => {
                  const value = e.target.value
                  if (value === "all") {
                    setActiveFilter(null)
                    setSearchTerm("")
                  } else if (value === "1-100") {
                    setActiveFilter("custom_range")
                    setFilteredData(historyData.filter((item) => item.round >= 1 && item.round <= 100))
                  } else if (value === "101-200") {
                    setActiveFilter("custom_range")
                    setFilteredData(historyData.filter((item) => item.round >= 101 && item.round <= 200))
                  } else if (value === "201-300") {
                    setActiveFilter("custom_range")
                    setFilteredData(historyData.filter((item) => item.round >= 201 && item.round <= 300))
                  } else if (value === "301-400") {
                    setActiveFilter("custom_range")
                    setFilteredData(historyData.filter((item) => item.round >= 301 && item.round <= 400))
                  } else if (value === "401-500") {
                    setActiveFilter("custom_range")
                    setFilteredData(historyData.filter((item) => item.round >= 401 && item.round <= 500))
                  } else if (value === "501-600") {
                    setActiveFilter("custom_range")
                    setFilteredData(historyData.filter((item) => item.round >= 501 && item.round <= 600))
                  } else if (value === "601-720") {
                    setActiveFilter("custom_range")
                    setFilteredData(historyData.filter((item) => item.round >= 601 && item.round <= 720))
                  }
                }}
                className="bg-[#161b22] text-white text-xs border border-[#30363d] rounded px-2 py-1"
              >
                <option value="all">{t(language, "history.allRounds")}</option>
                <option value="1-100">1-100</option>
                <option value="101-200">101-200</option>
                <option value="201-300">201-300</option>
                <option value="301-400">301-400</option>
                <option value="401-500">401-500</option>
                <option value="501-600">501-600</option>
                <option value="601-720">601-720</option>
              </select>
            </div>
          </div>

          {/* 결과 통계 정보 */}
          <div className="px-4 py-3 border-t border-[#1a1d24] bg-[#0d1117]">
            <div className="flex flex-wrap justify-between text-sm gap-2">
              <div>
                <span className="text-gray-500">{t(language, "history.btcWins")}:</span>{" "}
                <span className="text-red-400 font-medium">
                  {filteredData.filter((r) => r.result === "BTC_WIN").length}
                </span>
                <span className="text-gray-500 ml-1">
                  (
                  {filteredData.length > 0
                    ? Math.round(
                        (filteredData.filter((r) => r.result === "BTC_WIN").length / filteredData.length) * 100,
                      )
                    : 0}
                  %)
                </span>
              </div>
              <div>
                <span className="text-gray-500">{t(language, "history.ethWins")}:</span>{" "}
                <span className="text-green-400 font-medium">
                  {filteredData.filter((r) => r.result === "ETH_WIN").length}
                </span>
                <span className="text-gray-500 ml-1">
                  (
                  {filteredData.length > 0
                    ? Math.round(
                        (filteredData.filter((r) => r.result === "ETH_WIN").length / filteredData.length) * 100,
                      )
                    : 0}
                  %)
                </span>
              </div>
              <div>
                <span className="text-gray-500">{t(language, "history.ties")}:</span>{" "}
                <span className="text-yellow-400 font-medium">
                  {filteredData.filter((r) => r.result === "TIE").length}
                </span>
                <span className="text-gray-500 ml-1">
                  (
                  {filteredData.length > 0
                    ? Math.round((filteredData.filter((r) => r.result === "TIE").length / filteredData.length) * 100)
                    : 0}
                  %)
                </span>
              </div>
            </div>
          </div>
        </>
      )}

      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #0d1117;
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #30363d;
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #58a6ff;
        }
        .custom-scrollbar::-webkit-scrollbar-corner {
          background: #0d1117;
        }
      `}</style>
    </div>
  )
}
