"use client"

import { useEffect, useState, useRef } from "react"
import { ArrowDown, ArrowUp, AlertCircle, CheckCircle, Clock, Users, XCircle } from "lucide-react"
// 기존 import 문에 추가
import ResultHistory from "./result-history"
import { useLanguage } from "@/lib/language-context"
import { t } from "@/lib/translations"
import LanguageSelector from "@/components/language-selector"
// 상단에 BitMarketLogo import 추가
import BitMarketLogo from "@/components/logo"

// 베팅 내역 타입 정의
interface BettingHistory {
  id: string
  round: number
  option: string
  amount: number
  timestamp: string
  result?: "win" | "lose" | null
  winnings?: number
  balanceAfter?: number
}

// 가상 베팅 타입 정의 수정
interface VirtualBet {
  id: string
  option: string
  amount: number
  timestamp: string
  result?: "win" | "lose" // 결과 속성 추가
}

// 베팅 옵션 정의
const BET_OPTIONS = [
  "BTC WIN",
  "TIE",
  "ETH WIN",
  "BTC ODD",
  "BTC EVEN",
  "ETH ODD",
  "ETH EVEN",
  "BTC OVER",
  "BTC UNDER",
  "ETH OVER",
  "ETH UNDER",
]

// 결과 타입 정의
type ResultType = "BTC_WIN" | "ETH_WIN" | "TIE"
type ResultIndicator = "E" | "V" | "W" | "U" | "O"

// 결과 표시용 색상 및 아이콘 매핑
const RESULT_COLORS = {
  E: "bg-red-500", // ETH
  V: "bg-purple-500", // TIE
  W: "bg-green-500", // WIN
  U: "bg-blue-500", // UNDER
  O: "bg-yellow-500", // OVER
}

// 가격 변동 표시용 아이콘
const PriceChangeIcon = ({ isUp }: { isUp: boolean }) => (
  <span className={`inline-block mr-1 ${isUp ? "text-green-500" : "text-red-500"}`}>{isUp ? "▲" : "▼"}</span>
)

// 가짜 로고 컴포넌트 (실제 로고로 대체해야 함)
const BitcoinLogo = () => (
  <div className="w-6 h-6 rounded-full bg-[#f7931a] flex items-center justify-center">
    <span className="text-white text-xs font-bold">₿</span>
  </div>
)

const EthereumLogo = () => (
  <div className="w-6 h-6 rounded-full bg-[#627EEA] flex items-center justify-center">
    <span className="text-white text-xs font-bold">Ξ</span>
  </div>
)

// 가짜 로그 데이터 파싱 함수
const parseLogEntry = (log: string) => {
  const parts = log.split("|")
  const timestamp = parts[0]
  const message = parts[1]

  if (message.startsWith("Price update")) {
    const btcPriceMatch = message.match(/BTC=([\d.]+)/)
    const ethPriceMatch = message.match(/ETH=([\d.]+)/)

    const btcPrice = btcPriceMatch ? Number.parseFloat(btcPriceMatch[1]) : null
    const ethPrice = ethPriceMatch ? Number.parseFloat(ethPriceMatch[1]) : null

    return {
      timestamp,
      status: "Price Update",
      statusBg: "bg-blue-900/20",
      statusColor: "text-blue-400",
      statusIcon: <Clock className="h-4 w-4" />,
      btcPrice: btcPrice ? btcPrice.toFixed(2) : null,
      ethPrice: ethPrice ? ethPrice.toFixed(2) : null,
      details: "Real-time price update from Binance API",
    }
  } else if (message.startsWith("Bet placed")) {
    const optionMatch = message.match(/Option=([^,]+)/)
    const amountMatch = message.match(/Amount=([\d.]+)/)

    const option = optionMatch ? optionMatch[1] : null
    const amount = amountMatch ? Number.parseFloat(amountMatch[1]) : null

    return {
      timestamp,
      status: "Bet Placed",
      statusBg: "bg-yellow-900/20",
      statusColor: "text-yellow-400",
      statusIcon: <AlertCircle className="h-4 w-4" />,
      details: `User placed a bet on ${option} with amount ₩${amount?.toLocaleString()}`,
    }
  } else if (message.startsWith("Round ended")) {
    const btcPriceMatch = message.match(/BTC=([\d.]+)/)
    const ethPriceMatch = message.match(/ETH=([\d.]+)/)

    const btcPrice = btcPriceMatch ? Number.parseFloat(btcPriceMatch[1]) : null
    const ethPrice = ethPriceMatch ? Number.parseFloat(ethPriceMatch[1]) : null

    return {
      timestamp,
      status: "Round Ended",
      statusBg: "bg-green-900/20",
      statusColor: "text-green-400",
      statusIcon: <CheckCircle className="h-4 w-4" />,
      btcPrice: btcPrice ? btcPrice.toFixed(2) : null,
      ethPrice: ethPrice ? ethPrice.toFixed(2) : null,
      details: "Round has ended, results are being calculated",
    }
  } else {
    return {
      timestamp,
      status: "Info",
      statusBg: "bg-gray-900/20",
      statusColor: "text-gray-400",
      statusIcon: <AlertCircle className="h-4 w-4" />,
      details: message,
    }
  }
}

// 가짜 로그 필터링 함수
const getFilteredLogs = (activeTab = "all", debugLog: string[] = []) => {
  if (activeTab === "all") {
    return debugLog
  } else if (activeTab === "price") {
    return debugLog.filter((log) => log.includes("Price update"))
  } else {
    return debugLog
  }
}

export default function WebGamePage() {
  const { language } = useLanguage()
  // 현재 시간 기준으로 라운드 번호 계산
  const calculateCurrentRound = () => {
    const now = new Date()
    const hours = now.getHours()
    const minutes = now.getMinutes()

    // 00:00부터 시작해서 2분마다 1회차씩 증가
    // 하루 총 720회차 (24시간 * 60분 / 2분)
    const totalMinutesSinceMidnight = hours * 60 + minutes
    const roundNumber = Math.floor(totalMinutesSinceMidnight / 2) + 1

    return roundNumber > 720 ? roundNumber - 720 : roundNumber
  }

  const [seconds, setSeconds] = useState(120)
  const [round, setRound] = useState(calculateCurrentRound()) // 현재 시간 기준 라운드 계산
  const [wallet, setWallet] = useState(1000000)
  // 출목표 (이전 라운드 결과 기록)
  const [roundResults, setRoundResults] = useState<
    Array<{
      round: number
      result: "BTC_WIN" | "ETH_WIN" | "TIE"
      btcLastDigits: number
      ethLastDigits: number
      timestamp: string
      betOption?: string
      betAmount?: number
    }>
  >([])

  // 전체 라운드 히스토리 (1-720)
  const [fullRoundHistory, setFullRoundHistory] = useState<
    Array<{
      round: number
      btcPrice: string
      ethPrice: string
      btcPriceUp: boolean
      ethPriceUp: boolean
      result: ResultType
      indicators: ResultIndicator[]
    }>
  >([])

  const [betAmount, setBetAmount] = useState(0)
  const [selectedOption, setSelectedOption] = useState<string | null>(null)

  // 실시간 회원 수 상태 추가
  const [activeUsers, setActiveUsers] = useState(Math.floor(Math.random() * 100) + 50) // 50~150명

  // 베팅 내역 상태 추가
  const [bettingHistory, setBettingHistory] = useState<BettingHistory[]>([])

  // 가상 베팅 내역 (다른 사람들의 베팅처럼 보이는 데이터)
  const [virtualBets, setVirtualBets] = useState<VirtualBet[]>([])

  // 옵션별 베팅 카운트
  const [betCounts, setBetCounts] = useState<Record<string, number>>({
    "BTC WIN": 0,
    TIE: 0,
    "ETH WIN": 0,
    "BTC ODD": 0,
    "BTC EVEN": 0,
    "ETH ODD": 0,
    "ETH EVEN": 0,
    "BTC OVER": 0,
    "BTC UNDER": 0,
    "ETH OVER": 0,
    "ETH UNDER": 0,
  })

  // 차트 값과 동일한 가격으로 설정 (Binance API에서 가져온 실제 가격으로 초기화)
  const [btcPrice, setBtcPrice] = useState("96,238.09")
  const [ethPrice, setEthPrice] = useState("1,827.48")
  const [btcChange, setBtcChange] = useState("+0.02%")
  const [ethChange, setEthChange] = useState("+0.02%")
  const [btcRawPrice, setBtcRawPrice] = useState(96238.09)
  const [ethRawPrice, setEthRawPrice] = useState(1827.48)

  // 베팅 마감 시 고정된 가격 (결과 계산용)
  const [lockedBtcPrice, setLockedBtcPrice] = useState(0)
  const [lockedEthPrice, setLockedEthPrice] = useState(0)

  // 결과 표시용 최종 고정 가격 (0초 시점의 실제 가격)
  const [finalBtcPrice, setFinalBtcPrice] = useState(0)
  const [finalEthPrice, setFinalEthPrice] = useState(0)

  // 다음 라운드 시작 가격 (이전 라운드 결과값)
  const [nextRoundBtcPrice, setNextRoundBtcPrice] = useState(0)
  const [nextRoundEthPrice, setNextRoundEthPrice] = useState(0)

  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const priceUpdateRef = useRef<NodeJS.Timeout | null>(null)
  const virtualBetsRef = useRef<NodeJS.Timeout | null>(null)
  const activeUsersRef = useRef<NodeJS.Timeout | null>(null)
  const [isBettingClosed, setIsBettingClosed] = useState(false)
  const [isPriceUpdatePaused, setIsPriceUpdatePaused] = useState(false)
  const [roundResult, setRoundResult] = useState<{
    status: "win" | "lose" | null
    option: string | null
    amount: number
    winnings?: number
  } | null>(null)

  // 차트 결과 상태
  const [btcWin, setBtcWin] = useState(false)
  const [ethWin, setEthWin] = useState(false)
  const [showChartResults, setShowChartResults] = useState(false)
  const [timerStatus, setTimerStatus] = useState("Awaiting") // 타이머 상태 메시지

  // 가격 업데이트 애니메이션 상태
  const [btcPriceChanged, setBtcPriceChanged] = useState(false)
  const [ethPriceChanged, setEthPriceChanged] = useState(false)

  // 차트 iframe 참조
  const btcChartRef = useRef<HTMLIFrameElement>(null)
  const ethChartRef = useRef<HTMLIFrameElement>(null)

  // 디버깅용 로그 상태
  const [debugLog, setDebugLog] = useState<string[]>([])
  // const [activeTab, setActiveTab] = useState("all") // 로그 필터링 탭

  // 타이머 정확도 개선을 위한 시간 추적
  const lastTickTimeRef = useRef<number>(Date.now())

  // 현재 활성화된 베팅 ID
  const [currentBetId, setCurrentBetId] = useState<string | null>(null)

  // 디버깅 로그 함수
  const addDebugLog = (message: string) => {
    const now = new Date()
    const timeStr = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}:${now.getSeconds().toString().padStart(2, "0")}.${now.getMilliseconds().toString().padStart(3, "0")}`

    setDebugLog((prev) => [...prev.slice(-19), `${timeStr}|${message}`])
    console.log(message)
  }

  // 실시간 회원 수 업데이트 함수
  const updateActiveUsers = () => {
    // 5~35명 사이의 랜덤 값으로 업데이트
    setActiveUsers(Math.floor(Math.random() * 31) + 5)
  }

  // 실시간 회원 수 주기적 업데이트
  useEffect(() => {
    // 3~8초 간격으로 회원 수 업데이트
    const updateUsers = () => {
      updateActiveUsers()
      const nextInterval = Math.floor(Math.random() * 10000) + 10000 // 10~20초
      activeUsersRef.current = setTimeout(updateUsers, nextInterval)
    }

    // 첫 업데이트 시작
    activeUsersRef.current = setTimeout(updateUsers, 3000)

    return () => {
      if (activeUsersRef.current) clearTimeout(activeUsersRef.current)
    }
  }, [])

  // 가상 베팅 생성 함수
  const generateVirtualBet = () => {
    // 베팅 마감 시간이면 생성하지 않음
    if (seconds <= 34) return

    // 랜덤 옵션 선택
    const option = BET_OPTIONS[Math.floor(Math.random() * BET_OPTIONS.length)]

    // 랜덤 금액 생성 (50만원 ~ 780만원)
    const minAmount = 500000
    const maxAmount = 7800000
    const amount = Math.floor(Math.random() * (maxAmount - minAmount + 1)) + minAmount

    // 금액을 10만원 단위로 반올림
    const roundedAmount = Math.round(amount / 100000) * 100000

    // 현재 시간
    const now = new Date()
    const timeStr = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}:${now.getSeconds().toString().padStart(2, "0")}`

    // 고유 ID 생성 (더 다양한 사용자 ID가 생성되도록 수정)
    const id = `virtual-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`

    // 새 가상 베팅 생성
    const newVirtualBet: VirtualBet = {
      id,
      option,
      amount: roundedAmount,
      timestamp: timeStr,
      // 초기에는 결과 없음, 라운드 종료 시 결과 추가됨
    }

    // 가상 베팅 추가
    setVirtualBets((prev) => {
      // 최대 50개까지 유지 (더 많은 베팅 기록 유지)
      const updated = [...prev, newVirtualBet].slice(-50)
      return updated
    })

    // 옵션별 카운트 증가
    setBetCounts((prev) => ({
      ...prev,
      [option]: prev[option] + 1,
    }))
  }

  // 가상 베팅 시작
  useEffect(() => {
    // 초기 가상 베팅 생성 (15개)
    for (let i = 0; i < 15; i++) {
      generateVirtualBet()
    }

    return () => {
      if (virtualBetsRef.current) clearTimeout(virtualBetsRef.current)
    }
  }, [])

  // 타이머와 연동하여 가상 베팅 생성
  useEffect(() => {
    // 베팅 가능 시간에만 가상 베팅 생성 (86초 ~ 34초 사이)
    if (seconds > 34 && seconds <= 120) {
      // 베팅 가능 시간 내에서 랜덤하게 베팅 생성
      const generateBetWithDelay = () => {
        // 베팅 마감 전까지만 베팅 생성
        if (seconds > 34) {
          generateVirtualBet()

          // 다음 베팅까지 시간 간격 (베팅 가능 시간에 따라 조절)
          // 남은 시간이 적을수록 베팅 빈도 증가
          const remainingBettingTime = seconds - 34
          const maxInterval = Math.min(remainingBettingTime * 500, 5000) // 최대 5초, 남은 시간이 적으면 더 짧게
          const nextInterval = Math.floor(Math.random() * maxInterval) + 1000 // 1초~maxInterval초

          virtualBetsRef.current = setTimeout(generateBetWithDelay, nextInterval)
        }
      }

      // 첫 가상 베팅 시작 (약간의 지연 후)
      virtualBetsRef.current = setTimeout(generateBetWithDelay, 1000)
    }

    return () => {
      if (virtualBetsRef.current) clearTimeout(virtualBetsRef.current)
    }
  }, [seconds])

  // Binance API에서 실시간 가격 가져오기
  const fetchPrices = async () => {
    // 베팅 마감 후에는 가격 업데이트 중지
    if (isPriceUpdatePaused) {
      return
    }

    try {
      // BTC 가격 가져오기
      const btcResponse = await fetch("https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT")
      const btcData = await btcResponse.json()

      // ETH 가격 가져오기
      const ethResponse = await fetch("https://api.binance.com/api/v3/ticker/price?symbol=ETHUSDT")
      const ethData = await ethResponse.json()

      // 24시간 변동률 가져오기
      const btcTickerResponse = await fetch("https://api.binance.com/api/v3/ticker/24hr?symbol=BTCUSDT")
      const btcTickerData = await btcTickerResponse.json()

      const ethTickerResponse = await fetch("https://api.binance.com/api/v3/ticker/24hr?symbol=ETHUSDT")
      const ethTickerData = await ethTickerResponse.json()

      // 가격 변환 및 포맷팅
      const newBtcPrice = Number.parseFloat(btcData.price)
      const newEthPrice = Number.parseFloat(ethData.price)

      // 변동률 계산
      const btcPriceChangePercent = Number.parseFloat(btcTickerData.priceChangePercent)
      const ethPriceChangePercent = Number.parseFloat(ethTickerData.priceChangePercent)

      // 항상 가격을 업데이트하여 차트와 동기화
      const formattedBtcPrice = newBtcPrice.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })
      setBtcPrice(formattedBtcPrice)
      setBtcRawPrice(newBtcPrice)

      if (newBtcPrice !== btcRawPrice) {
        setBtcPriceChanged(true)
        setTimeout(() => setBtcPriceChanged(false), 500)
      }

      const formattedEthPrice = newEthPrice.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })
      setEthPrice(formattedEthPrice)
      setEthRawPrice(newEthPrice)

      if (newEthPrice !== ethRawPrice) {
        setEthPriceChanged(true)
        setTimeout(() => setEthPriceChanged(false), 500)
      }

      // 변동률 업데이트
      const btcChangeFormatted = (btcPriceChangePercent > 0 ? "+" : "") + btcPriceChangePercent.toFixed(2) + "%"
      const ethChangeFormatted = (ethPriceChangePercent > 0 ? "+" : "") + ethPriceChangePercent.toFixed(2) + "%"

      setBtcChange(btcChangeFormatted)
      setEthChange(ethChangeFormatted)

      // 디버깅 로그에 현재 가격 기록 (차트와 동일한 값)
      addDebugLog(`Price update: BTC=${newBtcPrice.toFixed(2)}, ETH=${newEthPrice.toFixed(2)}`)

      return { btcPrice: newBtcPrice, ethPrice: newEthPrice }
    } catch (error) {
      console.error("가격 가져오기 오류:", error)
      return null
    }
  }

  // 새로운 가격 가져오기 함수 (새 라운드 시작용)
  const fetchNewPrices = async () => {
    try {
      const prices = await fetchPrices()
      if (prices) {
        return prices
      }
    } catch (error) {
      console.error("새 가격 가져오기 오류:", error)
    }

    // 실패 시 기본값 반환
    return {
      btcPrice: btcRawPrice,
      ethPrice: ethRawPrice,
    }
  }

  // 컴포넌트 마운트 시 가격 업데이트 시작
  useEffect(() => {
    // 초기 가격 가져오기
    fetchPrices()

    // 1초마다 가격 업데이트
    priceUpdateRef.current = setInterval(fetchPrices, 1000)

    return () => {
      if (priceUpdateRef.current) clearInterval(priceUpdateRef.current)
    }
  }, [isPriceUpdatePaused])

  // 타이머 정확도 개선을 위한 함수
  const updateTimer = () => {
    const now = Date.now()
    const elapsed = now - lastTickTimeRef.current
    lastTickTimeRef.current = now

    // 타이머 업데이트 (정확한 1초 간격 유지)
    setSeconds((prev) => {
      // 타이머 상태 메시지 업데이트
      if (prev <= 30) {
        setTimerStatus("Closing")
      } else if (prev <= 60) {
        setTimerStatus("Betting")
      } else {
        setTimerStatus("Awaiting")
      }

      // 베팅 마감 체크 (34초 남았을 때)
      if (prev === 34) {
        setIsBettingClosed(true)
        setLockedBtcPrice(btcRawPrice)
        setLockedEthPrice(ethRawPrice)

        addDebugLog(`Betting closed! Price locked: BTC=${btcRawPrice.toFixed(2)}, ETH=${ethRawPrice.toFixed(2)}`)

        // 베팅 마감 메시지 표시
        alert("Betting is closed. Loading result data...")
      }

      // 라운드 종료 시 (0초가 될 때)
      if (prev <= 1) {
        // 0초 시점의 실제 가격 캡처를 위해 즉시 API 호출
        fetchPrices().then((prices) => {
          if (prices) {
            // 최종 가격 설정 (API에서 가져온 실시간 가격)
            setFinalBtcPrice(prices.btcPrice)
            setFinalEthPrice(prices.ethPrice)

            // 디버깅 로그에 최종 결과 가격 기록
            addDebugLog(
              `Round ended! Final price captured: BTC=${prices.btcPrice.toFixed(2)}, ETH=${prices.ethPrice.toFixed(2)}`,
            )

            // 결과 처리 (실시간 가격으로)
            processResults(prices.btcPrice, prices.ethPrice)

            // 차트 결과 표시
            setShowChartResults(true)

            // 15초 후 차트 결과 숨기기 및 새 라운드 시작
            setTimeout(async () => {
              setShowChartResults(false)
              setIsBettingClosed(false)
              setIsPriceUpdatePaused(false) // 가격 업데이트 재개

              // 새 라운드 시작 시 새로운 가격 가져오기
              const newPrices = await fetchNewPrices()
              setBtcRawPrice(newPrices.btcPrice)
              setEthRawPrice(newPrices.ethPrice)

              const formattedBtcPrice = newPrices.btcPrice.toLocaleString(undefined, {
                minimumFractionDigits: 2,
                minimumFractionDigits: 2,
              })
              const formattedEthPrice = newPrices.ethPrice.toLocaleString(undefined, {
                minimumFractionDigits: 2,
                minimumFractionDigits: 2,
              })

              setBtcPrice(formattedBtcPrice)
              setEthPrice(formattedEthPrice)

              // 변동률 초기화
              setBtcChange("+0.00%")
              setEthChange("+0.00%")

              addDebugLog(
                `New round started! Opening price: BTC=${newPrices.btcPrice.toFixed(2)}, ETH=${newPrices.ethPrice.toFixed(2)}`,
              )

              // 라운드 증가 (720회차까지)
              setRound((r) => (r < 720 ? r + 1 : 1))

              // 현재 베팅 ID 초기화
              setCurrentBetId(null)

              // 베팅 카운트 초기화
              setBetCounts({
                "BTC WIN": 0,
                TIE: 0,
                "ETH WIN": 0,
                "BTC ODD": 0,
                "BTC EVEN": 0,
                "ETH ODD": 0,
                "ETH EVEN": 0,
                "BTC OVER": 0,
                "BTC UNDER": 0,
                "ETH OVER": 0,
                "ETH UNDER": 0,
              })
            }, 15000)
          } else {
            // API 호출 실패 시 현재 가격 사용
            setFinalBtcPrice(btcRawPrice)
            setFinalEthPrice(ethRawPrice)

            addDebugLog(
              `Round ended! Final price captured(API failed): BTC=${btcRawPrice.toFixed(2)}, ETH=${ethRawPrice.toFixed(2)}`,
            )

            // 결과 처리
            processResults(btcRawPrice, ethRawPrice)

            // 차트 결과 표시
            setShowChartResults(true)

            // 15초 후 차트 결과 숨기기 및 새 라운드 시작
            setTimeout(async () => {
              setShowChartResults(false)
              setIsBettingClosed(false)
              setIsPriceUpdatePaused(false) // 가격 업데이트 재개

              // 새 라운드 시작 시 새로운 가격 가져오기
              const newPrices = await fetchNewPrices()
              setBtcRawPrice(newPrices.btcPrice)
              setEthRawPrice(newPrices.ethPrice)

              const formattedBtcPrice = newPrices.btcPrice.toLocaleString(undefined, {
                minimumFractionDigits: 2,
                minimumFractionDigits: 2,
              })
              const formattedEthPrice = newPrices.ethPrice.toLocaleString(undefined, {
                minimumFractionDigits: 2,
                minimumFractionDigits: 2,
              })

              setBtcPrice(formattedBtcPrice)
              setEthPrice(formattedEthPrice)

              // 변동률 초기화
              setBtcChange("+0.00%")
              setEthChange("+0.00%")

              addDebugLog(
                `New round started! Opening price: BTC=${newPrices.btcPrice.toFixed(2)}, ETH=${newPrices.ethPrice.toFixed(2)}`,
              )

              // 라운드 증가 (720회차까지)
              setRound((r) => (r < 720 ? r + 1 : 1))

              // 현재 베팅 ID 초기화
              setCurrentBetId(null)

              // 베팅 카운트 초기화
              setBetCounts({
                "BTC WIN": 0,
                TIE: 0,
                "ETH WIN": 0,
                "BTC ODD": 0,
                "BTC EVEN": 0,
                "ETH ODD": 0,
                "ETH EVEN": 0,
                "BTC OVER": 0,
                "BTC UNDER": 0,
                "ETH OVER": 0,
                "ETH UNDER": 0,
              })
            }, 15000)
          }
        })

        return 120 // 타이머 리셋
      }
      return prev - 1
    })
  }

  useEffect(() => {
    // 타이머 초기화
    lastTickTimeRef.current = Date.now()

    // 정확한 타이머를 위해 requestAnimationFrame 사용
    const timerLoop = () => {
      const now = Date.now()
      const elapsed = now - lastTickTimeRef.current

      // 1초마다 타이머 업데이트
      if (elapsed >= 1000) {
        updateTimer()
      }

      // 다음 프레임 요청
      timerRef.current = requestAnimationFrame(timerLoop)
    }

    // 타이머 시작
    timerRef.current = requestAnimationFrame(timerLoop)

    return () => {
      if (timerRef.current) cancelAnimationFrame(timerRef.current)
    }
  }, [btcRawPrice, ethRawPrice])

  // 초기 히스토리 데이터 생성
  useEffect(() => {
    setFullRoundHistory(generateHistoricalData())
  }, [])

  const handleAddAmount = (amount: number) => {
    setBetAmount((prev) => prev + amount)
  }

  const handlePlaceBet = (option: string) => {
    setSelectedOption(option)
  }

  const resetBet = () => {
    setBetAmount(0)
    setSelectedOption(null)
  }

  const confirmBet = () => {
    // 베팅 마감 체크
    if (isBettingClosed) {
      alert("Betting is closed. Please bet in the next round.")
      return
    }

    if (betAmount > 0 && selectedOption) {
      if (wallet >= betAmount) {
        // 베팅 금액 차감
        const newBalance = wallet - betAmount
        setWallet(newBalance)

        // 현재 시간 생성
        const now = new Date()
        const timeStr = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}:${now.getSeconds().toString().padStart(2, "0")}`

        // 고유 ID 생성
        const betId = `bet-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`

        // 베팅 내역 추가
        const newBet: BettingHistory = {
          id: betId,
          round: round,
          option: selectedOption,
          amount: betAmount,
          timestamp: timeStr,
          balanceAfter: newBalance,
        }

        setBettingHistory((prev) => [...prev, newBet])
        setCurrentBetId(betId) // 현재 활성화된 베팅 ID 설정

        // 옵션별 카운트 증가
        setBetCounts((prev) => ({
          ...prev,
          [selectedOption]: prev[selectedOption] + 1,
        }))

        // alert 제거하고 대신 간단한 텍스트 메시지 표시
        const betConfirmationMessage = document.createElement("div")
        betConfirmationMessage.className = "fixed bottom-4 left-0 right-0 mx-auto w-full max-w-md z-50 text-center"
        betConfirmationMessage.innerHTML = `
          <div class="bg-green-900/80 border border-green-500 text-white p-3 rounded-lg shadow-lg inline-block">
            <span class="font-medium">Bet confirmed: ₩${betAmount.toLocaleString()} on ${selectedOption}</span>
          </div>
        `
        document.body.appendChild(betConfirmationMessage)

        // 3초 후 메시지 제거
        setTimeout(() => {
          if (betConfirmationMessage.parentNode) {
            betConfirmationMessage.parentNode.removeChild(betConfirmationMessage)
          }
        }, 3000)

        // 디버깅 로그에 베팅 정보 추가
        addDebugLog(`Bet placed: Option=${selectedOption}, Amount=${betAmount}`)

        // 베팅 정보를 라운드 히스토리에 표시
        const betInfo = {
          round: round,
          result: "PENDING" as "BTC_WIN" | "ETH_WIN" | "TIE", // 타입 캐스팅
          btcLastDigits: Math.floor(btcRawPrice * 100) % 100,
          ethLastDigits: Math.floor(ethRawPrice * 100) % 100,
          timestamp: timeStr,
          betOption: selectedOption,
          betAmount: betAmount,
        }

        // 라운드 결과에 베팅 정보 추가 (최대 50개 유지)
        setRoundResults((prev) => {
          // 이미 같은 라운드의 결과가 있는지 확인
          const existingIndex = prev.findIndex((r) => r.round === round)
          if (existingIndex >= 0) {
            // 기존 결과 업데이트
            const updated = [...prev]
            updated[existingIndex] = {
              ...updated[existingIndex],
              betOption: selectedOption,
              betAmount: betAmount,
            }
            return updated
          } else {
            // 새 결과 추가
            return [...prev, betInfo].slice(-50)
          }
        })
      } else {
        alert("Insufficient balance")
        resetBet()
      }
    } else {
      alert("Please select a betting option and amount")
    }
  }

  // 결과 처리 함수 - 0초 시점의 실제 가격으로 결과 결정
  const processResults = (finalBtcPrice: number, finalEthPrice: number) => {
    // 0초 시점의 실제 가격의 끝 두 자리 추출
    const btcLastTwoDigits = Math.floor(finalBtcPrice * 100) % 100
    const ethLastTwoDigits = Math.floor(finalEthPrice * 100) % 100

    addDebugLog(`Result calculation: BTC last digits=${btcLastTwoDigits}, ETH last digits=${ethLastTwoDigits}`)

    // 비트코인과 이더리움 승패 결정 (끝 두 자리 기준)
    const btcWins = btcLastTwoDigits > ethLastTwoDigits
    // 출목표에 결과 기록
    const tie = btcLastTwoDigits === ethLastTwoDigits
    const resultType = btcWins ? "BTC_WIN" : tie ? "TIE" : "ETH_WIN"
    const now = new Date()
    const timeStr = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`

    setRoundResults((prev) =>
      [
        ...prev,
        {
          round,
          result: resultType,
          btcLastDigits: btcLastTwoDigits,
          ethLastDigits: ethLastTwoDigits,
          timestamp: timeStr,
        },
      ].slice(-50),
    ) // 최대 50개 결과만 저장

    // 전체 라운드 히스토리에도 결과 추가
    setFullRoundHistory((prev) => {
      // 현재 라운드가 이미 있는지 확인
      const existingIndex = prev.findIndex((item) => item.round === round)

      // 결과 표시자 생성
      const indicators: ResultIndicator[] = []

      // E (ETH) 또는 O (BTC)
      indicators.push(resultType === "ETH_WIN" ? "E" : "O")

      // V (TIE) 또는 U (UNDER)
      indicators.push(tie ? "V" : "U")

      // W (WIN) 항상 포함
      indicators.push("W")

      // E (EVEN) 또는 O (ODD)
      indicators.push(btcLastTwoDigits % 2 === 0 ? "E" : "O")

      // U (UNDER) 또는 V (OVER)
      indicators.push(btcLastTwoDigits < 50 ? "U" : "V")

      const newHistoryItem = {
        round,
        btcPrice: finalBtcPrice.toFixed(2),
        ethPrice: finalEthPrice.toFixed(2),
        btcPriceUp: true, // 실제 데이터에서는 이전 가격과 비교해야 함
        ethPriceUp: true, // 실제 데이터에서는 이전 가격과 비교해야 함
        result: resultType,
        indicators,
      }

      if (existingIndex >= 0) {
        // 기존 항목 업데이트
        const updated = [...prev]
        updated[existingIndex] = newHistoryItem
        return updated
      } else {
        // 새 항목 추가 (회차 순서대로 정렬)
        const updated = [...prev, newHistoryItem]
        return updated.sort((a, b) => a.round - b.round)
      }
    })

    // 차트 결과 설정
    setBtcWin(btcWins)
    setEthWin(!btcWins && !tie)

    // 나머지 코드는 그대로 유지...
    // 현재 라운드의 베팅 찾기
    const currentBet = bettingHistory.find((bet) => bet.id === currentBetId)

    if (currentBet) {
      // 베팅 승패 결정
      let won = false
      let multiplier = 1

      const btcIsOdd = btcLastTwoDigits % 2 !== 0
      const ethIsOdd = ethLastTwoDigits % 2 !== 0

      switch (currentBet.option) {
        case "BTC WIN":
          won = btcWins
          multiplier = 1.8
          break
        case "ETH WIN":
          won = !btcWins && !tie
          multiplier = 1.8
          break
        case "TIE":
          won = tie
          multiplier = 10
          break
        case "BTC ODD":
          won = btcIsOdd
          multiplier = 1.9
          break
        case "BTC EVEN":
          won = !btcIsOdd
          multiplier = 1.9
          break
        case "ETH ODD":
          won = ethIsOdd
          multiplier = 1.9
          break
        case "ETH EVEN":
          won = !ethIsOdd
          multiplier = 1.9
          break
        case "BTC UNDER":
          won = btcLastTwoDigits < 50
          multiplier = 1.9
          break
        case "ETH OVER":
          won = ethLastTwoDigits > 50
          multiplier = 1.9
          break
        case "ETH UNDER":
          won = ethLastTwoDigits < 50
          multiplier = 1.9
          break
      }

      // 결과에 따른 잔액 업데이트
      if (won) {
        const winnings = Math.floor(currentBet.amount * multiplier)
        const newBalance = wallet + winnings
        setWallet(newBalance)

        // 베팅 내역 업데이트
        setBettingHistory((prev) =>
          prev.map((bet) =>
            bet.id === currentBetId ? { ...bet, result: "win", winnings: winnings, balanceAfter: newBalance } : bet,
          ),
        )

        setRoundResult({
          status: "win",
          option: currentBet.option,
          amount: currentBet.amount,
          winnings: winnings,
        })

        addDebugLog(`Win! Option=${currentBet.option}, Amount=${currentBet.amount}, Winnings=${winnings}`)

        // 승리 알림 표시
        const alertElement = document.createElement("div")
        alertElement.className = "fixed top-4 left-0 right-0 mx-auto w-full max-w-md z-50 animate-fadeIn"
        alertElement.innerHTML = `
        <div class="bg-green-950 border border-green-500 text-white p-4 rounded-lg shadow-lg flex justify-between items-center">
          <div>
            <div class="text-green-400 font-bold text-lg">Win!</div>
            <div>Bet ₩${currentBet.amount.toLocaleString()} on ${currentBet.option}</div>
          </div>
          <div class="text-yellow-400 font-bold text-xl">+₩${winnings.toLocaleString()}</div>
        </div>
      `
        document.body.appendChild(alertElement)

        // 3초 후 알림 제거
        setTimeout(() => {
          if (alertElement.parentNode) {
            alertElement.parentNode.removeChild(alertElement)
          }
        }, 3000)
      } else {
        // 베팅 내역 업데이트
        setBettingHistory((prev) =>
          prev.map((bet) => (bet.id === currentBetId ? { ...bet, result: "lose", balanceAfter: wallet } : bet)),
        )

        setRoundResult({
          status: "lose",
          option: currentBet.option,
          amount: currentBet.amount,
        })

        addDebugLog(`Loss! Option=${currentBet.option}, Amount=${currentBet.amount}`)

        // 패배 알림 표시
        const alertElement = document.createElement("div")
        alertElement.className = "fixed top-4 left-0 right-0 mx-auto w-full max-w-md z-50 animate-fadeIn"
        alertElement.innerHTML = `
        <div class="bg-red-950 border border-red-500 text-white p-4 rounded-lg shadow-lg flex justify-between items-center">
          <div>
            <div class="text-red-400 font-bold text-lg">Loss!</div>
            <div>Bet ₩${currentBet.amount.toLocaleString()} on ${currentBet.option}</div>
          </div>
          <div class="text-red-400 font-bold text-xl">-₩${currentBet.amount.toLocaleString()}</div>
        </div>
      `
        document.body.appendChild(alertElement)

        // 3초 후 알림 제거
        setTimeout(() => {
          if (alertElement.parentNode) {
            alertElement.parentNode.removeChild(alertElement)
          }
        }, 3000)
      }

      // 베팅 초기화
      setBetAmount(0)
      setSelectedOption(null)
    }
  }

  // 베팅 옵션 아이콘
  const BetOptionIcon = ({ option }: { option: string }) => {
    if (option.includes("BTC")) {
      return (
        <div className="w-5 h-5 rounded-full bg-[#f7931a] flex items-center justify-center">
          <span className="text-white text-xs font-bold">₿</span>
        </div>
      )
    } else if (option.includes("ETH")) {
      return (
        <div className="w-5 h-5 rounded-full bg-[#627EEA] flex items-center justify-center">
          <span className="text-white text-xs font-bold">Ξ</span>
        </div>
      )
    } else {
      return (
        <div className="w-5 h-5 rounded-full bg-[#f0b90b] flex items-center justify-center">
          <span className="text-white text-xs font-bold">T</span>
        </div>
      )
    }
  }

  // 라운드 결과가 나올 때 가상 베팅 결과도 업데이트
  useEffect(() => {
    // 결과가 표시될 때 (showChartResults가 true로 변경될 때)
    if (showChartResults && finalBtcPrice > 0 && finalEthPrice > 0) {
      // 가상 베팅 결과 업데이트
      const btcLastTwoDigits = Math.floor(finalBtcPrice * 100) % 100
      const ethLastTwoDigits = Math.floor(finalEthPrice * 100) % 100
      const btcWins = btcLastTwoDigits > ethLastTwoDigits
      const tie = btcLastTwoDigits === ethLastTwoDigits
      const btcIsOdd = btcLastTwoDigits % 2 !== 0
      const ethIsOdd = ethLastTwoDigits % 2 !== 0

      // 각 가상 베팅의 결과 계산 (실제 결과와 동일한 로직)
      setVirtualBets((prev) =>
        prev.map((bet) => {
          // 이미 결과가 있는 베팅은 건너뛰기
          if (bet.hasOwnProperty("result")) return bet

          // 베팅 결과 계산
          let won = false

          switch (bet.option) {
            case "BTC WIN":
              won = btcWins
              break
            case "ETH WIN":
              won = !btcWins && !tie
              break
            case "TIE":
              won = tie
              break
            case "BTC ODD":
              won = btcIsOdd
              break
            case "BTC EVEN":
              won = !btcIsOdd
              break
            case "ETH ODD":
              won = ethIsOdd
              break
            case "ETH EVEN":
              won = !ethIsOdd
              break
            case "BTC UNDER":
              won = btcLastTwoDigits < 50
              break
            case "BTC OVER":
              won = btcLastTwoDigits >= 50
              break
            case "ETH OVER":
              won = ethLastTwoDigits > 50
              break
            case "ETH UNDER":
              won = ethLastTwoDigits <= 50
              break
          }

          // 결과 추가
          return {
            ...bet,
            result: won ? "win" : "lose",
          }
        }),
      )
    }

    // 새 라운드 시작 시 이전 베팅 결과 초기화
    if (seconds === 120) {
      setVirtualBets([])
    }
  }, [showChartResults, finalBtcPrice, finalEthPrice, seconds])

  // 금액 포맷팅 함수
  const formatAmount = (amount: number) => {
    if (amount >= 1000000) {
      return `${(amount / 1000000).toFixed(1)}M`
    } else if (amount >= 10000) {
      return `${(amount / 10000).toFixed(0)}만`
    } else {
      return amount.toLocaleString()
    }
  }

  // 히스토리 데이터 생성 함수
  const generateHistoricalData = () => {
    const history = []

    // 1회차부터 720회차까지 순서대로 생성
    for (let i = 1; i <= 720; i++) {
      // 랜덤 가격 생성
      const btcBase = 95000 + Math.random() * 1000
      const ethBase = 1830 + Math.random() * 10

      // 가격 변동 방향
      const btcPriceUp = Math.random() > 0.5
      const ethPriceUp = Math.random() > 0.5

      // 끝자리 숫자 생성
      const btcLastDigits = Math.floor(Math.random() * 100)
      const ethLastDigits = Math.floor(Math.random() * 100)

      // 결과 결정
      let result: ResultType
      if (btcLastDigits > ethLastDigits) {
        result = "BTC_WIN"
      } else if (btcLastDigits < ethLastDigits) {
        result = "ETH_WIN"
      } else {
        result = "TIE"
      }

      // 결과 표시자 생성
      const indicators: ResultIndicator[] = []

      // E (ETH) 또는 O (BTC)
      indicators.push(result === "ETH_WIN" ? "E" : "O")

      // V (TIE) 또는 U (UNDER)
      indicators.push(Math.random() > 0.7 ? "V" : "U")

      // W (WIN) 항상 포함
      indicators.push("W")

      // E (EVEN) 또는 O (ODD)
      indicators.push(Math.random() > 0.5 ? "E" : "O")

      // U (UNDER) 또는 O (OVER)
      indicators.push(Math.random() > 0.5 ? "U" : "V")

      history.push({
        round: i,
        btcPrice: btcBase.toFixed(2),
        ethPrice: ethBase.toFixed(2),
        btcPriceUp,
        ethPriceUp,
        result,
        indicators,
      })
    }

    return history
  }

  // 배당률을 가져오는 함수
  const getMultiplier = (option: string): number => {
    switch (option) {
      case "TIE":
        return 12
      case "BTC WIN":
      case "ETH WIN":
        return 1.95
      case "BTC ODD":
      case "BTC EVEN":
      case "ETH ODD":
      case "ETH EVEN":
      case "BTC OVER":
      case "BTC UNDER":
      case "ETH OVER":
      case "ETH UNDER":
        return 1.95
      default:
        return 0
    }
  }

  const handleOptionSelect = (option: string) => {
    setSelectedOption(option)
    // 옵션만 선택하고 금액은 그대로 유지
  }

  const handleAmountChange = (amount: number) => {
    setBetAmount((prev) => prev + amount)
    // 금액만 추가하고 옵션은 그대로 유지
  }

  return (
    <div className="min-h-screen bg-[#0e1117] flex flex-col">
      {/* 상단 헤더 영역 - 차트 결과값과 동일한 큰 숫자로 표시 */}
      {/* 기존 코드:
      <div className="w-full bg-[#131722] border-b border-[#2a2e39] py-2 sm:py-3">
        <div className="max-w-full mx-auto px-2 sm:px-4">
          {/* 언어 선택기를 상단에 별도로 배치 */}
      {/*<div className="flex justify-end mb-2">
            <LanguageSelector />
          </div>*/}
      {/* 아래 코드로 변경: */}
      <div className="w-full relative border-b border-[#2a2e39] py-2 sm:py-3 overflow-hidden">
        {/* 고급스러운 배경 효과 */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0e17] via-[#131722] to-[#0a0e17] z-0"></div>

        {/* 미묘한 패턴 오버레이 */}
        <div className="absolute inset-0 opacity-5 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCI+CjxyZWN0IHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgZmlsbD0ibm9uZSIvPgo8cGF0aCBkPSJNMCAwTDYwIDYwTTYwIDBMMCAzME0zMCAwTDYwIDMwTTAgMzBMMzAgNjBNMCAxNUwxNSAwTTQ1IDYwTDYwIDQ1TTAgNDVMNDUgME0xNSA2MEw2MCAxNSIgc3Ryb2tlPSIjZmZmIiBzdHJva2Utd2lkdGg9IjAuNSIgc3Ryb2tlLW9wYWNpdHk9IjAuMSIvPgo8L3N2Zz4=')] z-10"></div>

        {/* 상단 그라데이션 라인 */}
        <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#58a6ff]/50 to-transparent z-20"></div>

        {/* 움직이는 그라데이션 효과 */}
        <div className="absolute inset-0 opacity-10 bg-gradient-to-r from-[#f7931a]/0 via-[#f7931a]/30 to-[#f7931a]/0 animate-gradient-x z-10"></div>
        <div className="absolute inset-0 opacity-10 bg-gradient-to-r from-[#627EEA]/0 via-[#627EEA]/20 to-[#627EEA]/0 animate-gradient-y z-10"></div>

        {/* 반짝이는 입자 효과 */}
        <div className="absolute inset-0 stars-container z-20"></div>

        {/* 실제 콘텐츠 */}
        <div className="max-w-full mx-auto px-2 sm:px-4 relative z-30">
          {/* 로고와 언어 선택기를 함께 배치 */}
          <div className="flex justify-between items-center mb-3">
            <BitMarketLogo size="md" />
            <LanguageSelector />
          </div>
          <div className="flex flex-row items-center justify-center gap-2 md:gap-6 relative">
            {/* 비트코인 가격 */}
            <div className="flex flex-col items-center mr-2 md:mr-4">
              <div className="flex items-center mb-1">
                <BitcoinLogo />
                <span className="text-white text-sm md:text-xl lg:text-2xl font-medium ml-1">BTC</span>
              </div>
              <div className="flex flex-col items-center">
                <span
                  className={`text-[#ff5b5b] text-lg sm:text-2xl md:text-4xl lg:text-5xl font-bold tracking-tighter price-display ${btcPriceChanged ? "price-change" : ""}`}
                >
                  {btcPrice}
                </span>
                <span className="text-[#ff5b5b] text-xs sm:text-sm">{btcChange}</span>
              </div>
            </div>

            {/* 타이머 - 중앙에 배치 */}
            <div className="relative mx-2 md:mx-4">
              <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-28 md:h-28 rounded-full flex flex-col items-center justify-center bg-[#131722]/80 border border-[#2a2e39] relative overflow-hidden shadow-[0_0_15px_rgba(0,0,0,0.3)]">
                <div className="absolute inset-0 bg-[#0e1117]/80 rounded-full"></div>
                <div className="absolute inset-0 bg-gradient-to-b from-[#1a1f2c]/50 to-transparent rounded-full"></div>

                {/* 타이머 내부 글로우 효과 */}
                <div className="absolute inset-0 rounded-full bg-gradient-to-r from-[#5de0e6]/0 via-[#5de0e6]/10 to-[#5de0e6]/0 animate-pulse-slow"></div>

                {/* 타이머 내용 */}
                <div className="relative z-10 flex flex-col items-center">
                  <span className="text-[#5de0e6] text-[8px] sm:text-xs font-medium">{timerStatus}</span>
                  <span className="text-[#5de0e6] text-xl sm:text-3xl md:text-4xl font-bold">{seconds}</span>
                  <div className="text-white text-[8px] sm:text-[10px] mt-0">
                    {t(language, "gameUI.round")} <span className="text-white">{round}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* 이더리움 가격 */}
            <div className="flex flex-col items-center ml-2 md:ml-4">
              <div className="flex items-center mb-1">
                <span className="text-white text-sm md:text-xl lg:text-2xl font-medium mr-1">ETH</span>
                <EthereumLogo />
              </div>
              <div className="flex flex-col items-center">
                <span
                  className={`text-[#4bdb4b] text-lg sm:text-2xl md:text-4xl lg:text-5xl font-bold tracking-tighter price-display ${ethPriceChanged ? "price-change" : ""}`}
                >
                  {ethPrice}
                </span>
                <span className="text-[#4bdb4b] text-xs sm:text-sm">{ethChange}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 실시간 회원 수 및 베팅 정보 표시 */}
      <div className="w-full bg-gradient-to-r from-[#0f1923] via-[#162231] to-[#0f1923] py-1 border-b border-[#2a2e39] flex items-center justify-between px-4">
        <div className="flex items-center">
          <Users className="h-4 w-4 text-green-400 mr-2" />
          <span className="text-green-400 font-medium">{activeUsers}</span>
          <span className="text-gray-400 text-sm ml-1">{t(language, "gameUI.usersOnline")}</span>
        </div>
        <div className="text-gray-400 text-sm">
          <span className="text-yellow-400 font-medium">
            ₩{(Object.values(betCounts).reduce((a, b) => a + b, 0) * 1500000).toLocaleString()}
          </span>
          <span className="ml-1">{t(language, "gameUI.bettingInProgress")}</span>
        </div>
      </div>

      {/* 베팅 옵션 스크롤 바 */}
      <div className="w-full bg-black py-2 overflow-hidden border-b border-[#2a2e39]">
        <div className="ticker-container">
          <div className="ticker-wrapper">
            <div className="ticker-item">
              {Object.entries(betCounts).map(([option, count], index) => (
                <div key={index} className="flex items-center mx-4 whitespace-nowrap">
                  <BetOptionIcon option={option} />
                  <span
                    className={`ml-1 text-sm font-medium ${
                      option.includes("BTC")
                        ? "text-[#ff5b5b]"
                        : option.includes("ETH")
                          ? "text-[#4bdb4b]"
                          : "text-[#f0b90b]"
                    }`}
                  >
                    {option.split(" ")[1]}s
                  </span>
                  <span className="mx-1 text-white text-sm">{count}</span>
                  <span className="text-gray-500 text-sm">{Math.floor(Math.random() * 5)}</span>
                  <span className="ml-2 text-yellow-400 font-medium">
                    ₩{formatAmount(500000 + Math.floor(Math.random() * 7300000))}
                  </span>
                </div>
              ))}
            </div>
            <div className="ticker-item">
              {Object.entries(betCounts).map(([option, count], index) => (
                <div key={`repeat-${index}`} className="flex items-center mx-4 whitespace-nowrap">
                  <BetOptionIcon option={option} />
                  <span
                    className={`ml-1 text-sm font-medium ${
                      option.includes("BTC")
                        ? "text-[#ff5b5b]"
                        : option.includes("ETH")
                          ? "text-[#4bdb4b]"
                          : "text-[#f0b90b]"
                    }`}
                  >
                    {option.split(" ")[1]}s
                  </span>
                  <span className="mx-1 text-white text-sm">{count}</span>
                  <span className="text-gray-500 text-sm">{Math.floor(Math.random() * 5)}</span>
                  <span className="ml-2 text-yellow-400 font-medium">
                    ₩{formatAmount(500000 + Math.floor(Math.random() * 7300000))}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 차트 영역 - 실제 트레이딩뷰 차트 */}
      <div className="w-full bg-[#131722] py-0 relative">
        <div className="flex flex-col sm:flex-row">
          {/* BTC Chart */}
          <div className="w-full sm:w-1/2 h-[200px] sm:h-[300px] md:h-[400px] relative">
            <iframe
              ref={btcChartRef}
              id="btc_chart_iframe"
              src="https://s.tradingview.com/widgetembed/?frameElementId=tv_chart_container&symbol=BINANCE:BTCUSDT&interval=1&hidesidetoolbar=0&symboledit=0&saveimage=0&toolbarbg=131722&studies=[]&theme=dark&style=1&timezone=exchange&withdateranges=1&studies_overrides={}&overrides={}&enabled_features=[]&disabled_features=[]&locale=en&utm_source=&utm_medium=widget&utm_campaign=chart"
              className="w-full h-full border-none"
              title="Bitcoin Chart"
              style={{ backgroundColor: "#131722" }}
              allowTransparency={true}
              sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
            />
            {/* BTC Result Overlay */}
            {showChartResults && (
              <div
                className={`absolute inset-0 flex items-center justify-center ${btcWin ? "bg-[#26a69a]/30" : "bg-[#ef5350]/30"} backdrop-blur-sm`}
              >
                <div
                  className={`rounded-lg px-4 sm:px-16 py-4 sm:py-8 ${btcWin ? "bg-[#26a69a]/80" : "bg-[#ef5350]/80"} shadow-2xl`}
                >
                  <div className="text-xl sm:text-2xl font-bold text-white text-center mb-2">
                    {btcWin ? "WIN" : "LOSE"}
                  </div>
                  <div className="text-3xl sm:text-5xl font-bold text-white text-center">
                    {finalBtcPrice.toFixed(2)}
                  </div>
                  <div className="text-lg sm:text-xl font-bold text-white text-center mt-2">
                    Last Digits: {Math.floor(finalBtcPrice * 100) % 100}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* ETH Chart */}
          <div className="w-full sm:w-1/2 h-[200px] sm:h-[300px] md:h-[400px] relative">
            <iframe
              ref={ethChartRef}
              id="eth_chart_iframe"
              src="https://s.tradingview.com/widgetembed/?frameElementId=tv_chart_container&symbol=BINANCE:ETHUSDT&interval=1&hidesidetoolbar=0&symboledit=0&saveimage=0&toolbarbg=131722&studies=[]&theme=dark&style=1&timezone=exchange&withdateranges=1&studies_overrides={}&overrides={}&enabled_features=[]&disabled_features=[]&locale=en&utm_source=&utm_medium=widget&utm_campaign=chart"
              className="w-full h-full border-none"
              title="Ethereum Chart"
              style={{ backgroundColor: "#131722" }}
              allowTransparency={true}
              sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
            />
            {/* ETH Result Overlay */}
            {showChartResults && (
              <div
                className={`absolute inset-0 flex items-center justify-center ${ethWin ? "bg-[#26a69a]/30" : "bg-[#ef5350]/30"} backdrop-blur-sm`}
              >
                <div
                  className={`rounded-lg px-4 sm:px-16 py-4 sm:py-8 ${ethWin ? "bg-[#26a69a]/80" : "bg-[#ef5350]/80"} shadow-2xl`}
                >
                  <div className="text-xl sm:text-2xl font-bold text-white text-center mb-2">
                    {ethWin ? "WIN" : "LOSE"}
                  </div>
                  <div className="text-3xl sm:text-5xl font-bold text-white text-center">
                    {finalEthPrice.toFixed(2)}
                  </div>
                  <div className="text-lg sm:text-xl font-bold text-white text-center mt-2">
                    Last Digits: {Math.floor(finalEthPrice * 100) % 100}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 베팅 마감 시 로딩 오버레이 - 차트 중앙에 하나만 표시 */}
        {isBettingClosed && !showChartResults && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            {/* 전체 차트 영역에 블러 효과 적용 */}
            <div className="absolute inset-0 bg-black/30 backdrop-blur-sm"></div>

            {/* 로딩 메시지 */}
            <div className="relative z-10 px-16 py-10 bg-gradient-to-r from-[#d4af37]/20 via-[#f0ca45]/30 to-[#d4af37]/20 backdrop-blur-md rounded-xl border border-[#f0ca45]/40 shadow-[0_0_30px_rgba(212,175,55,0.3)] transform transition-all duration-500">
              <div className="flex flex-col items-center gap-6">
                {/* 로딩 스피너 */}
                <div className="w-16 h-16 rounded-full border-4 border-[#f0ca45]/30 border-t-[#f0ca45] animate-spin"></div>

                {/* 로딩 텍스트 */}
                <div className="text-center">
                  <div
                    className="text-white text-3xl font-bold tracking-wider"
                    style={{ fontFamily: "'Orbitron', sans-serif" }}
                  >
                    Loading Result Data
                  </div>
                  <div className="text-[#f0ca45] text-sm mt-3">Please wait...</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 게임 UI 영역 */}
      <div className="flex-1 w-full mx-auto px-2 sm:px-4 py-4 sm:py-6">
        {/* 고급스러운 마켓 데이터 패널 */}
        <div className="mb-4 bg-gradient-to-r from-[#0d1117] via-[#131722] to-[#0d1117] rounded-lg border border-[#30363d] shadow-lg overflow-hidden">
          {/* 헤더 영역 */}
          <div className="bg-gradient-to-r from-[#161b22] via-[#1c2333] to-[#161b22] px-4 py-3 border-b border-[#30363d] flex items-center justify-between">
            <div className="font-bold text-[#58a6ff] flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z"
                />
              </svg>
              <span className="text-lg tracking-wide">MARKET DATA</span>
            </div>
            <div className="text-xs text-[#8b949e] flex items-center">
              <span className="inline-block h-2 w-2 rounded-full bg-green-500 mr-1.5 animate-pulse"></span>
              Live Updates
            </div>
          </div>

          {/* 탭 네비게이션 */}
          <div className="flex border-b border-[#30363d] bg-[#0d1117]/80">
            <button className="px-4 py-2 text-sm font-medium text-white border-b-2 border-[#58a6ff]">Price</button>
          </div>

          {/* 모바일 최적화된 마켓 데이터 표시 */}
          <div className="p-0 h-24 sm:h-32 overflow-y-auto custom-scrollbar">
            {/* 데스크탑 뷰 - 테이블 형식 */}
            <div className="hidden sm:block">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-[#0d1117] z-10">
                  <tr className="text-xs text-[#8b949e] border-b border-[#30363d]">
                    <th className="text-left py-2 px-3 font-medium">Time</th>
                    <th className="text-left py-2 px-3 font-medium">Status</th>
                    <th className="text-left py-2 px-3 font-medium">BTC</th>
                    <th className="text-left py-2 px-3 font-medium">ETH</th>
                    <th className="text-left py-2 px-3 font-medium">Details</th>
                  </tr>
                </thead>
                <tbody>
                  {getFilteredLogs("price", debugLog).map((log, i) => {
                    const entry = parseLogEntry(log)

                    return (
                      <tr
                        key={i}
                        className="border-b border-[#30363d]/10 hover:bg-[#161b22]/50 transition-colors duration-150"
                      >
                        <td className="py-2 px-3 text-gray-400 font-mono text-xs">{entry.timestamp}</td>
                        <td className="py-2 px-3">
                          <div
                            className={`inline-flex items-center px-2 py-1 rounded-full ${entry.statusBg} ${entry.statusColor}`}
                          >
                            <span className="mr-1">{entry.statusIcon}</span>
                            <span className="font-medium text-xs">{entry.status}</span>
                          </div>
                        </td>
                        <td className="py-2 px-3">
                          {entry.btcPrice && (
                            <div className="flex items-center">
                              <span className="font-mono text-white bg-[#1a1d24] px-2 py-0.5 rounded">
                                {entry.btcPrice}
                              </span>
                              {entry.btcTrend !== 0 && (
                                <span className="ml-1">
                                  {entry.btcTrend > 0 ? (
                                    <ArrowUp className="h-3 w-3 text-green-500" />
                                  ) : (
                                    <ArrowDown className="h-3 w-3 text-red-500" />
                                  )}
                                </span>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="py-2 px-3">
                          {entry.ethPrice && (
                            <div className="flex items-center">
                              <span className="font-mono text-white bg-[#1a1d24] px-2 py-0.5 rounded">
                                {entry.ethPrice}
                              </span>
                              {entry.ethTrend !== 0 && (
                                <span className="ml-1">
                                  {entry.ethTrend > 0 ? (
                                    <ArrowUp className="h-3 w-3 text-green-500" />
                                  ) : (
                                    <ArrowDown className="h-3 w-3 text-red-500" />
                                  )}
                                </span>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="py-2 px-3 text-gray-300">{entry.details}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            {/* 모바일 뷰 - 카드 형식 */}
            <div className="block sm:hidden">
              {getFilteredLogs("price", debugLog).map((log, i) => {
                const entry = parseLogEntry(log)

                return (
                  <div key={i} className="border-b border-[#30363d]/10 p-2">
                    <div className="flex justify-between items-center mb-1">
                      <div className="text-gray-400 font-mono text-xs">{entry.timestamp}</div>
                      <div
                        className={`inline-flex items-center px-2 py-1 rounded-full ${entry.statusBg} ${entry.statusColor}`}
                      >
                        <span className="mr-1">{entry.statusIcon}</span>
                        <span className="font-medium text-xs">{entry.status}</span>
                      </div>
                    </div>

                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <span className="text-xs text-gray-400 mr-2">BTC:</span>
                        {entry.btcPrice && (
                          <span className="font-mono text-white bg-[#1a1d24] px-2 py-0.5 rounded text-xs">
                            {entry.btcPrice}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center">
                        <span className="text-xs text-gray-400 mr-2">ETH:</span>
                        {entry.ethPrice && (
                          <span className="font-mono text-white bg-[#1a1d24] px-2 py-0.5 rounded text-xs">
                            {entry.ethPrice}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* 실시간 베팅 활동 패널 - 마켓 데이터 패널에서 분리 */}
        <div className="mb-4 bg-gradient-to-r from-[#0d1117] via-[#131722] to-[#0d1117] rounded-lg border border-[#30363d] shadow-lg overflow-hidden">
          {/* 헤더 영역 */}
          <div className="bg-gradient-to-r from-[#161b22] via-[#1c2333] to-[#161b22] px-4 py-3 border-b border-[#30363d] flex items-center justify-between">
            <div className="font-bold text-[#58a6ff] flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                />
              </svg>
              <span className="text-lg tracking-wide">LIVE BETTING ACTIVITY</span>
            </div>
            <div className="text-xs text-[#8b949e] flex items-center">
              <span className="inline-block h-2 w-2 rounded-full bg-green-500 mr-1.5 animate-pulse"></span>
              Real-time Updates
            </div>
          </div>

          {/* 실시간 베팅 활동 테이블 */}
          <div className="p-0 h-24 sm:h-32 overflow-y-auto overflow-x-auto custom-scrollbar">
            {/* 데스크탑 뷰 - 테이블 형식 */}
            <div className="hidden sm:block min-w-[600px]">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-[#0d1117] z-10">
                  <tr className="text-xs text-[#8b949e] border-b border-[#30363d]">
                    <th className="text-left py-2 px-3 font-medium">Time</th>
                    <th className="text-left py-2 px-3 font-medium">User</th>
                    <th className="text-left py-2 px-3 font-medium">Option</th>
                    <th className="text-left py-2 px-3 font-medium">Amount</th>
                    <th className="text-left py-2 px-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="relative">
                  {/* 실시간 베팅 활동 표시 */}
                  {virtualBets.slice(-10).map((bet, index) => {
                    // 랜덤 사용자 이름 생성 (베팅마다 고정된 사용자 이름 사용)
                    const username = `user${Number.parseInt(bet.id.split("-")[2].substring(0, 4), 36)}`
                    // 베팅 상태 - 결과가 있으면 해당 결과 사용, 없으면 진행 중
                    const status = bet.result || "pending"

                    return (
                      <tr
                        key={bet.id}
                        className={`border-b border-[#30363d]/10 hover:bg-[#161b22]/50 transition-colors duration-150 animate-fadeIn ${
                          status === "win" ? "bg-green-950/20" : status === "lose" ? "bg-red-950/20" : ""
                        }`}
                      >
                        <td className="py-2 px-3 text-gray-400 font-mono text-xs">{bet.timestamp}</td>
                        <td className="py-2 px-3">
                          <div className="flex items-center">
                            <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold mr-2">
                              {username.substring(0, 1).toUpperCase()}
                            </div>
                            <span className="text-gray-300">{username}</span>
                          </div>
                        </td>
                        <td className="py-2 px-3">
                          <div className="flex items-center">
                            <BetOptionIcon option={bet.option} />
                            <span className="ml-2 text-white font-medium">{bet.option}</span>
                          </div>
                        </td>
                        <td className="py-2 px-3 text-yellow-400 font-medium">₩{bet.amount.toLocaleString()}</td>
                        <td className="py-2 px-3">
                          {status === "win" ? (
                            <div className="inline-flex items-center px-2 py-1 rounded-full bg-green-900/20 text-green-400">
                              <CheckCircle className="h-4 w-4 mr-1" />
                              <span className="font-medium text-xs">Win</span>
                            </div>
                          ) : status === "lose" ? (
                            <div className="inline-flex items-center px-2 py-1 rounded-full bg-red-900/20 text-red-400">
                              <XCircle className="h-4 w-4 mr-1" />
                              <span className="font-medium text-xs">Loss</span>
                            </div>
                          ) : (
                            <div className="inline-flex items-center px-2 py-1 rounded-full bg-blue-900/20 text-blue-400">
                              <Clock className="h-4 w-4 mr-1" />
                              <span className="font-medium text-xs">Pending</span>
                            </div>
                          )}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            {/* 모바일 뷰 - 카드 형식 */}
            <div className="block sm:hidden">
              {virtualBets.slice(-10).map((bet, index) => {
                const username = `user${Number.parseInt(bet.id.split("-")[2].substring(0, 4), 36)}`
                const status = bet.result || "pending"

                return (
                  <div
                    key={bet.id}
                    className={`p-2 border-b border-[#30363d]/10 animate-fadeIn ${
                      status === "win" ? "bg-green-950/20" : status === "lose" ? "bg-red-950/20" : ""
                    }`}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <div className="text-gray-400 font-mono text-xs">{bet.timestamp}</div>
                      {status === "win" ? (
                        <div className="inline-flex items-center px-2 py-1 rounded-full bg-green-900/20 text-green-400">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          <span className="font-medium text-xs">Win</span>
                        </div>
                      ) : status === "lose" ? (
                        <div className="inline-flex items-center px-2 py-1 rounded-full bg-red-900/20 text-red-400">
                          <XCircle className="h-3 w-3 mr-1" />
                          <span className="font-medium text-xs">Loss</span>
                        </div>
                      ) : (
                        <div className="inline-flex items-center px-2 py-1 rounded-full bg-blue-900/20 text-blue-400">
                          <Clock className="h-3 w-3 mr-1" />
                          <span className="font-medium text-xs">Pending</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center mb-1">
                      <div className="w-5 h-5 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold mr-2">
                        {username.substring(0, 1).toUpperCase()}
                      </div>
                      <span className="text-gray-300 text-xs">{username}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <BetOptionIcon option={bet.option} />
                        <span className="ml-1 text-white text-xs">{bet.option}</span>
                      </div>
                      <span className="text-yellow-400 font-medium text-xs">₩{bet.amount.toLocaleString()}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* 사용자 베팅 내역 패널 */}
        <div className="mb-4 bg-gradient-to-r from-[#0d1117] via-[#131722] to-[#0d1117] rounded-lg border border-[#30363d] shadow-lg overflow-hidden">
          {/* 헤더 영역 */}
          <div className="bg-gradient-to-r from-[#161b22] via-[#1c2333] to-[#161b22] px-4 py-3 border-b border-[#30363d] flex items-center justify-between">
            <div className="font-bold text-[#58a6ff] flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 mr-2"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                />
              </svg>
              <span className="text-lg tracking-wide">YOUR BETTING HISTORY</span>
            </div>
            <div className="text-xs text-[#8b949e]">{bettingHistory.length} bets placed</div>
          </div>

          {/* 베팅 내역 테이블 */}
          <div className="p-0 h-24 sm:h-32 overflow-y-auto overflow-x-auto custom-scrollbar">
            {bettingHistory.length > 0 ? (
              <>
                {/* 데스크탑 뷰 - 테이블 형식 */}
                <div className="hidden sm:block min-w-[600px]">
                  <table className="w-full text-sm">
                    <thead className="sticky top-0 bg-[#0d1117] z-10">
                      <tr className="text-xs text-[#8b949e] border-b border-[#30363d]">
                        <th className="text-left py-2 px-3 font-medium">Round</th>
                        <th className="text-left py-2 px-3 font-medium">Time</th>
                        <th className="text-left py-2 px-3 font-medium">Option</th>
                        <th className="text-left py-2 px-3 font-medium">Amount</th>
                        <th className="text-left py-2 px-3 font-medium">Result</th>
                        <th className="text-right py-2 px-3 font-medium">Balance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {bettingHistory.map((bet) => (
                        <tr
                          key={bet.id}
                          className={`border-b border-[#30363d]/10 hover:bg-[#161b22]/50 transition-colors duration-150 ${
                            bet.result === "win" ? "bg-green-950/30" : bet.result === "lose" ? "bg-red-950/30" : ""
                          }`}
                        >
                          <td className="py-2 px-3 text-gray-300">{bet.round}</td>
                          <td className="py-2 px-3 text-gray-400 font-mono text-xs">{bet.timestamp}</td>
                          <td className="py-2 px-3 text-white font-medium">{bet.option}</td>
                          <td className="py-2 px-3 text-gray-300">₩{bet.amount.toLocaleString()}</td>
                          <td className="py-2 px-3">
                            {bet.result === "win" ? (
                              <div className="inline-flex items-center px-2 py-1 rounded-full bg-green-900/20 text-green-400">
                                <CheckCircle className="h-4 w-4 mr-1" />
                                <span className="font-medium text-xs">Win! +₩{bet.winnings?.toLocaleString()}</span>
                              </div>
                            ) : bet.result === "lose" ? (
                              <div className="inline-flex items-center px-2 py-1 rounded-full bg-red-900/20 text-red-400">
                                <XCircle className="h-4 w-4 mr-1" />
                                <span className="font-medium text-xs">Loss</span>
                              </div>
                            ) : (
                              <div className="inline-flex items-center px-2 py-1 rounded-full bg-blue-900/20 text-blue-400">
                                <Clock className="h-4 w-4 mr-1" />
                                <span className="font-medium text-xs">In Progress</span>
                              </div>
                            )}
                          </td>
                          <td className="py-2 px-3 text-right">
                            {bet.balanceAfter ? (
                              <span className="font-mono text-white bg-[#1a1d24] px-2 py-0.5 rounded">
                                ₩{bet.balanceAfter.toLocaleString()}
                              </span>
                            ) : (
                              "-"
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* 모바일 뷰 - 카드 형식 */}
                <div className="block sm:hidden">
                  {bettingHistory.map((bet) => (
                    <div
                      key={bet.id}
                      className={`p-2 border-b border-[#30363d]/10 ${
                        bet.result === "win" ? "bg-green-950/30" : bet.result === "lose" ? "bg-red-950/30" : ""
                      }`}
                    >
                      <div className="flex justify-between items-center mb-1">
                        <div className="flex items-center">
                          <span className="text-gray-400 text-xs mr-2">Round:</span>
                          <span className="text-gray-300 text-xs">{bet.round}</span>
                        </div>
                        <div className="text-gray-400 font-mono text-xs">{bet.timestamp}</div>
                      </div>

                      <div className="flex justify-between items-center mb-1">
                        <div className="flex items-center">
                          <BetOptionIcon option={bet.option} />
                          <span className="ml-1 text-white text-xs">{bet.option}</span>
                        </div>
                        <span className="text-gray-300 text-xs">₩{bet.amount.toLocaleString()}</span>
                      </div>

                      <div className="flex justify-between items-center">
                        <div>
                          {bet.result === "win" ? (
                            <div className="inline-flex items-center px-2 py-1 rounded-full bg-green-900/20 text-green-400">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              <span className="font-medium text-xs">Win! +₩{bet.winnings?.toLocaleString()}</span>
                            </div>
                          ) : bet.result === "lose" ? (
                            <div className="inline-flex items-center px-2 py-1 rounded-full bg-red-900/20 text-red-400">
                              <XCircle className="h-3 w-3 mr-1" />
                              <span className="font-medium text-xs">Loss</span>
                            </div>
                          ) : (
                            <div className="inline-flex items-center px-2 py-1 rounded-full bg-blue-900/20 text-blue-400">
                              <Clock className="h-3 w-3 mr-1" />
                              <span className="font-medium text-xs">In Progress</span>
                            </div>
                          )}
                        </div>
                        {bet.balanceAfter && (
                          <span className="font-mono text-white bg-[#1a1d24] px-2 py-0.5 rounded text-xs">
                            ₩{bet.balanceAfter.toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full py-6 text-center">
                <div className="text-gray-500 mb-2">No betting history yet</div>
                <div className="text-sm text-gray-400">Your betting history will appear here</div>
              </div>
            )}
          </div>
        </div>

        <style jsx>
          {`
          .custom-scrollbar::-webkit-scrollbar {
            width: 8px;
            height: 8px;
          }
          .custom-scrollbar::-webkit-scrollbar-track {
            background: #0d1117;
            border-radius: 4px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #30363d;
            border-radius: 4px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #58a6ff;
          }
          .custom-scrollbar::-webkit-scrollbar-corner {
            background: #0d1117;
          }
          
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          
          .animate-fadeIn {
            animation: fadeIn 0.3s ease-out forwards;
          }
          
          .ticker-container {
            width: 100%;
            overflow: hidden;
            position: relative;
          }

          .ticker-wrapper {
            display: flex;
            width: 100%;
            position: relative;
          }

          .ticker-item {
            display: flex;
            white-space: nowrap;
            padding-right: 0;
            animation: ticker 120s linear infinite;
            will-change: transform;
          }

          @keyframes ticker {
            0% { transform: translateX(0); }
            100% { transform: translateX(-100%); }
          }
          
          @media (max-width: 640px) {
            .price-display {
              font-size: 1.5rem;
            }
            
            .ticker-container {
              height: 30px;
              overflow: hidden;
            }
            
            .ticker-item {
              animation-duration: 60s;
            }
          }

          @keyframes gradient-x {
            0%, 100% {
              transform: translateX(-50%);
            }
            50% {
              transform: translateX(50%);
            }
          }

          @keyframes gradient-y {
            0%, 100% {
              transform: translateY(-50%);
            }
            50% {
              transform: translateY(50%);
            }
          }

          @keyframes pulse-slow {
            0%, 100% {
              opacity: 0.1;
            }
            50% {
              opacity: 0.3;
            }
          }

          .animate-gradient-x {
            animation: gradient-x 15s ease infinite;
          }

          .animate-gradient-y {
            animation: gradient-y 15s ease infinite;
          }

          .animate-pulse-slow {
            animation: pulse-slow 4s ease-in-out infinite;
          }

          /* 반짝이는 별 효과 */
          .stars-container {
            position: absolute;
            width: 100%;
            height: 100%;
          }

          .stars-container::before,
          .stars-container::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
              radial-gradient(1px 1px at 25% 10%, white, transparent),
              radial-gradient(1px 1px at 50% 25%, white, transparent),
              radial-gradient(1px 1px at 75% 30%, white, transparent),
              radial-gradient(1.5px 1.5px at 20% 50%, white, transparent),
              radial-gradient(1px 1px at 35% 75%, white, transparent),
              radial-gradient(1.5px 1.5px at 65% 60%, white, transparent),
              radial-gradient(1px 1px at 85% 85%, white, transparent);
            background-size: 100% 100%;
            background-repeat: no-repeat;
            opacity: 0.2;
          }

          .stars-container::after {
            background-image: 
              radial-gradient(1px 1px at 10% 20%, white, transparent),
              radial-gradient(1px 1px at 40% 35%, white, transparent),
              radial-gradient(1px 1px at 60% 15%, white, transparent),
              radial-gradient(1.5px 1.5px at 30% 40%, white, transparent),
              radial-gradient(1px 1px at 55% 65%, white, transparent),
              radial-gradient(1.5px 1.5px at 75% 45%, white, transparent),
              radial-gradient(1px 1px at 90% 70%, white, transparent);
            animation: twinkle 8s ease-in-out infinite alternate;
          }
        `}
        </style>

        {/* 출목표 (이전 라운드 결과 기록) */}
        {/* 출목표 (이전 라운드 결과 기록) - 전체 회차 히스토리 */}
        <ResultHistory initialData={fullRoundHistory} />

        {/* 현재 라운드 정보 섹션을 추가합니다 (라운드 히스토리 섹션 다음에) */}
        <div className="flex justify-between items-center mb-4">
          <div className="bg-[#1e222d] px-4 py-2 rounded-lg shadow-lg border border-[#2a2e39]">
            <div className="text-lg text-[#5de0e6] font-bold">Round #{round}</div>
          </div>
          <div className="bg-[#1e222d] px-4 py-2 rounded-lg shadow-lg border border-[#2a2e39]">
            <div className="text-lg text-[#f0b90b] font-bold">
              {t(language, "gameUI.balance")}: ₩{wallet.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Betting Grid */}
        <div className="bg-black/80 rounded-xl p-4 mb-6 border border-gray-800">
          <div className="flex flex-col sm:flex-row justify-between items-center mb-3">
            <div className="text-gray-400 text-sm mb-2 sm:mb-0">{t(language, "gameUI.openOrder")} (0)</div>
            <div className="text-gray-400 text-sm">
              {t(language, "gameUI.bettingAmount")} {betAmount.toLocaleString()} x{" "}
              {selectedOption ? getMultiplier(selectedOption) : 0} ={" "}
              {selectedOption ? Math.floor(betAmount * getMultiplier(selectedOption)).toLocaleString() : 0}
            </div>
          </div>

          {/* First row - 3 large buttons */}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
            <button
              onClick={() => handleOptionSelect("BTC WIN")}
              disabled={isBettingClosed}
              className={`py-2 sm:py-4 text-base sm:text-lg font-bold transition-all duration-300 rounded-md ${
                selectedOption === "BTC WIN" ? "bg-[#26a69a]" : "bg-gradient-to-b from-[#c33b3b] to-[#a52a2a]"
              } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <span className="flex items-center justify-center">
                <span className="text-xl sm:text-2xl mr-2">₿</span>
                {t(language, "betting.btcWin")} <span className="ml-2">x 1.95</span>
              </span>
            </button>
            <button
              onClick={() => handleOptionSelect("TIE")}
              disabled={isBettingClosed}
              className={`py-2 sm:py-4 text-base sm:text-lg font-bold transition-all duration-300 rounded-md ${
                selectedOption === "TIE" ? "bg-[#26a69a]" : "bg-gradient-to-b from-[#c6a93f] to-[#b08d2e]"
              } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <span className="flex items-center justify-center">
                {t(language, "betting.tie")} <span className="ml-2">x 12</span>
              </span>
            </button>
            <button
              onClick={() => handleOptionSelect("ETH WIN")}
              disabled={isBettingClosed}
              className={`py-2 sm:py-4 text-base sm:text-lg font-bold transition-all duration-300 rounded-md ${
                selectedOption === "ETH WIN" ? "bg-[#26a69a]" : "bg-gradient-to-b from-[#3b9c3b] to-[#2a802a]"
              } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <span className="flex items-center justify-center">
                <span className="text-xl sm:text-2xl mr-2">Ξ</span>
                {t(language, "betting.ethWin")} <span className="ml-2">x 1.95</span>
              </span>
            </button>
          </div>

          {/* Second row - 4 medium buttons */}

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
            <button
              onClick={() => handleOptionSelect("BTC ODD")}
              disabled={isBettingClosed}
              className={`py-2 sm:py-4 text-base sm:text-lg font-bold transition-all duration-300 rounded-md ${
                selectedOption === "BTC ODD" ? "bg-[#26a69a]" : "bg-gradient-to-b from-[#c33b3b] to-[#a52a2a]"
              } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <span className="flex items-center justify-center">
                <span className="text-lg sm:text-xl mr-1">₿</span>
                {t(language, "betting.odd")} <span className="ml-1">x1.95</span>
              </span>
            </button>
            <button
              onClick={() => handleOptionSelect("BTC EVEN")}
              disabled={isBettingClosed}
              className={`py-2 sm:py-4 text-base sm:text-lg font-bold transition-all duration-300 rounded-md ${
                selectedOption === "BTC EVEN" ? "bg-[#26a69a]" : "bg-gradient-to-b from-[#3b9c3b] to-[#2a802a]"
              } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <span className="flex items-center justify-center">
                <span className="text-lg sm:text-xl mr-1">₿</span>
                {t(language, "betting.even")} <span className="ml-1">x1.95</span>
              </span>
            </button>
            <button
              onClick={() => handleOptionSelect("ETH ODD")}
              disabled={isBettingClosed}
              className={`py-2 sm:py-4 text-base sm:text-lg font-bold transition-all duration-300 rounded-md ${
                selectedOption === "ETH ODD" ? "bg-[#26a69a]" : "bg-gradient-to-b from-[#c33b3b] to-[#a52a2a]"
              } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <span className="flex items-center justify-center">
                <span className="text-lg sm:text-xl mr-1">Ξ</span>
                {t(language, "betting.odd")} <span className="ml-1">x1.95</span>
              </span>
            </button>
            <button
              onClick={() => handleOptionSelect("ETH EVEN")}
              disabled={isBettingClosed}
              className={`py-2 sm:py-4 text-base sm:text-lg font-bold transition-all duration-300 rounded-md ${
                selectedOption === "ETH EVEN" ? "bg-[#26a69a]" : "bg-gradient-to-b from-[#3b9c3b] to-[#2a802a]"
              } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <span className="flex items-center justify-center">
                <span className="text-lg sm:text-xl mr-1">Ξ</span>
                {t(language, "betting.even")} <span className="ml-1">x1.95</span>
              </span>
            </button>
          </div>

          {/* Third row - 4 medium buttons */}

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
            <button
              onClick={() => handleOptionSelect("BTC OVER")}
              disabled={isBettingClosed}
              className={`py-2 sm:py-4 text-base sm:text-lg font-bold transition-all duration-300 rounded-md ${
                selectedOption === "BTC OVER" ? "bg-[#26a69a]" : "bg-gradient-to-b from-[#c33b3b] to-[#a52a2a]"
              } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <span className="flex items-center justify-center">
                <span className="text-lg sm:text-xl mr-1">₿</span>
                {t(language, "betting.over")} <span className="ml-1">x1.95</span>
              </span>
            </button>
            <button
              onClick={() => handleOptionSelect("BTC UNDER")}
              disabled={isBettingClosed}
              className={`py-2 sm:py-4 text-base sm:text-lg font-bold transition-all duration-300 rounded-md ${
                selectedOption === "BTC UNDER" ? "bg-[#26a69a]" : "bg-gradient-to-b from-[#3b9c3b] to-[#2a802a]"
              } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <span className="flex items-center justify-center">
                <span className="text-lg sm:text-xl mr-1">₿</span>
                {t(language, "betting.under")} <span className="ml-1">x1.95</span>
              </span>
            </button>
            <button
              onClick={() => handleOptionSelect("ETH OVER")}
              disabled={isBettingClosed}
              className={`py-2 sm:py-4 text-base sm:text-lg font-bold transition-all duration-300 rounded-md ${
                selectedOption === "ETH OVER" ? "bg-[#26a69a]" : "bg-gradient-to-b from-[#c33b3b] to-[#a52a2a]"
              } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <span className="flex items-center justify-center">
                <span className="text-lg sm:text-xl mr-1">Ξ</span>
                {t(language, "betting.over")} <span className="ml-1">x1.95</span>
              </span>
            </button>
            <button
              onClick={() => handleOptionSelect("ETH UNDER")}
              disabled={isBettingClosed}
              className={`py-2 sm:py-4 text-base sm:text-lg font-bold transition-all duration-300 rounded-md ${
                selectedOption === "ETH UNDER" ? "bg-[#26a69a]" : "bg-gradient-to-b from-[#3b9c3b] to-[#2a802a]"
              } ${isBettingClosed ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <span className="flex items-center justify-center">
                <span className="text-lg sm:text-xl mr-1">Ξ</span>
                {t(language, "betting.under")} <span className="ml-1">x1.95</span>
              </span>
            </button>
          </div>

          {/* Betting controls */}
          <div className="flex flex-col sm:flex-row justify-between items-center bg-black rounded-lg p-2 gap-2 sm:gap-4">
            <button
              onClick={resetBet}
              className="w-full sm:w-auto flex items-center justify-center bg-[#333333] hover:bg-[#444444] text-white py-3 px-4 rounded-md"
            >
              <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M2 12C2 6.48 6.48 2 12 2C17.52 2 22 6.48 22 12C22 17.52 17.52 22 12 22C6.48 22 2 17.52 2 12ZM12 6V12L16 14"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              {t(language, "action.reset")}
            </button>

            <div className="grid grid-cols-3 gap-1 sm:flex flex-wrap justify-center sm:gap-2 w-full sm:w-auto">
              <button
                onClick={() => handleAmountChange(5000)}
                className="bg-[#333333] hover:bg-[#444444] text-white py-2 px-3 rounded-md text-sm"
              >
                5K
              </button>
              <button
                onClick={() => handleAmountChange(1000000)}
                className="bg-[#333333] hover:bg-[#444444] text-white py-2 px-3 rounded-md text-sm"
              >
                1M
              </button>
              <button
                onClick={() => handleAmountChange(5000000)}
                className="bg-[#333333] hover:bg-[#444444] text-white py-2 px-3 rounded-md text-sm"
              >
                5M
              </button>
              <button
                onClick={() => handleAmountChange(10000000)}
                className="bg-[#333333] hover:bg-[#444444] text-white py-2 px-3 rounded-md text-sm"
              >
                10M
              </button>
              <button
                onClick={() => handleAmountChange(50000000)}
                className="bg-[#333333] hover:bg-[#444444] text-white py-2 px-3 rounded-md text-sm"
              >
                50M
              </button>
              <button
                onClick={() => handleAmountChange(100000000)}
                className="bg-[#333333] hover:bg-[#444444] text-white py-2 px-3 rounded-md text-sm"
              >
                100M
              </button>
            </div>

            <div className="flex items-center w-full sm:w-auto justify-between sm:justify-start">
              <div className="text-white text-2xl sm:text-3xl font-bold mx-2 sm:mx-4">{betAmount.toLocaleString()}</div>
              <button
                onClick={confirmBet}
                disabled={!selectedOption || betAmount <= 0 || isBettingClosed}
                className={`flex items-center justify-center bg-[#333333] hover:bg-[#444444] text-white py-3 px-4 rounded-md ${
                  !selectedOption || betAmount <= 0 || isBettingClosed ? "opacity-50 cursor-not-allowed" : ""
                }`}
              >
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path
                    d="M20 6L9 17L4 12"
                    stroke="white"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                {t(language, "action.confirmBet")}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
