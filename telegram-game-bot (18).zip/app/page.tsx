"use client"

import Link from "next/link"
import { ArrowUpRight, Monitor } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center py-4 px-2 sm:py-12 sm:px-4">
      <div className="max-w-2xl w-full mx-auto text-center">
        {/* 로고 및 타이틀 - 모바일 최적화 */}
        <div className="mb-6 sm:mb-12">
          <div className="flex flex-col sm:flex-row justify-center items-center mb-3 sm:mb-4">
            <div className="relative mb-3 sm:mb-0">
              <div className="w-16 h-16 sm:w-24 sm:h-24 rounded-full border-2 border-[#d4af37] flex items-center justify-center">
                <span className="text-[#d4af37] text-3xl sm:text-5xl font-bold">B</span>
              </div>
            </div>
            <div className="sm:ml-4 text-center sm:text-left flex flex-col justify-center">
              <h1 className="text-[#d4af37] text-4xl sm:text-6xl font-bold tracking-wide">BitMatch</h1>
            </div>
          </div>
          <p className="text-[#d4af37] text-lg sm:text-2xl font-light tracking-wider">Crypto Betting Platform</p>
        </div>

        {/* 구분선 */}
        <div className="w-full h-px bg-[#d4af37]/30 my-6 sm:my-10"></div>

        {/* 게임 룰 - 모바일 최적화 */}
        <div className="mb-6 sm:mb-16 text-left px-0 sm:px-0">
          <h2 className="text-[#d4af37] text-xl sm:text-3xl font-bold mb-4 sm:mb-8">게임 룰</h2>
          <div className="space-y-3 sm:space-y-6">
            <div className="flex">
              <span className="text-[#d4af37] text-lg sm:text-2xl font-bold mr-2 sm:mr-4 flex-shrink-0">1</span>
              <p className="text-[#d4af37] text-sm sm:text-xl">바이낸스 차트를 기반으로 결과 설정이 결정됩니다</p>
            </div>
            <div className="flex">
              <span className="text-[#d4af37] text-lg sm:text-2xl font-bold mr-2 sm:mr-4 flex-shrink-0">2</span>
              <p className="text-[#d4af37] text-sm sm:text-xl">
                게임은 정기적인 가격의 소수점 2자리를 기준으로 합니다(0.00~0.99)
              </p>
            </div>
            <div className="flex">
              <span className="text-[#d4af37] text-lg sm:text-2xl font-bold mr-2 sm:mr-4 flex-shrink-0">3</span>
              <p className="text-[#d4af37] text-sm sm:text-xl">
                배팅시간 90초 배팅마감후 30 초 결과 값대기 총 시간 게임 2분입니다
              </p>
            </div>
            <div className="flex">
              <span className="text-[#d4af37] text-lg sm:text-2xl font-bold mr-2 sm:mr-4 flex-shrink-0">4</span>
              <p className="text-[#d4af37] text-sm sm:text-xl">
                기본적으로 비트 코인 또는 이더리움소수점 2자리의 결과 값으로 더 높은 입장이 승리하게 됩니다
              </p>
            </div>
            <div className="flex">
              <span className="text-[#d4af37] text-lg sm:text-2xl font-bold mr-2 sm:mr-4 flex-shrink-0">5</span>
              <p className="text-[#d4af37] text-sm sm:text-xl">
                바이낸스 현물 1분봉 시작가 기준으로 결과값이 적용됩니다
              </p>
            </div>
          </div>
        </div>

        {/* 게임 베팅 구성 - 모바일 최적화 */}
        <div className="mb-6 sm:mb-16 text-left px-0 sm:px-0">
          <h2 className="text-[#d4af37] text-xl sm:text-3xl font-bold mb-4 sm:mb-8">게임 베팅 구성</h2>
          <div className="space-y-3 sm:space-y-6">
            <div className="flex items-start">
              <span className="text-[#d4af37] text-lg sm:text-xl mr-2 sm:mr-4 flex-shrink-0">•</span>
              <p className="text-[#d4af37] text-sm sm:text-xl">
                비트 코인 승 타이더리움 승리 (소수점 두 자리의 결과 값을 더 높은 숫자가 승리)
              </p>
            </div>
            <div className="flex items-start">
              <span className="text-[#d4af37] text-lg sm:text-xl mr-2 sm:mr-4 flex-shrink-0">•</span>
              <p className="text-[#d4af37] text-sm sm:text-xl">
                비트 코인 홀페어 이더리움 홀짝 (소수점 두자리의 홀짝에 따라감)
              </p>
            </div>
            <div className="flex items-start">
              <span className="text-[#d4af37] text-lg sm:text-xl mr-2 sm:mr-4 flex-shrink-0">•</span>
              <p className="text-[#d4af37] text-sm sm:text-xl">배팅 시간 90초 배팅마감후 30 초 결과 값대기</p>
            </div>
            <div className="flex items-start">
              <span className="text-[#d4af37] text-lg sm:text-xl mr-2 sm:mr-4 flex-shrink-0">•</span>
              <p className="text-[#d4af37] text-sm sm:text-xl">윗배팅 기준점 0-49언더 50-99오버</p>
            </div>
            <div className="flex items-start">
              <span className="text-[#d4af37] text-lg sm:text-xl mr-2 sm:mr-4 flex-shrink-0">•</span>
              <p className="text-[#d4af37] text-sm sm:text-xl">타이, 홀/짝, 오바/언더</p>
            </div>
          </div>
        </div>

        {/* 버튼 영역 - 모바일 최적화 */}
        <div className="flex flex-col gap-3 sm:gap-4 justify-center mt-6 sm:mt-12">
          <Link
            href="/web-game"
            className="px-4 py-2 sm:px-8 sm:py-4 bg-transparent border-2 border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37]/10 transition-all duration-300 flex items-center justify-center gap-2 text-base sm:text-xl font-medium rounded-none"
          >
            웹 게임 시작하기
            <Monitor className="h-4 w-4 sm:h-5 sm:w-5 ml-1 sm:ml-2" />
          </Link>

          <Link
            href="https://t.me/BitMaket_7bot"
            target="_blank"
            className="px-4 py-2 sm:px-8 sm:py-4 bg-transparent border-2 border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37]/10 transition-all duration-300 flex items-center justify-center gap-2 text-base sm:text-xl font-medium rounded-none"
          >
            텔레그램에서 봇 시작하기
            <ArrowUpRight className="h-4 w-4 sm:h-5 sm:w-5 ml-1 sm:ml-2" />
          </Link>
        </div>
      </div>
    </div>
  )
}
