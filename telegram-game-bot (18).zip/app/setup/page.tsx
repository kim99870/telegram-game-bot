import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { InfoIcon, CheckCircle2, Copy } from "lucide-react"
import Link from "next/link"

export default function SetupPage() {
  return (
    <div className="container flex items-center justify-center min-h-screen py-12 bg-gradient-to-b from-gray-900 to-black">
      <Card className="w-full max-w-md border-green-500/20 bg-black/80 text-white">
        <CardHeader className="border-b border-green-500/20">
          <CardTitle className="text-green-400">BitMatch 텔레그램 봇 설정</CardTitle>
          <CardDescription className="text-gray-400">텔레그램 봇을 설정하는 방법을 안내합니다.</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-6">
            <Alert className="bg-blue-900/30 border-blue-500/50 text-blue-200">
              <InfoIcon className="h-4 w-4 text-blue-400" />
              <AlertTitle className="text-blue-300">중요</AlertTitle>
              <AlertDescription className="text-blue-200">
                이 설정을 완료하려면 텔레그램 BotFather에서 봇 토큰을 발급받아야 합니다.
              </AlertDescription>
            </Alert>

            <div className="space-y-6">
              <div className="space-y-2">
                <h3 className="font-medium text-green-400 flex items-center">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-green-900 text-green-300 mr-2 text-xs">
                    1
                  </span>
                  BotFather에서 봇 생성하기
                </h3>
                <p className="text-sm text-gray-400 ml-8">
                  텔레그램에서 @BotFather를 검색하고 /newbot 명령어를 사용하여 새 봇을 생성하세요.
                </p>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium text-green-400 flex items-center">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-green-900 text-green-300 mr-2 text-xs">
                    2
                  </span>
                  봇 토큰 설정하기
                </h3>
                <p className="text-sm text-gray-400 ml-8">BotFather로부터 받은 토큰을 환경 변수에 설정하세요.</p>
                <div className="space-y-2 ml-8">
                  <Label htmlFor="token" className="text-gray-300">
                    텔레그램 봇 토큰
                  </Label>
                  <div className="flex">
                    <Input
                      id="token"
                      placeholder="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
                      className="bg-gray-800 border-gray-700 text-gray-200"
                      disabled
                      value="***********************"
                    />
                    <Button variant="outline" size="icon" className="ml-2 border-gray-700 text-green-400">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium text-green-400 flex items-center">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-green-900 text-green-300 mr-2 text-xs">
                    3
                  </span>
                  웹훅 설정하기
                </h3>
                <p className="text-sm text-gray-400 ml-8">배포 후 다음 URL로 웹훅을 설정하세요:</p>
                <code className="block p-3 bg-gray-800 rounded text-xs overflow-x-auto ml-8 text-green-300 border border-gray-700">
                  https://api.telegram.org/bot{"{YOUR_BOT_TOKEN}"}/setWebhook?url={"{YOUR_DOMAIN}"}/api/telegram-webhook
                </code>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium text-green-400 flex items-center">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-green-900 text-green-300 mr-2 text-xs">
                    4
                  </span>
                  봇 사용 시작하기
                </h3>
                <p className="text-sm text-gray-400 ml-8">
                  설정이 완료되면 텔레그램에서 봇을 찾아 /start 명령어로 게임을 시작하세요.
                </p>
                <div className="flex items-center ml-8 mt-2">
                  <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-green-400 text-sm">모든 설정이 완료되었습니다!</span>
                </div>
              </div>

              <div className="pt-4 flex space-x-4">
                <Button className="w-1/2 bg-green-600 hover:bg-green-700">설정 저장</Button>
                <Link href="/" className="w-1/2">
                  <Button variant="outline" className="w-full border-green-700 text-green-400 hover:bg-green-900/30">
                    홈으로 돌아가기
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
