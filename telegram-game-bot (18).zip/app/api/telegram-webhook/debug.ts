// 디버깅용 API 엔드포인트
import { NextResponse } from "next/server"

export async function GET() {
  try {
    // 환경 변수 확인
    const token = process.env.TELEGRAM_BOT_TOKEN
    const tokenStatus = token ? "설정됨 (마스킹됨: " + token.substring(0, 5) + "...)" : "설정되지 않음"

    return NextResponse.json({
      status: "정상",
      telegram_token: tokenStatus,
      timestamp: new Date().toISOString(),
      message: "텔레그램 봇 디버깅 API가 정상적으로 작동 중입니다.",
    })
  } catch (error) {
    return NextResponse.json(
      {
        status: "오류",
        error: String(error),
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
