import { Telegraf, Markup } from "telegraf"
import { type NextRequest, NextResponse } from "next/server"
import { getBinancePrice } from "@/lib/crypto-api"

// 토큰 환경 변수에서 가져오기
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "7965340925:AAGxU7avZioNeoj3mbJRxyv0XnrMzGXfY8w"
const bot = new Telegraf(BOT_TOKEN)

// 디버깅을 위한 로깅 함수
function logDebug(message: string, data?: any) {
  const now = new Date()
  const timeStr = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}:${now.getSeconds().toString().padStart(2, "0")}`
  console.log(`[${timeStr}] [DEBUG] ${message}`, data ? JSON.stringify(data) : "")
}

// Game state storage - in a real app, you'd use a database
const userStates = new Map()
const gameRounds = new Map()
let currentRound = {
  number: 1, // 00시부터 1회차로 시작
  timeRemaining: 120,
  btcPrice: 97490.04,
  ethPrice: 1854.39,
  btcChange: "+0.83%",
  ethChange: "+0.10%",
  // 베팅 마감 시 고정된 가격 (결과 계산용)
  lockedBtcPrice: 0,
  lockedEthPrice: 0,
  // 결과 표시용 최종 고정 가격 (추가)
  finalBtcPrice: 0,
  finalEthPrice: 0,
  isBettingClosed: false,
  isPriceUpdatePaused: false,
  // 결과가 표시되었는지 여부
  isResultDisplayed: false,
  // 결과 데이터
  resultData: null,
}

// Initialize game
let gameInterval: NodeJS.Timeout | null = null
let isGameRunning = false
let isNewRoundStarting = false // 새 라운드 시작 플래그

// 기본 명령어 설정
bot.start((ctx) => {
  const userId = ctx.from.id

  // 사용자 초기화
  if (!userStates.has(userId)) {
    userStates.set(userId, {
      balance: 1000000,
      currentBet: {
        amount: 0,
        option: null,
      },
    })
  }

  logDebug(`사용자 ${userId} 시작 명령어 수신`)
  return ctx.reply(
    "🎮 *BitMatch 베팅 게임에 오신 것을 환영합니다!* 🎮\n\n" +
      "비트코인과 이더리움 가격 변동에 베팅하고 가상 화폐를 획득하세요!\n\n" +
      "📊 */status* - 현재 가격 및 남은 시간 확인\n" +
      "💰 */bet* - 새로운 베팅 하기\n" +
      "💵 */balance* - 잔액 확인\n" +
      "❓ */help* - 도움말 보기",
    { parse_mode: "Markdown" },
  )
})

bot.help((ctx) => {
  logDebug("도움말 명령어 수신")
  return ctx.reply(
    `
📚 *BitMatch 베팅 게임 도움말* 📚

*명령어:*
/start - 계정 초기화
/status - 현재 가격 및 시간 확인
/bet - 새로운 베팅 하기
/balance - 잔액 확인
/help - 도움말 보기

*베팅 옵션:*
• BTC WIN - 비트코인 가격 끝자리 > 이더리움 가격 끝자리
• ETH WIN - 이더리움 가격 끝자리 > 비트코인 가격 끝자리
• TIE - 두 가격 끝자리가 동일함
• BTC ODD - 비트코인 가격 끝자리가 홀수
• BTC EVEN - 비트코인 가격 끝자리가 짝수
• ETH ODD - 이더리움 가격 끝자리가 홀수
• ETH EVEN - 이더리움 가격 끝자리가 짝수
• BTC UNDER - 비트코인 가격 끝자리가 50 미만
• ETH OVER - 이더리움 가격 끝자리가 50 초과

*게임 규칙:*
• 각 라운드는 120초 동안 진행됩니다
• 베팅은 라운드 시작 후 86초 동안만 가능합니다
• 한 라운드에 여러 베팅을 할 수 있습니다
• 승리 시 자동으로 상금이 지급됩니다
• 시작 잔액: ₩1,000,000
  `,
    { parse_mode: "Markdown" },
  )
})

bot.command("ping", (ctx) => {
  logDebug("Ping 명령어 수신")
  return ctx.reply("pong! 봇이 정상 작동 중입니다.")
})

// Status command
bot.command("status", (ctx) => {
  logDebug("상태 명령어 수신")

  // 결과가 표시된 상태인 경우
  if (currentRound.isResultDisplayed && currentRound.resultData) {
    return ctx.reply(currentRound.resultData, { parse_mode: "Markdown" })
  }

  // 베팅 마감 여부에 따라 다른 가격 표시
  const btcPrice = currentRound.isBettingClosed ? currentRound.lockedBtcPrice : currentRound.btcPrice
  const ethPrice = currentRound.isBettingClosed ? currentRound.lockedEthPrice : currentRound.ethPrice

  let statusMessage =
    `📊 *BitMatch 상태* 📊\n\n` +
    `*라운드:* ${currentRound.number}\n` +
    `*남은 시간:* ${currentRound.timeRemaining}초\n\n`

  // 베팅 마감 시 추가 정보 표시
  if (currentRound.isBettingClosed) {
    statusMessage +=
      `🔒 *베팅 마감!*\n\n` +
      `*BTCUSDT · 1*\n` +
      `O${btcPrice.toFixed(2)} H${btcPrice.toFixed(2)} L${btcPrice.toFixed(2)} C${btcPrice.toFixed(2)}\n\n` +
      `*ETHUSDT · 1*\n` +
      `O${ethPrice.toFixed(2)} H${ethPrice.toFixed(2)} L${ethPrice.toFixed(2)} C${ethPrice.toFixed(2)}\n\n` +
      `🔄 *결과 데이터를 로딩 중입니다...*\n\n` +
      `결과는 ${currentRound.timeRemaining}초 후에 발표됩니다.`
  } else {
    statusMessage +=
      `*Bitcoin:* ₩${btcPrice.toLocaleString()} (${currentRound.btcChange})\n` +
      `*Ethereum:* ₩${ethPrice.toLocaleString()} (${currentRound.ethChange})\n\n` +
      `⏱ *베팅 마감까지:* ${Math.max(0, currentRound.timeRemaining - 34)}초\n`
  }

  return ctx.reply(statusMessage, { parse_mode: "Markdown" })
})

// Balance command
bot.command("balance", (ctx) => {
  const userId = ctx.from.id
  const user = userStates.get(userId)

  if (!user) {
    ctx.reply("계정을 초기화하려면 /start 명령어를 사용하세요.")
    return
  }

  ctx.reply(`💰 *현재 잔액:* ₩${user.balance.toLocaleString()}`, { parse_mode: "Markdown" })
})

// Bet command
bot.command("bet", (ctx) => {
  const userId = ctx.from.id
  const user = userStates.get(userId)

  if (!user) {
    ctx.reply("계정을 초기화하려면 /start 명령어를 사용하세요.")
    return
  }

  // 게임이 실행 중인지 확인
  if (!isGameRunning) {
    startGame()
  }

  // 결과가 표시된 상태인 경우
  if (currentRound.isResultDisplayed && currentRound.resultData) {
    ctx.reply(`${currentRound.resultData}\n\n` + `다음 라운드를 기다려주세요. 새 라운드는 곧 시작됩니다.`, {
      parse_mode: "Markdown",
    })
    return
  }

  // Check if betting is still open (first 86 seconds of the round)
  if (currentRound.isBettingClosed) {
    ctx.reply(
      `❌ *베팅 마감*\n\n` +
        `*BTCUSDT · 1*\n` +
        `O${currentRound.lockedBtcPrice.toFixed(2)} H${currentRound.lockedBtcPrice.toFixed(2)} L${currentRound.lockedBtcPrice.toFixed(2)} C${currentRound.lockedBtcPrice.toFixed(2)}\n\n` +
        `*ETHUSDT · 1*\n` +
        `O${currentRound.lockedEthPrice.toFixed(2)} H${currentRound.lockedEthPrice.toFixed(2)} L${currentRound.lockedEthPrice.toFixed(2)} C${currentRound.lockedEthPrice.toFixed(2)}\n\n` +
        `🔄 *결과 데이터를 로딩 중입니다...*\n\n` +
        `결과는 ${currentRound.timeRemaining}초 후에 발표됩니다.\n\n` +
        `다음 라운드를 기다려주세요.`,
      { parse_mode: "Markdown" },
    )
    return
  }

  // 끝자리 계산
  const btcLastTwoDigits = Math.floor(currentRound.btcPrice * 100) % 100
  const ethLastTwoDigits = Math.floor(currentRound.ethPrice * 100) % 100

  ctx.reply(
    `📊 *현재 시장 상황*\n` +
      `*BTCUSDT:* ₩${currentRound.btcPrice.toLocaleString()} (${btcLastTwoDigits})\n` +
      `*ETHUSDT:* ₩${currentRound.ethPrice.toLocaleString()} (${ethLastTwoDigits})\n\n` +
      `⏱ *라운드 ${currentRound.number}* - 남은 시간: ${currentRound.timeRemaining}초\n` +
      `🕒 *베팅 마감까지:* ${Math.max(0, currentRound.timeRemaining - 34)}초\n\n` +
      `베팅 옵션을 선택하세요:`,
    {
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [
          Markup.button.callback("BTC WIN", "bet_BTC_WIN"),
          Markup.button.callback("TIE", "bet_TIE"),
          Markup.button.callback("ETH WIN", "bet_ETH_WIN"),
        ],
        [Markup.button.callback("BTC ODD", "bet_BTC_ODD"), Markup.button.callback("BTC EVEN", "bet_BTC_EVEN")],
        [Markup.button.callback("ETH ODD", "bet_ETH_ODD"), Markup.button.callback("ETH EVEN", "bet_ETH_EVEN")],
        [Markup.button.callback("BTC UNDER", "bet_BTC_UNDER"), Markup.button.callback("ETH OVER", "bet_ETH_OVER")],
      ]),
    },
  )
})

// Handle bet option selection
bot.action(/bet_(.+)/, (ctx) => {
  const userId = ctx.from.id
  const user = userStates.get(userId)
  const option = ctx.match[1].replace(/_/g, " ")

  if (!user) {
    ctx.reply("계정을 초기화하려면 /start 명령어를 사용하세요.")
    return
  }

  // 결과가 표시된 상태인 경우
  if (currentRound.isResultDisplayed && currentRound.resultData) {
    ctx.reply(`${currentRound.resultData}\n\n` + `다음 라운드를 기다려주세요. 새 라운드는 곧 시작됩니다.`, {
      parse_mode: "Markdown",
    })
    return
  }

  // 베팅 마감 확인
  if (currentRound.isBettingClosed) {
    ctx.reply(
      `❌ *베팅 마감*\n\n` +
        `*BTCUSDT · 1*\n` +
        `O${currentRound.lockedBtcPrice.toFixed(2)} H${currentRound.lockedBtcPrice.toFixed(2)} L${currentRound.lockedBtcPrice.toFixed(2)} C${currentRound.lockedBtcPrice.toFixed(2)}\n\n` +
        `*ETHUSDT · 1*\n` +
        `O${currentRound.lockedEthPrice.toFixed(2)} H${currentRound.lockedEthPrice.toFixed(2)} L${currentRound.lockedEthPrice.toFixed(2)} C${currentRound.lockedEthPrice.toFixed(2)}\n\n` +
        `🔄 *결과 데이터를 로딩 중입니다...*`,
      { parse_mode: "Markdown" },
    )
    return
  }

  user.currentBet.option = option

  ctx.editMessageText(`선택한 옵션: *${option}*\n\n베팅 금액을 선택하세요:`, {
    parse_mode: "Markdown",
    ...Markup.inlineKeyboard([
      [
        Markup.button.callback("₩5,000", "amount_5000"),
        Markup.button.callback("₩10,000", "amount_10000"),
        Markup.button.callback("₩50,000", "amount_50000"),
      ],
      [Markup.button.callback("₩100,000", "amount_100000"), Markup.button.callback("₩1,000,000", "amount_1000000")],
      [Markup.button.callback("❌ 취소", "cancel_bet")],
    ]),
  })
})

// Handle bet amount selection
bot.action(/amount_(\d+)/, (ctx) => {
  const userId = ctx.from.id
  const user = userStates.get(userId)
  const amount = Number.parseInt(ctx.match[1])

  if (!user) {
    ctx.reply("계정을 초기화하려면 /start 명령어를 사용하세요.")
    return
  }

  // 결과가 표시된 상태인 경우
  if (currentRound.isResultDisplayed && currentRound.resultData) {
    ctx.reply(`${currentRound.resultData}\n\n` + `다음 라운드를 기다려주세요. 새 라운드는 곧 시작됩니다.`, {
      parse_mode: "Markdown",
    })
    return
  }

  // 베팅 마감 확인
  if (currentRound.isBettingClosed) {
    ctx.reply(
      `❌ *베팅 마감*\n\n` +
        `*BTCUSDT · 1*\n` +
        `O${currentRound.lockedBtcPrice.toFixed(2)} H${currentRound.lockedBtcPrice.toFixed(2)} L${currentRound.lockedBtcPrice.toFixed(2)} C${currentRound.lockedBtcPrice.toFixed(2)}\n\n` +
        `*ETHUSDT · 1*\n` +
        `O${currentRound.lockedEthPrice.toFixed(2)} H${currentRound.lockedEthPrice.toFixed(2)} L${currentRound.lockedEthPrice.toFixed(2)} C${currentRound.lockedEthPrice.toFixed(2)}\n\n` +
        `🔄 *결과 데이터를 로딩 중입니다...*`,
      { parse_mode: "Markdown" },
    )
    return
  }

  if (user.balance < amount) {
    ctx.reply("❌ 잔액이 부족합니다. 더 작은 금액을 선택하세요.")
    return
  }

  user.currentBet.amount = amount

  ctx.editMessageText(
    `베팅 확인:\n\n` +
      `옵션: *${user.currentBet.option}*\n` +
      `금액: ₩${amount.toLocaleString()}\n\n` +
      `현재 잔액: ₩${user.balance.toLocaleString()}`,
    {
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback("✅ 확인", "confirm_bet"), Markup.button.callback("❌ 취소", "cancel_bet")],
      ]),
    },
  )
})

// Handle bet confirmation
bot.action("confirm_bet", (ctx) => {
  const userId = ctx.from.id
  const user = userStates.get(userId)

  if (!user || !user.currentBet.option || !user.currentBet.amount) {
    ctx.reply("잘못된 베팅입니다. 새로운 베팅을 하려면 /bet 명령어를 사용하세요.")
    return
  }

  // 결과가 표시된 상태인 경우
  if (currentRound.isResultDisplayed && currentRound.resultData) {
    ctx.reply(`${currentRound.resultData}\n\n` + `다음 라운드를 기다려주세요. 새 라운드는 곧 시작됩니다.`, {
      parse_mode: "Markdown",
    })
    return
  }

  // 베팅 마감 확인
  if (currentRound.isBettingClosed) {
    ctx.reply(
      `❌ *베팅 마감*\n\n` +
        `*BTCUSDT · 1*\n` +
        `O${currentRound.lockedBtcPrice.toFixed(2)} H${currentRound.lockedBtcPrice.toFixed(2)} L${currentRound.lockedBtcPrice.toFixed(2)} C${currentRound.lockedBtcPrice.toFixed(2)}\n\n` +
        `*ETHUSDT · 1*\n` +
        `O${currentRound.lockedEthPrice.toFixed(2)} H${currentRound.lockedEthPrice.toFixed(2)} L${currentRound.lockedEthPrice.toFixed(2)} C${currentRound.lockedEthPrice.toFixed(2)}\n\n` +
        `🔄 *결과 데이터를 로딩 중입니다...*`,
      { parse_mode: "Markdown" },
    )
    return
  }

  if (user.balance < user.currentBet.amount) {
    ctx.reply("❌ 잔액이 부족합니다. 더 작은 금액을 선택하세요.")
    return
  }

  // Deduct bet amount from balance
  user.balance -= user.currentBet.amount

  // Add bet to current round
  if (!gameRounds.has(currentRound.number)) {
    gameRounds.set(currentRound.number, [])
  }

  gameRounds.get(currentRound.number).push({
    userId,
    option: user.currentBet.option,
    amount: user.currentBet.amount,
  })

  logDebug(`사용자 ${userId} 베팅 확인: ${user.currentBet.option}, 금액: ${user.currentBet.amount}`)

  ctx.editMessageText(
    `✅ *베팅 완료!*\n\n` +
      `옵션: *${user.currentBet.option}*\n` +
      `금액: ₩${user.currentBet.amount.toLocaleString()}\n\n` +
      `새 잔액: ₩${user.balance.toLocaleString()}\n\n` +
      `라운드 ${currentRound.number}는 ${currentRound.timeRemaining}초 후에 종료됩니다.`,
    { parse_mode: "Markdown" },
  )

  // Reset current bet
  user.currentBet = {
    amount: 0,
    option: null,
  }
})

// Handle bet cancellation
bot.action("cancel_bet", (ctx) => {
  const userId = ctx.from.id
  const user = userStates.get(userId)

  if (user) {
    user.currentBet = {
      amount: 0,
      option: null,
    }
  }

  ctx.editMessageText("베팅이 취소되었습니다. 새로운 베팅을 하려면 /bet 명령어를 사용하세요.")
})

// 새로운 가격 가져오기 함수
async function fetchNewPrices() {
  try {
    const prices = await getBinancePrice()
    if (prices) {
      return {
        btcPrice: prices.btcPrice,
        ethPrice: prices.ethPrice,
        btcChange: "+0.00%", // 새 라운드 시작 시 변동률 초기화
        ethChange: "+0.00%",
      }
    }
  } catch (error) {
    console.error("새 가격 가져오기 오류:", error)
  }

  // 실패 시 기본값 반환
  return {
    btcPrice: currentRound.btcPrice,
    ethPrice: currentRound.ethPrice,
    btcChange: currentRound.btcChange,
    ethChange: currentRound.ethChange,
  }
}

// Start the game timer and price updates
function startGame() {
  if (isGameRunning) return

  logDebug("게임 시작...")
  isGameRunning = true

  // 게임 시작 시 새로운 가격 가져오기
  fetchNewPrices().then((prices) => {
    currentRound.btcPrice = prices.btcPrice
    currentRound.ethPrice = prices.ethPrice
    currentRound.btcChange = prices.btcChange
    currentRound.ethChange = prices.ethChange

    logDebug(`게임 시작 가격: BTC=${currentRound.btcPrice.toFixed(2)}, ETH=${currentRound.ethPrice.toFixed(2)}`)
  })

  gameInterval = setInterval(async () => {
    try {
      // 새 라운드 시작 시 새로운 가격 가져오기
      if (isNewRoundStarting) {
        // 결과 표시 상태 초기화
        currentRound.isResultDisplayed = false
        currentRound.resultData = null

        const prices = await fetchNewPrices()
        currentRound.btcPrice = prices.btcPrice
        currentRound.ethPrice = prices.ethPrice
        currentRound.btcChange = prices.btcChange
        currentRound.ethChange = prices.ethChange

        isNewRoundStarting = false
        logDebug(
          `새 라운드 시작 가격: BTC=${currentRound.btcPrice.toFixed(2)}, ETH=${currentRound.ethPrice.toFixed(2)}`,
        )
      }

      // 베팅 마감 후에는 가격 업데이트 중지
      if (!currentRound.isPriceUpdatePaused) {
        // Try to get real prices from Binance
        const prices = await getBinancePrice()
        if (prices) {
          const btcOldPrice = currentRound.btcPrice
          const ethOldPrice = currentRound.ethPrice

          currentRound.btcPrice = prices.btcPrice
          currentRound.ethPrice = prices.ethPrice

          // Calculate change percentage
          const btcChangePercent = (((currentRound.btcPrice - btcOldPrice) / btcOldPrice) * 100).toFixed(2)
          const ethChangePercent = (((currentRound.ethPrice - ethOldPrice) / ethOldPrice) * 100).toFixed(2)

          currentRound.btcChange = (btcChangePercent > 0 ? "+" : "") + btcChangePercent + "%"
          currentRound.ethChange = (ethChangePercent > 0 ? "+" : "") + ethChangePercent + "%"
        } else {
          // Fallback to random price changes if API fails
          currentRound.btcPrice = Number.parseFloat((currentRound.btcPrice + (Math.random() * 300 - 150)).toFixed(2))
          currentRound.ethPrice = Number.parseFloat((currentRound.ethPrice + (Math.random() * 20 - 10)).toFixed(2))

          currentRound.btcChange = (Math.random() > 0.5 ? "+" : "-") + (Math.random() * 2).toFixed(2) + "%"
          currentRound.ethChange = (Math.random() > 0.5 ? "+" : "-") + (Math.random() * 2).toFixed(2) + "%"
        }
      }

      // Update time remaining
      if (currentRound.timeRemaining > 0) {
        currentRound.timeRemaining--

        // Notify users about time remaining at specific intervals
        if (
          currentRound.timeRemaining === 60 ||
          currentRound.timeRemaining === 30 ||
          currentRound.timeRemaining === 10
        ) {
          notifyAllUsers(`⏱ *라운드 ${currentRound.number}*: ${currentRound.timeRemaining}초 남았습니다!`)
        }

        // 베팅 마감 (34초 남았을 때)
        if (currentRound.timeRemaining === 34) {
          currentRound.isBettingClosed = true
          currentRound.isPriceUpdatePaused = true

          // 현재 가격을 고정 (결과 계산용)
          currentRound.lockedBtcPrice = currentRound.btcPrice
          currentRound.lockedEthPrice = currentRound.ethPrice

          // 끝자리 계산
          const btcLastTwoDigits = Math.floor(currentRound.lockedBtcPrice * 100) % 100
          const ethLastTwoDigits = Math.floor(currentRound.lockedEthPrice * 100) % 100

          logDebug(
            `베팅 마감! 가격 고정: BTC=${currentRound.lockedBtcPrice.toFixed(2)} (끝자리: ${btcLastTwoDigits}), ETH=${currentRound.lockedEthPrice.toFixed(2)} (끝자리: ${ethLastTwoDigits})`,
          )

          notifyAllUsers(
            `🔒 *베팅 마감!*\n\n` +
              `*BTCUSDT · 1*\n` +
              `O${currentRound.lockedBtcPrice.toFixed(2)} H${currentRound.lockedBtcPrice.toFixed(2)} L${currentRound.lockedBtcPrice.toFixed(2)} C${currentRound.lockedBtcPrice.toFixed(2)}\n\n` +
              `*ETHUSDT · 1*\n` +
              `O${currentRound.lockedEthPrice.toFixed(2)} H${currentRound.lockedEthPrice.toFixed(2)} L${currentRound.lockedEthPrice.toFixed(2)} C${currentRound.lockedEthPrice.toFixed(2)}\n\n` +
              `🔄 *결과 데이터를 로딩 중입니다...*\n\n` +
              `결과는 ${currentRound.timeRemaining}초 후에 발표됩니다.`,
          )
        }
      } else {
        // 라운드 종료 시점에 최종 가격 캡처 (이 시점의 가격으로 결과 결정)
        currentRound.finalBtcPrice = currentRound.btcPrice
        currentRound.finalEthPrice = currentRound.ethPrice

        logDebug(
          `라운드 종료! 최종 결과 가격 확정: BTC=${currentRound.finalBtcPrice.toFixed(2)}, ETH=${currentRound.finalEthPrice.toFixed(2)}`,
        )

        // Round ended, process bets and start new round
        await processRoundResults()

        // 5초 후에 새 라운드 시작
        setTimeout(async () => {
          // 새 라운드 시작 플래그 설정
          isNewRoundStarting = true

          // 새 라운드 시작 - 반드시 새 가격 가져오기 (새로운 오픈 시가)
          let newPrices = await fetchNewPrices()
          if (!newPrices) {
            logDebug("새 가격 가져오기 실패, 재시도...")
            // 최대 3번 재시도
            for (let i = 0; i < 3; i++) {
              const retryPrices = await fetchNewPrices()
              if (retryPrices) {
                newPrices = retryPrices
                break
              }
              await new Promise((resolve) => setTimeout(resolve, 500))
            }
          }

          // 새 라운드 시작
          currentRound = {
            number: currentRound.number < 720 ? currentRound.number + 1 : 1, // 720회차까지 진행 후 1회차로 리셋
            timeRemaining: 120,
            btcPrice: newPrices.btcPrice, // 새 오픈 가격으로 시작
            ethPrice: newPrices.ethPrice, // 새 오픈 가격으로 시작
            btcChange: "+0.00%", // 변동률 초기화
            ethChange: "+0.00%", // 변동률 초기화
            lockedBtcPrice: 0,
            lockedEthPrice: 0,
            finalBtcPrice: 0,
            finalEthPrice: 0,
            isBettingClosed: false,
            isPriceUpdatePaused: false,
            isResultDisplayed: false,
            resultData: null,
          }

          // 끝자리 계산
          const btcLastTwoDigits = Math.floor(currentRound.btcPrice * 100) % 100
          const ethLastTwoDigits = Math.floor(currentRound.ethPrice * 100) % 100

          // Notify all users about new round with new prices
          notifyAllUsers(
            `🔄 *라운드 ${currentRound.number} 시작!*\n\n` +
              `*새 오픈 시가:*\n` +
              `*BTCUSDT:* ₩${currentRound.btcPrice.toLocaleString()} (끝자리: ${btcLastTwoDigits})\n` +
              `*ETHUSDT:* ₩${currentRound.ethPrice.toLocaleString()} (끝자리: ${ethLastTwoDigits})\n\n` +
              `새로운 베팅을 하려면 /bet 명령어를 사용하세요.`,
          )
        }, 5000) // 5초 후에 새 라운드 시작

        // 타이머 일시 정지 (새 라운드 시작 전까지)
        clearInterval(gameInterval)
        gameInterval = null

        // 5초 후에 게임 다시 시작
        setTimeout(() => {
          if (!gameInterval) {
            gameInterval = setInterval(arguments.callee, 1000)
          }
        }, 5000)

        return // 현재 인터벌 종료
      }
    } catch (error) {
      console.error("Game update error:", error)
    }
  }, 1000)
}

// Notify all active users
function notifyAllUsers(message: string) {
  for (const [userId] of userStates) {
    try {
      bot.telegram.sendMessage(userId, message, { parse_mode: "Markdown" })
    } catch (error) {
      console.error(`Failed to notify user ${userId}:`, error)
    }
  }
}

// Process round results
async function processRoundResults() {
  // 최종 고정된 가격의 끝 두 자리 추출 (finalBtcPrice 사용)
  const btcLastTwoDigits = Math.floor(currentRound.finalBtcPrice * 100) % 100
  const ethLastTwoDigits = Math.floor(currentRound.finalEthPrice * 100) % 100

  logDebug(`결과 계산: BTC 끝자리=${btcLastTwoDigits}, ETH 끝자리=${ethLastTwoDigits}`)

  // 비트코인과 이더리움 승패 결정 (끝 두 자리 기준)
  const btcWins = btcLastTwoDigits > ethLastTwoDigits
  const tie = btcLastTwoDigits === ethLastTwoDigits
  const btcIsOdd = btcLastTwoDigits % 2 !== 0
  const ethIsOdd = ethLastTwoDigits % 2 !== 0

  // 결과 메시지 - 스크린샷 형식으로 변경 (0초 시점의 실제 가격으로)
  const resultMessage = `
🏁 *라운드 ${currentRound.number} 결과 (0초 시점 가격)*

*BTCUSDT · 1*
O${currentRound.finalBtcPrice.toFixed(2)} H${currentRound.finalBtcPrice.toFixed(2)} L${currentRound.finalBtcPrice.toFixed(2)} C${currentRound.finalBtcPrice.toFixed(2)}

*ETHUSDT · 1*
O${currentRound.finalEthPrice.toFixed(2)} H${currentRound.finalEthPrice.toFixed(2)} L${currentRound.finalEthPrice.toFixed(2)} C${currentRound.finalEthPrice.toFixed(2)}

*결과 (끝자리 기준):*
${btcWins ? "✅ BTC WIN" : tie ? "✅ TIE" : "✅ ETH WIN"} (BTC: ${btcLastTwoDigits}, ETH: ${ethLastTwoDigits})

*기타 조건:*
${btcIsOdd ? "✅" : "❌"} BTC ODD (${btcLastTwoDigits})
${!btcIsOdd ? "✅" : "❌"} BTC EVEN (${btcLastTwoDigits})
${ethIsOdd ? "✅" : "❌"} ETH ODD (${ethLastTwoDigits})
${!ethIsOdd ? "✅" : "❌"} ETH EVEN (${ethLastTwoDigits})
${btcLastTwoDigits < 50 ? "✅" : "❌"} BTC UNDER (${btcLastTwoDigits} < 50)
${ethLastTwoDigits > 50 ? "✅" : "❌"} ETH OVER (${ethLastTwoDigits} > 50)
`

  // 결과 데이터 저장
  currentRound.isResultDisplayed = true
  currentRound.resultData = resultMessage

  // Notify all users about round results
  notifyAllUsers(resultMessage)

  // Process all bets for this round
  const roundBets = gameRounds.get(currentRound.number) || []

  for (const bet of roundBets) {
    const user = userStates.get(bet.userId)
    if (!user) continue

    let won = false
    let multiplier = 1

    switch (bet.option) {
      case "BTC WIN":
        won = btcWins
        multiplier = 1.8
        break
      case "ETH WIN":
        won = !btcWins && !tie
        multiplier = 1.8
        break
      case "TIE":
        won = tie
        multiplier = 10
        break
      case "BTC ODD":
        won = btcIsOdd
        multiplier = 1.9
        break
      case "BTC EVEN":
        won = !btcIsOdd
        multiplier = 1.9
        break
      case "ETH ODD":
        won = ethIsOdd
        multiplier = 1.9
        break
      case "ETH EVEN":
        won = !ethIsOdd
        multiplier = 1.9
        break
      case "BTC UNDER":
        won = btcLastTwoDigits < 50
        multiplier = 1.9
        break
      case "ETH OVER":
        won = ethLastTwoDigits > 50
        multiplier = 1.9
        break
    }

    // Calculate winnings
    const winnings = won ? Math.floor(bet.amount * multiplier) : 0

    if (won) {
      user.balance += winnings
      // Notify user of win
      await bot.telegram.sendMessage(
        bet.userId,
        `🎉 *승리!* 베팅: ₩${bet.amount.toLocaleString()} on ${bet.option}\n💰 획득: ₩${winnings.toLocaleString()}\n💵 현재 잔액: ₩${user.balance.toLocaleString()}`,
        { parse_mode: "Markdown" },
      )
    } else {
      // Notify user of loss
      await bot.telegram.sendMessage(
        bet.userId,
        `❌ *패배* 베팅: ₩${bet.amount.toLocaleString()} on ${bet.option}\n💵 현재 잔액: ₩${user.balance.toLocaleString()}`,
        { parse_mode: "Markdown" },
      )
    }
  }

  // Clear round bets
  gameRounds.delete(currentRound.number)
}

// 모든 메시지에 응답
bot.on("message", (ctx) => {
  const userId = ctx.from.id

  // 사용자가 등록되어 있지 않으면 초기화
  if (!userStates.has(userId)) {
    userStates.set(userId, {
      balance: 1000000,
      currentBet: {
        amount: 0,
        option: null,
      },
    })

    ctx.reply(
      "🎮 *BitMatch 베팅 게임에 오신 것을 환영합니다!* 🎮\n\n" +
        "비트코인과 이더리움 가격 변동에 베팅하고 가상 화폐를 획득하세요!\n\n" +
        "📊 */status* - 현재 가격 및 남은 시간 확인\n" +
        "💰 */bet* - 새로운 베팅 하기\n" +
        "💵 */balance* - 잔액 확인\n" +
        "❓ */help* - 도움말 보기",
      { parse_mode: "Markdown" },
    )
    return
  }

  // 게임이 실행 중인지 확인
  if (!isGameRunning) {
    startGame()
  }

  logDebug(`사용자 ${userId}로부터 메시지 수신: ${ctx.message.text}`)
  return ctx.reply(`명령어를 사용해주세요. 도움말은 /help를 입력하세요.`)
})

// 봇 초기화 및 설정
bot.telegram
  .getMe()
  .then((botInfo) => {
    logDebug(`봇 초기화 완료: @${botInfo.username}`)
  })
  .catch((err) => {
    console.error("봇 초기화 오류:", err)
  })

// Launch the bot in webhook mode for production
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    logDebug("텔레그램 업데이트 수신", body)

    // 게임이 실행 중인지 확인
    if (!isGameRunning) {
      startGame()
    }

    await bot.handleUpdate(body)
    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error("업데이트 처리 오류:", error)
    return NextResponse.json(
      {
        ok: false,
        error: String(error),
        message: "웹훅 처리 중 오류가 발생했습니다",
      },
      { status: 500 },
    )
  }
}

// 간단한 GET 요청 처리 추가
export async function GET() {
  // 게임이 실행 중인지 확인
  if (!isGameRunning) {
    startGame()
  }

  return NextResponse.json({
    status: "online",
    message: "텔레그램 봇 웹훅 엔드포인트가 활성화되어 있습니다.",
    gameStatus: isGameRunning ? "실행 중" : "중지됨",
    currentRound: {
      number: currentRound.number,
      timeRemaining: currentRound.timeRemaining,
      isBettingClosed: currentRound.isBettingClosed,
    },
    timestamp: new Date().toISOString(),
  })
}
