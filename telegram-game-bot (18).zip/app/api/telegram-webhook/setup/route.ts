import { NextResponse } from "next/server"
import { Telegraf } from "telegraf"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const setup = searchParams.get("setup") === "true"

    if (!setup) {
      return NextResponse.json({
        message: "봇 설정을 시작하려면 ?setup=true 파라미터를 추가하세요",
        example: "/api/telegram-webhook/setup?setup=true",
      })
    }

    const token = process.env.TELEGRAM_BOT_TOKEN
    if (!token) {
      return NextResponse.json({ error: "TELEGRAM_BOT_TOKEN이 설정되지 않았습니다" }, { status: 500 })
    }

    const bot = new Telegraf(token)

    // 봇 정보 가져오기
    const botInfo = await bot.telegram.getMe()

    // 현재 웹훅 정보 가져오기
    const webhookInfo = await bot.telegram.getWebhookInfo()

    // 호스트 URL 가져오기
    const host = request.headers.get("host") || "your-app.vercel.app"
    const protocol = host.includes("localhost") ? "http" : "https"
    const webhookUrl = `${protocol}://${host}/api/telegram-webhook`

    // 웹훅 설정
    await bot.telegram.setWebhook(webhookUrl)

    // 명령어 설정
    await bot.telegram.setMyCommands([
      { command: "start", description: "게임 시작 및 계정 초기화" },
      { command: "status", description: "현재 가격 및 시간 확인" },
      { command: "bet", description: "새로운 베팅 하기" },
      { command: "balance", description: "잔액 확인" },
      { command: "help", description: "도움말 보기" },
      { command: "test", description: "봇 연결 테스트" },
    ])

    return NextResponse.json({
      success: true,
      bot: {
        id: botInfo.id,
        username: botInfo.username,
        first_name: botInfo.first_name,
      },
      webhook: {
        previous: webhookInfo.url,
        new: webhookUrl,
        status: "설정됨",
      },
      commands: "설정됨",
      next_steps: ["텔레그램에서 @" + botInfo.username + "를 검색하세요", "/start 명령어를 입력하여 게임을 시작하세요"],
    })
  } catch (error) {
    console.error("봇 설정 오류:", error)
    return NextResponse.json({ error: String(error) }, { status: 500 })
  }
}
