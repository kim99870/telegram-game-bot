import { NextResponse } from "next/server"
import { Telegraf } from "telegraf"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const url = searchParams.get("url")

    if (!url) {
      return NextResponse.json(
        {
          error: "url 파라미터가 필요합니다",
          example: "/api/telegram-webhook/set?url=https://your-domain.com/api/telegram-webhook",
        },
        { status: 400 },
      )
    }

    const token = process.env.TELEGRAM_BOT_TOKEN
    if (!token) {
      return NextResponse.json(
        {
          error: "TELEGRAM_BOT_TOKEN이 설정되지 않았습니다",
        },
        { status: 500 },
      )
    }

    const bot = new Telegraf(token)

    // 기존 웹훅 정보 가져오기
    const oldWebhook = await bot.telegram.getWebhookInfo()

    // 새 웹훅 설정
    await bot.telegram.setWebhook(url)

    // 명령어 설정
    await bot.telegram.setMyCommands([
      { command: "start", description: "봇 시작하기" },
      { command: "help", description: "도움말 보기" },
      { command: "ping", description: "봇 상태 확인" },
    ])

    // 새 웹훅 정보 가져오기
    const newWebhook = await bot.telegram.getWebhookInfo()

    return NextResponse.json({
      success: true,
      webhook: {
        old: oldWebhook.url,
        new: newWebhook.url,
      },
      commands: "설정됨",
      test_instructions: ["텔레그램에서 봇을 검색하세요", "/ping 명령어를 입력하여 봇이 응답하는지 확인하세요"],
    })
  } catch (error) {
    console.error("웹훅 설정 오류:", error)
    return NextResponse.json(
      {
        error: String(error),
      },
      { status: 500 },
    )
  }
}
