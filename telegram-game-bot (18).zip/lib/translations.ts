import type { Language } from "./language-context"

// 번역 데이터 타입 정의
interface Translations {
  [key: string]: {
    en: string
    ko: string
    zh: string
  }
}

// 번역 데이터
const translations: Translations = {
  // 게임 UI 관련 번역
  "gameUI.usersOnline": {
    en: "users online",
    ko: "접속자 수",
    zh: "在线用户",
  },
  "gameUI.bettingInProgress": {
    en: "betting in progress",
    ko: "베팅 진행 중",
    zh: "投注进行中",
  },
  "gameUI.round": {
    en: "Round",
    ko: "회차",
    zh: "回合",
  },
  "gameUI.balance": {
    en: "Balance",
    ko: "잔액",
    zh: "余额",
  },
  "gameUI.openOrder": {
    en: "Open order",
    ko: "미체결 주문",
    zh: "未成交订单",
  },
  "gameUI.bettingAmount": {
    en: "Betting Amount",
    ko: "베팅 금액",
    zh: "投注金额",
  },

  // 베팅 옵션 관련 번역
  "betting.btcWin": {
    en: "BTC WIN",
    ko: "BTC 승리",
    zh: "BTC 胜",
  },
  "betting.tie": {
    en: "TIE",
    ko: "무승부",
    zh: "平局",
  },
  "betting.ethWin": {
    en: "ETH WIN",
    ko: "ETH 승리",
    zh: "ETH 胜",
  },
  "betting.odd": {
    en: "ODD",
    ko: "홀",
    zh: "奇数",
  },
  "betting.even": {
    en: "EVEN",
    ko: "짝",
    zh: "偶数",
  },
  "betting.over": {
    en: "OVER",
    ko: "오버",
    zh: "大于",
  },
  "betting.under": {
    en: "UNDER",
    ko: "언더",
    zh: "小于",
  },
  "betting.btcOdd": {
    en: "BTC ODD",
    ko: "BTC 홀수",
    zh: "BTC 奇数",
  },
  "betting.btcEven": {
    en: "BTC EVEN",
    ko: "BTC 짝수",
    zh: "BTC 偶数",
  },
  "betting.ethOdd": {
    en: "ETH ODD",
    ko: "ETH 홀수",
    zh: "ETH 奇数",
  },
  "betting.ethEven": {
    en: "ETH EVEN",
    ko: "ETH 짝수",
    zh: "ETH 偶数",
  },
  "betting.btcOver": {
    en: "BTC OVER",
    ko: "BTC 오버",
    zh: "BTC 大于",
  },
  "betting.btcUnder": {
    en: "BTC UNDER",
    ko: "BTC 언더",
    zh: "BTC 小于",
  },
  "betting.ethOver": {
    en: "ETH OVER",
    ko: "ETH 오버",
    zh: "ETH 大于",
  },
  "betting.ethUnder": {
    en: "ETH UNDER",
    ko: "ETH 언더",
    zh: "ETH 小于",
  },

  // 버튼 및 액션 관련 번역
  "action.reset": {
    en: "Reset",
    ko: "초기화",
    zh: "重置",
  },
  "action.confirmBet": {
    en: "Confirm Bet",
    ko: "베팅 확인",
    zh: "确认投注",
  },

  // 결과 관련 번역
  "result.win": {
    en: "Win!",
    ko: "승리!",
    zh: "胜利!",
  },
  "result.loss": {
    en: "Loss!",
    ko: "패배!",
    zh: "失败!",
  },
  "result.pending": {
    en: "Pending",
    ko: "대기 중",
    zh: "等待中",
  },
  "result.loadingData": {
    en: "Loading Result Data",
    ko: "결과 데이터 로딩 중",
    zh: "加载结果数据",
  },
  "result.pleaseWait": {
    en: "Please wait...",
    ko: "잠시만 기다려주세요...",
    zh: "请稍候...",
  },

  // 베팅 내역 관련 번역
  "history.yourBettingHistory": {
    en: "YOUR BETTING HISTORY",
    ko: "나의 베팅 내역",
    zh: "您的投注历史",
  },
  "history.betsPlaced": {
    en: "bets placed",
    ko: "베팅 완료",
    zh: "已下注",
  },
  "history.noBettingHistory": {
    en: "No betting history yet",
    ko: "아직 베팅 내역이 없습니다",
    zh: "暂无投注历史",
  },
  "history.willAppearHere": {
    en: "Your betting history will appear here",
    ko: "베팅 내역이 여기에 표시됩니다",
    zh: "您的投注历史将显示在这里",
  },

  // 언어 선택 관련 번역
  "language.english": {
    en: "English",
    ko: "영어",
    zh: "英语",
  },
  "language.korean": {
    en: "Korean",
    ko: "한국어",
    zh: "韩语",
  },
  "language.chinese": {
    en: "Chinese",
    ko: "중국어",
    zh: "中文",
  },

  // 결과 내역 관련 번역 추가
  "history.resultHistory": {
    en: "Result History",
    ko: "결과 내역",
    zh: "结果历史",
  },
  "history.total": {
    en: "Total",
    ko: "전체",
    zh: "总共",
  },
  "history.rounds": {
    en: "rounds",
    ko: "회차",
    zh: "回合",
  },
  "history.filter": {
    en: "Filter",
    ko: "필터",
    zh: "筛选",
  },
  "history.viewChart": {
    en: "View Chart",
    ko: "차트 보기",
    zh: "查看图表",
  },
  "history.downloadCSV": {
    en: "Download CSV",
    ko: "CSV 다운로드",
    zh: "下载CSV",
  },
  "history.searchPlaceholder": {
    en: "Search rounds, prices, results...",
    ko: "회차, 가격, 결과 검색...",
    zh: "搜索回合、价格、结果...",
  },
  "history.btcWin": {
    en: "BTC WIN",
    ko: "BTC 승리",
    zh: "BTC 胜",
  },
  "history.ethWin": {
    en: "ETH WIN",
    ko: "ETH 승리",
    zh: "ETH 胜",
  },
  "history.tie": {
    en: "TIE",
    ko: "무승부",
    zh: "平局",
  },
  "history.btcOdd": {
    en: "BTC ODD",
    ko: "BTC 홀수",
    zh: "BTC 奇数",
  },
  "history.btcEven": {
    en: "BTC EVEN",
    ko: "BTC 짝수",
    zh: "BTC 偶数",
  },
  "history.last10": {
    en: "Last 10",
    ko: "최근 10회",
    zh: "最近10次",
  },
  "history.last50": {
    en: "Last 50",
    ko: "최근 50회",
    zh: "最近50次",
  },
  "history.last100": {
    en: "Last 100",
    ko: "최근 100회",
    zh: "最近100次",
  },
  "history.consecutivePatterns": {
    en: "Consecutive Patterns",
    ko: "연속 패턴",
    zh: "连续模式",
  },
  "history.btcConsecutiveWins": {
    en: "BTC consecutive wins",
    ko: "BTC 연속 승리",
    zh: "BTC连续胜利",
  },
  "history.ethConsecutiveWins": {
    en: "ETH consecutive wins",
    ko: "ETH 연속 승리",
    zh: "ETH连续胜利",
  },
  "history.tieConsecutive": {
    en: "Tie consecutive",
    ko: "무승부 연속",
    zh: "连续平局",
  },
  "history.alternatingPattern": {
    en: "Alternating pattern",
    ko: "교차 패턴",
    zh: "交替模式",
  },
  "history.times": {
    en: " times",
    ko: "회",
    zh: "次",
  },
  "history.frequentPatterns": {
    en: "Frequently Occurring Patterns (Last 3 rounds)",
    ko: "자주 발생하는 패턴 (최근 3회)",
    zh: "常见模式 (最近3轮)",
  },
  "history.round": {
    en: "Round",
    ko: "회차",
    zh: "回合",
  },
  "history.time": {
    en: "Time",
    ko: "시간",
    zh: "时间",
  },
  "history.btcPrice": {
    en: "BTC Price",
    ko: "BTC 가격",
    zh: "BTC 价格",
  },
  "history.ethPrice": {
    en: "ETH Price",
    ko: "ETH 가격",
    zh: "ETH 价格",
  },
  "history.result": {
    en: "Result",
    ko: "결과",
    zh: "结果",
  },
  "history.details": {
    en: "Details",
    ko: "상세",
    zh: "详情",
  },
  "history.first": {
    en: "First",
    ko: "처음",
    zh: "首页",
  },
  "history.previous": {
    en: "Previous",
    ko: "이전",
    zh: "上一页",
  },
  "history.next": {
    en: "Next",
    ko: "다음",
    zh: "下一页",
  },
  "history.last": {
    en: "Last",
    ko: "마지막",
    zh: "末页",
  },
  "history.roundRange": {
    en: "Round Range",
    ko: "회차 범위",
    zh: "回合范围",
  },
  "history.allRounds": {
    en: "All Rounds",
    ko: "전체 회차",
    zh: "所有回合",
  },
  "history.btcWins": {
    en: "BTC Wins",
    ko: "BTC 승",
    zh: "BTC 胜",
  },
  "history.ethWins": {
    en: "ETH Wins",
    ko: "ETH 승",
    zh: "ETH 胜",
  },
  "history.ties": {
    en: "Ties",
    ko: "무승부",
    zh: "平局",
  },
}

// 번역 함수
export function t(language: Language, key: string): string {
  if (!translations[key]) {
    console.warn(`Translation key not found: ${key}`)
    return key
  }

  return translations[key][language] || translations[key].en
}
