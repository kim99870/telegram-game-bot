"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

// 지원하는 언어 타입 정의
export type Language = "en" | "ko" | "zh"

// 언어 컨텍스트 타입 정의
interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
}

// 기본값으로 영어 설정
const defaultLanguageContext: LanguageContextType = {
  language: "en",
  setLanguage: () => {},
}

// 언어 컨텍스트 생성
const LanguageContext = createContext<LanguageContextType>(defaultLanguageContext)

// 언어 제공자 컴포넌트
export function LanguageProvider({ children }: { children: ReactNode }) {
  // 브라우저 언어 설정 확인 (기본값은 영어)
  const getBrowserLanguage = (): Language => {
    if (typeof window !== "undefined") {
      const browserLang = navigator.language.split("-")[0]
      if (browserLang === "ko" || browserLang === "zh") {
        return browserLang as Language
      }
    }
    return "en"
  }

  // 로컬 스토리지에서 언어 설정 가져오기 또는 브라우저 언어 사용
  const getInitialLanguage = (): Language => {
    if (typeof window !== "undefined") {
      const savedLanguage = localStorage.getItem("preferredLanguage") as Language
      return savedLanguage || getBrowserLanguage()
    }
    return "en"
  }

  const [language, setLanguageState] = useState<Language>(getInitialLanguage)

  // 언어 변경 함수
  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage)
    if (typeof window !== "undefined") {
      localStorage.setItem("preferredLanguage", newLanguage)
    }
  }

  return <LanguageContext.Provider value={{ language, setLanguage }}>{children}</LanguageContext.Provider>
}

// 언어 컨텍스트 사용을 위한 훅
export function useLanguage() {
  return useContext(LanguageContext)
}
